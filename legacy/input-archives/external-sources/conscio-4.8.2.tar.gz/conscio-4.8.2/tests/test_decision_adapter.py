# tests/test_decision_adapter.py
"""Tests for DecisionAdapter and typed decision protocol (v4.8 S3).

Covers:
- Loader, validations, and error codes
- Local validation before I/O (raising ValueError)
- decide() against a loopback stub HTTP server: success, retries (429, 529), no-retry (401),
  network vs timeout, all malformed response variants
- Fuzzing with deterministic seed (>=2000 mutations) asserting only DecisionError
- Hub validate and redact tests
- Dedicated mutation tests M1 to M4
"""
from __future__ import annotations

import copy
import http.client
import http.server
import json
import random
import socket
import threading
import time
import traceback
import urllib.error
import urllib.request
from typing import Any

import pytest

from conscio.decision_adapter import (
    DEFAULT_TIMEOUT_S,
    Answer,
    Decision,
    DecisionAdapter,
    DecisionError,
    load_decision_adapter,
)
from conscio.hub import config as hub_config

# ── Test helpers and stub server ─────────────────────────────────────────────

def _canonical_choice_response(
    choice: str = "proceed",
    probs: dict[str, float] | None = None,
    confidence: float = 0.95,
    model: str = "decision-model",
) -> dict[str, Any]:
    return {
        "model": model,
        "answers": {
            "q_choice": {
                "type": "choice",
                "choice": choice,
                "probabilities": probs or {"proceed": 0.95, "hold": 0.03, "veto": 0.02},
                "confidence": confidence,
            }
        },
    }


def start_stub(responder: Any) -> tuple[http.server.ThreadingHTTPServer, int, list[dict]]:
    """Start a loopback HTTP stub server on an ephemeral port."""
    requests: list[dict] = []

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args: Any) -> None:
            pass

        def do_POST(self) -> None:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length)
            body = None
            if raw:
                try:
                    body = json.loads(raw.decode("utf-8"))
                except Exception:
                    body = raw
            entry = {
                "path": self.path,
                "headers": dict(self.headers),
                "body": body,
                "raw": raw,
            }
            requests.append(entry)
            status, payload, raw_bytes = responder(len(requests) - 1, entry)
            self.send_response(status)
            if raw_bytes is not None:
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw_bytes)))
                self.end_headers()
                self.wfile.write(raw_bytes)
            elif payload is not None:
                data = json.dumps(payload).encode("utf-8")
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_header("Content-Length", "0")
                self.end_headers()

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, server.server_address[1], requests


# ── Loader tests ─────────────────────────────────────────────────────────────

def test_loader_absent_block_returns_none():
    assert load_decision_adapter({}) is None
    assert load_decision_adapter({"adapter": {"type": "openai"}}) is None
    assert load_decision_adapter({"decision_adapter": None}) is None


def test_loader_bad_block_type_returns_bad_config():
    assert load_decision_adapter({"decision_adapter": "not-a-dict"}) == "bad_config"
    assert load_decision_adapter({"decision_adapter": [1, 2]}) == "bad_config"


def test_loader_inline_api_key_forbidden(monkeypatch):
    """M6: Inline api_key is strictly prohibited (D6), returning 'bad_config' even if key is in env."""
    monkeypatch.setenv("DECISION_API_KEY", "valid-env-key")
    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "api_key": "raw-key",
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"


def test_loader_unknown_key_returns_bad_config():
    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "unknown_key": "val",
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"


def test_loader_rejects_type_key_as_unknown():
    """M2: The 'type' key is unknown and must be rejected with 'bad_config'."""
    cfg = {
        "decision_adapter": {
            "type": "custom",
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"
    assert load_decision_adapter({"decision_adapter": {"type": "bogus"}}) == "bad_config"
    assert load_decision_adapter({"decision_adapter": {"type": 123}}) == "bad_config"


def test_loader_valid_config(monkeypatch):
    monkeypatch.setenv("DECISION_API_KEY", "dec-key-123")

    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        }
    }
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.url == "https://decision.example/v1/decide"
    assert ad.model == "jev"
    assert ad.api_key_env == "DECISION_API_KEY"
    assert ad.api_key == "dec-key-123"
    assert ad.timeout_s == DEFAULT_TIMEOUT_S

    # repr does not expose the key
    assert "dec-key-123" not in repr(ad)


def test_loader_missing_url_returns_bad_config(monkeypatch):
    monkeypatch.setenv("DECISION_API_KEY", "k")
    assert load_decision_adapter({
        "decision_adapter": {
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        }
    }) == "bad_config"
    assert load_decision_adapter({
        "decision_adapter": {
            "url": "",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        }
    }) == "bad_config"
    assert load_decision_adapter({
        "decision_adapter": {
            "url": "   ",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        }
    }) == "bad_config"


def test_loader_missing_model_returns_bad_config(monkeypatch):
    """M3 & M8: Missing or whitespace model has no default and must be rejected with 'bad_config'."""
    # 1. With key present in env
    monkeypatch.setenv("DECISION_API_KEY", "k")
    for bad_m in (None, "", "   ", "\t\n"):
        block = {
            "url": "https://decision.example/v1/decide",
            "api_key_env": "DECISION_API_KEY",
        }
        if bad_m is not None:
            block["model"] = bad_m
        assert load_decision_adapter({"decision_adapter": block}) == "bad_config"

    # 2. M8 dente: With key ABSENT in env, whitespace model must return bad_config, NEVER no_key
    monkeypatch.delenv("DECISION_API_KEY", raising=False)
    for bad_m in ("", "   ", "\t\n"):
        cfg_nokey = {
            "decision_adapter": {
                "url": "https://decision.example/v1/decide",
                "model": bad_m,
                "api_key_env": "DECISION_API_KEY",
            }
        }
        assert load_decision_adapter(cfg_nokey) == "bad_config"


def test_loader_missing_api_key_env_returns_bad_config():
    """M4: Missing api_key_env must return 'bad_config'."""
    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"


def test_loader_timeout_validation(monkeypatch):
    """M7: timeout_s <= 0, nan, inf, bool, string rejected with 'bad_config' before key check."""
    # 1. With key present in env
    monkeypatch.setenv("DECISION_API_KEY", "k")
    for bad_t in (0, 0.0, -1, -5.5, float("nan"), float("inf"), float("-inf"), 1e400, True, False, "10"):
        cfg = {
            "decision_adapter": {
                "url": "https://decision.example/v1/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
                "timeout_s": bad_t,
            }
        }
        assert load_decision_adapter(cfg) == "bad_config"

    # 2. M7 dente: With key ABSENT in env, timeout_s=0 must still return bad_config, NEVER no_key
    monkeypatch.delenv("DECISION_API_KEY", raising=False)
    for bad_t in (0, 0.0, -1):
        cfg_nokey = {
            "decision_adapter": {
                "url": "https://decision.example/v1/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
                "timeout_s": bad_t,
            }
        }
        assert load_decision_adapter(cfg_nokey) == "bad_config"

    # 3. Finite valid timeout
    monkeypatch.setenv("DECISION_API_KEY", "k")
    cfg_ok = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "timeout_s": 25.5,
        }
    }
    ad = load_decision_adapter(cfg_ok)
    assert isinstance(ad, DecisionAdapter)
    assert ad.timeout_s == 25.5


def test_loader_url_validation(monkeypatch):
    monkeypatch.setenv("DECISION_API_KEY", "k")

    # http outside loopback is rejected
    assert load_decision_adapter(
        {
            "decision_adapter": {
                "url": "http://api.external.com/v1/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
            }
        }
    ) == "bad_config"

    # ftp / file / non-http(s) rejected
    assert load_decision_adapter(
        {
            "decision_adapter": {
                "url": "file:///etc/passwd",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
            }
        }
    ) == "bad_config"

    # embedded credentials rejected
    assert load_decision_adapter(
        {
            "decision_adapter": {
                "url": "https://user:pass@api.external.com/v1/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
            }
        }
    ) == "bad_config"

    # http on 127.0.0.1 or localhost is allowed
    ad1 = load_decision_adapter(
        {
            "decision_adapter": {
                "url": "http://127.0.0.1:8080/v1/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
            }
        }
    )
    assert isinstance(ad1, DecisionAdapter)
    assert ad1.url == "http://127.0.0.1:8080/v1/decide"

    ad2 = load_decision_adapter(
        {
            "decision_adapter": {
                "url": "http://localhost:5000/decide",
                "model": "jev",
                "api_key_env": "DECISION_API_KEY",
            }
        }
    )
    assert isinstance(ad2, DecisionAdapter)
    assert ad2.url == "http://localhost:5000/decide"


def test_loader_key_resolution_order_and_file(tmp_path, monkeypatch):
    # Order: env -> vault -> file
    key_file = tmp_path / "keys.env"
    key_file.write_text("TEST_KEY=file-key\nOTHER_KEY=other-val\n")

    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path / "vault"))
    (tmp_path / "vault").mkdir()
    (tmp_path / "vault" / "TEST_KEY").write_text("vault-key\n")

    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "TEST_KEY",
            "api_key_file": str(key_file),
        }
    }

    # 1. Env present wins over vault and file
    monkeypatch.setenv("TEST_KEY", "env-key")
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.api_key == "env-key"

    # 2. Env absent, vault wins over file
    monkeypatch.delenv("TEST_KEY", raising=False)
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.api_key == "vault-key"

    # 3. Env absent, vault absent, file wins
    monkeypatch.delenv("TEST_KEY", raising=False)
    (tmp_path / "vault" / "TEST_KEY").unlink()
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.api_key == "file-key"

    # 4. File holding only OTHER keys -> no_key
    cfg_other = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "NON_EXISTENT_KEY",
            "api_key_file": str(key_file),
        }
    }
    assert load_decision_adapter(cfg_other) == "no_key"

    # 5. Tilde expansion in api_key_file
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    (fake_home / "my_key.env").write_text("TEST_KEY=expanded-home-key\n")
    monkeypatch.setenv("HOME", str(fake_home))
    cfg_tilde = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "TEST_KEY",
            "api_key_file": "~/my_key.env",
        }
    }
    ad_tilde = load_decision_adapter(cfg_tilde)
    assert isinstance(ad_tilde, DecisionAdapter)
    assert ad_tilde.api_key == "expanded-home-key"


def test_loader_missing_api_key_env_even_with_file_returns_bad_config(tmp_path):
    """D17 & M5: api_key_env is strictly mandatory. A key file without api_key_env returns bad_config."""
    key_file = tmp_path / "valid.key"
    key_file.write_text("DECISION_API_KEY=secret-token\n")

    # Only api_key_file provided, no api_key_env -> bad_config
    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_file": str(key_file),
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"

    # api_key_env is None -> bad_config
    cfg_none = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": None,
            "api_key_file": str(key_file),
        }
    }
    assert load_decision_adapter(cfg_none) == "bad_config"

    # api_key_env empty or whitespace -> bad_config
    cfg_empty = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "   ",
            "api_key_file": str(key_file),
        }
    }
    assert load_decision_adapter(cfg_empty) == "bad_config"


def test_loader_key_file_with_other_key_before_target_returns_correct_key(tmp_path, monkeypatch):
    """D17 finding 1: strict matching ensures a previous key in file does NOT leak."""
    monkeypatch.delenv("DECISION_API_KEY", raising=False)
    monkeypatch.delenv("OTHER_SERVICE_TOKEN", raising=False)
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path / "vault"))

    key_file = tmp_path / "multi.env"
    key_file.write_text("OTHER_SERVICE_TOKEN=aaa-wrong-secret\nDECISION_API_KEY=bbb-right\n")

    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "api_key_file": str(key_file),
        }
    }
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.api_key == "bbb-right"


def test_loader_key_file_with_only_other_keys_returns_no_key(tmp_path, monkeypatch):
    """D17: When file holds only other keys, resolve returns empty -> no_key."""
    monkeypatch.delenv("DECISION_API_KEY", raising=False)
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path / "vault"))

    key_file = tmp_path / "other.env"
    key_file.write_text("OTHER_SERVICE_TOKEN=aaa-wrong-secret\n")

    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "api_key_file": str(key_file),
        }
    }
    assert load_decision_adapter(cfg) == "no_key"


def test_loader_key_file_tilde_expansion(tmp_path, monkeypatch):
    """Spec §7: tilde expansion in api_key_file."""
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    (fake_home / "tilde_key.env").write_text("DECISION_API_KEY=expanded-home-key\n")
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.delenv("DECISION_API_KEY", raising=False)
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path / "vault"))

    cfg = {
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "api_key_file": "~/tilde_key.env",
        }
    }
    ad = load_decision_adapter(cfg)
    assert isinstance(ad, DecisionAdapter)
    assert ad.api_key == "expanded-home-key"


# ── Local validation tests ───────────────────────────────────────────────────

def test_local_validation_boolean_rejected_with_noul_message():
    ad = DecisionAdapter("https://decision.example/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
    with pytest.raises(ValueError) as exc:
        ad.decide("state", {"q1": {"type": "boolean"}})
    assert "use 'noul' instead" in str(exc.value)


def test_local_validation_empty_or_invalid_questions():
    ad = DecisionAdapter("https://decision.example/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
    with pytest.raises(ValueError):
        ad.decide("state", {})
    with pytest.raises(ValueError):
        ad.decide("state", "not-a-dict")  # type: ignore
    with pytest.raises(ValueError):
        ad.decide("state", {"": {"type": "noul"}})
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": "not-a-dict"})  # type: ignore
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "unsupported"}})


def test_local_validation_choice_criteria():
    ad = DecisionAdapter("https://decision.example/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
    # missing criteria
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "choice"}})
    # empty criteria (0 options)
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "choice", "criteria": {}}})
    # 256 options (> 255)
    crit_256 = {f"opt_{i}": f"desc_{i}" for i in range(256)}
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "choice", "criteria": crit_256}})


def test_local_validation_score_criteria():
    ad = DecisionAdapter("https://decision.example/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
    # missing criteria
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "score"}})
    # 0 levels
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "score", "criteria": {}}})
    # 11 levels (> 10)
    crit_11 = {f"{i}": f"level {i}" for i in range(11)}
    with pytest.raises(ValueError):
        ad.decide("state", {"q1": {"type": "score", "criteria": crit_11}})


def test_local_validation_does_zero_network_requests():
    server, port, requests = start_stub(lambda i, r: (200, {}, None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        with pytest.raises(ValueError):
            ad.decide("state", {"q1": {"type": "boolean"}})
        with pytest.raises(ValueError):
            ad.decide("state", {"q1": {"type": "choice"}})  # no criteria
        assert len(requests) == 0
    finally:
        server.shutdown()
        server.server_close()


# ── decide() transport and response tests ─────────────────────────────────────

def test_decide_choice_success():
    resp_body = {
        "model": "decision-model-v1",
        "answers": {
            "q_proceed": {
                "type": "choice",
                "choice": "proceed",
                "probabilities": {"proceed": 0.85, "hold": 0.10, "veto": 0.05},
                "confidence": 0.88,
            }
        },
    }
    server, port, requests = start_stub(lambda i, r: (200, resp_body, None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "test-model", "DECISION_API_KEY", None, 10.0, "secret-bearer")
        questions = {
            "q_proceed": {
                "type": "choice",
                "criteria": {"proceed": "Go", "hold": "Wait", "veto": "Stop"},
            }
        }
        dec = ad.decide({"ctx": 123}, questions)
        assert isinstance(dec, Decision)
        assert dec.model == "decision-model-v1"
        assert "q_proceed" in dec.answers
        ans = dec.answers["q_proceed"]
        assert isinstance(ans, Answer)
        assert ans.type == "choice"
        assert ans.value == "proceed"
        assert ans.probabilities == {"proceed": 0.85, "hold": 0.10, "veto": 0.05}
        assert ans.confidence == 0.88

        # Verify request headers and path
        assert len(requests) == 1
        req = requests[0]
        assert req["path"] == "/v1/decide"
        assert req["headers"]["Authorization"] == "Bearer secret-bearer"
        assert req["headers"]["Content-Type"] == "application/json"
        assert req["body"]["model"] == "test-model"
        assert req["body"]["questions"] == questions
        assert req["body"]["state"] == {"ctx": 123}
    finally:
        server.shutdown()
        server.server_close()


def test_decide_posts_to_exact_url_without_appending_path():
    """M1: The adapter posts to the exact path in url, never appending a suffix."""
    server, port, requests = start_stub(lambda i, r: (200, _canonical_choice_response(), None))
    custom_path = "/my/custom/path"
    try:
        ad = DecisionAdapter(
            url=f"http://127.0.0.1:{port}{custom_path}",
            model="jev",
            api_key_env="DECISION_API_KEY",
            api_key_file=None,
            timeout_s=10.0,
            api_key="secret-key",
        )
        ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
        assert len(requests) == 1
        assert requests[0]["path"] == custom_path
    finally:
        server.shutdown()
        server.server_close()


def test_decide_noul_success():
    resp_body = {
        "model": "decision-model-v1",
        "answers": {
            "q_prob": {
                "type": "noul",
                "noul": 0.72,
            }
        },
    }
    server, port, _requests = start_stub(lambda i, r: (200, resp_body, None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        dec = ad.decide({}, {"q_prob": {"type": "noul"}})
        assert dec.answers["q_prob"] == Answer(
            type="noul",
            value=0.72,
            probabilities={},
            confidence=None,
        )
    finally:
        server.shutdown()
        server.server_close()


def test_decide_score_success():
    resp_body = {
        "model": "decision-model-v1",
        "answers": {
            "q_score": {
                "type": "score",
                "score": 3.0,
                "probabilities": {"1": 0.05, "2": 0.15, "3": 0.80},
                "confidence": 0.91,
            }
        },
    }
    server, port, _requests = start_stub(lambda i, r: (200, resp_body, None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        dec = ad.decide(
            {},
            {"q_score": {"type": "score", "criteria": {"1": "Low", "2": "Med", "3": "High"}}},
        )
        assert dec.answers["q_score"] == Answer(
            type="score",
            value=3.0,
            probabilities={"1": 0.05, "2": 0.15, "3": 0.80},
            confidence=0.91,
        )
    finally:
        server.shutdown()
        server.server_close()


def test_decide_retries_429_and_529_then_succeeds(monkeypatch):
    # Monkeypatch time.sleep to avoid waiting during test
    monkeypatch.setattr(time, "sleep", lambda s: None)

    # 429 on call 0, 529 on call 1, 200 on call 2
    def responder(call_idx: int, req: dict):
        if call_idx == 0:
            return 429, {"error": "rate limit"}, None
        if call_idx == 1:
            return 529, {"error": "overloaded"}, None
        return 200, _canonical_choice_response(), None

    server, port, requests = start_stub(responder)
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        dec = ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
        assert isinstance(dec, Decision)
        assert len(requests) == 3
    finally:
        server.shutdown()
        server.server_close()


def test_decide_401_fails_immediately_without_retry():
    def responder(call_idx: int, req: dict):
        return 401, {"error": "unauthorized"}, None

    server, port, requests = start_stub(responder)
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        with pytest.raises(DecisionError) as exc:
            ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
        assert exc.value.status == "http_401"
        assert len(requests) == 1
    finally:
        server.shutdown()
        server.server_close()


def test_decide_deadline_exhaustion_raises_timeout():
    def responder(call_idx: int, req: dict):
        time.sleep(0.1)
        return 200, _canonical_choice_response(), None

    server, port, _requests = start_stub(responder)
    try:
        # timeout_s very small
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 0.03, "k")
        with pytest.raises(DecisionError) as exc:
            ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
        assert exc.value.status == "timeout"
    finally:
        server.shutdown()
        server.server_close()


def test_decide_network_error_with_healthy_deadline_raises_network(monkeypatch):
    # Simulate a socket/network TimeoutError occurring when the overall deadline is still healthy
    def _fake_urlopen(req, timeout):
        raise urllib.error.URLError(TimeoutError("socket timed out"))

    monkeypatch.setattr(urllib.request, "urlopen", _fake_urlopen)

    ad = DecisionAdapter("http://127.0.0.1:9/v1/decide", "m", "DECISION_API_KEY", None, 30.0, "k")
    with pytest.raises(DecisionError) as exc:
        ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
    assert exc.value.status == "network"


def test_decide_connection_refused_raises_network():
    # Connecting to closed port on loopback
    ad = DecisionAdapter("http://127.0.0.1:1/v1/decide", "m", "DECISION_API_KEY", None, 5.0, "k")
    with pytest.raises(DecisionError) as exc:
        ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
    assert exc.value.status == "network"


# ── Malformed response variants ──────────────────────────────────────────────

@pytest.mark.parametrize(
    "bad_payload",
    [
        b"not json at all",
        b"\xff\xfe\x00\x00invalid utf8",
        json.dumps([]).encode("utf-8"),
        json.dumps("string").encode("utf-8"),
        json.dumps({"model": "m"}).encode("utf-8"),  # answers missing
        json.dumps({"answers": []}).encode("utf-8"),  # answers not dict
        json.dumps({"answers": {}}).encode("utf-8"),  # question missing
        json.dumps({"answers": {"q_choice": "not-a-dict"}}).encode("utf-8"),
        json.dumps({"answers": {"q_choice": {"type": "noul", "noul": 0.5}}}).encode("utf-8"),  # type mismatch
        # choice: value not in criteria
        json.dumps({
            "answers": {
                "q_choice": {
                    "type": "choice",
                    "choice": "bogus_option",
                    "probabilities": {"proceed": 0.8, "hold": 0.1, "veto": 0.1},
                    "confidence": 0.8,
                }
            }
        }).encode("utf-8"),
        # choice: probabilities missing key
        json.dumps({
            "answers": {
                "q_choice": {
                    "type": "choice",
                    "choice": "proceed",
                    "probabilities": {"proceed": 0.9, "hold": 0.1},
                    "confidence": 0.8,
                }
            }
        }).encode("utf-8"),
        # choice: probability value not finite / bool / out of range
        json.dumps({
            "answers": {
                "q_choice": {
                    "type": "choice",
                    "choice": "proceed",
                    "probabilities": {"proceed": 1.5, "hold": 0.1, "veto": 0.1},
                    "confidence": 0.8,
                }
            }
        }).encode("utf-8"),
        json.dumps({
            "answers": {
                "q_choice": {
                    "type": "choice",
                    "choice": "proceed",
                    "probabilities": {"proceed": True, "hold": 0.1, "veto": 0.1},
                    "confidence": 0.8,
                }
            }
        }).encode("utf-8"),
        # choice: confidence is bool
        json.dumps({
            "answers": {
                "q_choice": {
                    "type": "choice",
                    "choice": "proceed",
                    "probabilities": {"proceed": 0.8, "hold": 0.1, "veto": 0.1},
                    "confidence": True,
                }
            }
        }).encode("utf-8"),
        # giant integer in JSON -> malformed without OverflowError
        b'{"answers": {"q_choice": {"type": "choice", "choice": "proceed", "probabilities": {"proceed": 1' + b'0' * 500 + b', "hold": 0, "veto": 0}, "confidence": 0.8}}}',
    ],
)
def test_decide_malformed_variants(bad_payload):
    server, port, _ = start_stub(lambda i, r: (200, None, bad_payload))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
        with pytest.raises(DecisionError) as exc:
            ad.decide({}, {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}})
        assert exc.value.status == "malformed"
    finally:
        server.shutdown()
        server.server_close()


# ── Fuzz test (>= 2000 deterministic mutations) ──────────────────────────────

_FUZZ_JUNK = [
    None,
    True,
    False,
    0,
    1,
    -1,
    1.5,
    float("nan"),
    float("inf"),
    float("-inf"),
    10**400,
    "",
    "bogus",
    [],
    [1, 2],
    {},
    {"nested": "dict"},
]


def _all_paths(data: Any, prefix: tuple = ()) -> list[tuple]:
    paths: list[tuple] = []
    if isinstance(data, dict):
        for k, v in data.items():
            p = prefix + (k,)
            paths.append(p)
            paths.extend(_all_paths(v, p))
    elif isinstance(data, list):
        for i, v in enumerate(data):
            p = prefix + (i,)
            paths.append(p)
            paths.extend(_all_paths(v, p))
    return paths


def test_fuzz_decide_contract_never_raises_unexpected_exceptions():
    """Fuzz >= 2000 mutated server responses: only DecisionError is raised."""
    rng = random.Random(20260927)
    base = _canonical_choice_response()
    questions = {"q_choice": {"type": "choice", "criteria": {"proceed": "", "hold": "", "veto": ""}}}

    class MockResponse:
        def __init__(self, data: bytes):
            self._data = data

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def read(self):
            return self._data

    ad_mock = DecisionAdapter("http://127.0.0.1:0/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "k")
    violations: list[str] = []

    for i in range(2000):
        data = copy.deepcopy(base)
        op = i % 3
        paths = _all_paths(data)

        if op == 0 and paths:  # Replace node with junk
            p = rng.choice(paths)
            curr = data
            for seg in p[:-1]:
                curr = curr[seg]
            curr[p[-1]] = rng.choice(_FUZZ_JUNK)
        elif op == 1 and paths:  # Delete node
            dict_paths = [p for p in paths if isinstance(p[-1], str)]
            if dict_paths:
                p = rng.choice(dict_paths)
                curr = data
                for seg in p[:-1]:
                    curr = curr[seg]
                del curr[p[-1]]
        elif op == 2 and paths:  # Nest node deeper
            p = rng.choice(paths)
            curr = data
            for seg in p[:-1]:
                curr = curr[seg]
            curr[p[-1]] = {"extra_nested": curr[p[-1]]}

        raw_bytes = json.dumps(data).encode("utf-8")

        def _mock_urlopen(*args, _payload=raw_bytes, **kwargs):
            return MockResponse(_payload)

        orig_urlopen = urllib.request.urlopen
        urllib.request.urlopen = _mock_urlopen
        try:
            res = ad_mock.decide("state", questions)
            # If it succeeded, check fields
            assert isinstance(res, Decision)
        except DecisionError as de:
            assert de.status in ("malformed", "timeout", "network") or de.status.startswith("http_")
        except Exception as exc:
            violations.append(f"Iteration {i} raised unexpected {type(exc).__name__}: {exc}")
        finally:
            urllib.request.urlopen = orig_urlopen

    assert not violations, f"Fuzz violations: {violations[:5]}"


# ── Hub validate & redact tests ──────────────────────────────────────────────

def test_hub_validate_rejects_inline_api_key_in_decision_adapter():
    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "api_key": "raw-key-secret",
        },
    }
    errs = hub_config.validate(cfg)
    assert any("decision_adapter.api_key is not allowed" in e for e in errs)


def test_hub_validate_rejects_unknown_keys_in_decision_adapter():
    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
            "mystery_key": "foo",
        },
    }
    errs = hub_config.validate(cfg)
    assert any("decision_adapter unknown key 'mystery_key'" in e for e in errs)


def test_hub_validate_rejects_type_key_in_decision_adapter():
    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "type": "not-a-type",
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        },
    }
    errs = hub_config.validate(cfg)
    assert any("decision_adapter unknown key 'type'" in e for e in errs)


def test_hub_validate_accepts_valid_decision_adapter():
    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_env": "DECISION_API_KEY",
        },
    }
    assert hub_config.validate(cfg) == []


def test_hub_validate_requires_api_key_env_in_decision_adapter():
    """M9: Hub validate requires api_key_env naming the variable, never accepting missing env."""
    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
        },
    }
    errs = hub_config.validate(cfg)
    assert any("decision_adapter requires 'api_key_env'" in e for e in errs)

    # Even with api_key_file provided, api_key_env is strictly required
    cfg_file = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key_file": "/path/to/key.env",
        },
    }
    errs_file = hub_config.validate(cfg_file)
    assert any("decision_adapter requires 'api_key_env'" in e for e in errs_file)


def test_hub_redact_masks_api_key_in_decision_adapter(tmp_path, monkeypatch):
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path))
    (tmp_path / "DECISION_API_KEY").write_text("secret-in-vault\n")

    cfg = {
        "model": "m",
        "adapter": {"type": "openai"},
        "decision_adapter": {
            "url": "https://decision.example/v1/decide",
            "model": "jev",
            "api_key": "raw-inline-secret",
            "api_key_env": "DECISION_API_KEY",
        },
    }
    redacted = hub_config.redact(cfg)
    da = redacted["decision_adapter"]
    assert "api_key" not in da
    assert da["api_key_present"] is True
    assert da["url"] == "https://decision.example/v1/decide"
    assert da["model"] == "jev"


# ── G33b Construction validation and security teeth ─────────────────────────

def test_direct_construction_with_file_url_raises_valueerror_and_no_io(monkeypatch):
    def _explode(*args, **kwargs):
        raise AssertionError("urlopen must NEVER be called on invalid url construction")

    monkeypatch.setattr(urllib.request, "urlopen", _explode)
    with pytest.raises(ValueError, match="Invalid url"):
        DecisionAdapter("file:///etc/hostname#", "m", "DECISION_API_KEY", None, 10.0, "secret-key")


@pytest.mark.parametrize("bad_timeout", [float("nan"), float("inf"), 0, -1, -0.5, 0.0, True, False])
def test_construction_invalid_timeout_s_raises_valueerror(bad_timeout):
    with pytest.raises(ValueError, match="timeout_s must be"):
        DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, bad_timeout, "secret-key")


@pytest.mark.parametrize("bad_model", ["", "   ", "\t\n", None, 123])
def test_construction_invalid_model_raises_valueerror(bad_model):
    with pytest.raises(ValueError, match="Invalid model"):
        DecisionAdapter("https://decision.example/v1/decide", bad_model, "DECISION_API_KEY", None, 10.0, "secret-key")  # type: ignore


@pytest.mark.parametrize("bad_env", ["", "   ", "lower_case", "123_START", None, 123, "VAR-WITH-DASH"])
def test_construction_invalid_api_key_env_raises_valueerror(bad_env):
    with pytest.raises(ValueError, match="Invalid api_key_env"):
        DecisionAdapter("https://decision.example/v1/decide", "m", bad_env, None, 10.0, "secret-key")  # type: ignore


@pytest.mark.parametrize("bad_key", ["secret\nkey", "secret\x00key", "secret\rkey", ""])
def test_construction_invalid_api_key_raises_valueerror(bad_key):
    with pytest.raises(ValueError, match="api_key"):
        DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, 10.0, bad_key)


def test_transport_exception_never_leaks_secret_key_in_str_repr_args_traceback(monkeypatch):
    secret_key = "TOP_SECRET_API_KEY_xyz123"
    ad = DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, 10.0, secret_key)

    def _exploding_urlopen(req, timeout):
        raise ValueError(f"bad header Authorization: Bearer {secret_key}")

    monkeypatch.setattr(urllib.request, "urlopen", _exploding_urlopen)

    with pytest.raises(DecisionError) as exc_info:
        ad.decide({"state": "ok"}, {"q1": {"type": "noul"}})

    err = exc_info.value
    assert err.status == "network"
    assert err.__cause__ is None
    assert err.__context__ is None
    assert secret_key not in str(err)
    assert secret_key not in repr(err)
    for arg in err.args:
        assert secret_key not in str(arg)

    tb_str = "".join(traceback.format_exception(type(err), err, err.__traceback__))
    assert secret_key not in tb_str


def test_local_validation_state_rejects_nan_and_non_serializable_without_io(monkeypatch):
    ad = DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, 10.0, "key")

    def _explode(*args, **kwargs):
        raise AssertionError("urlopen must NEVER be called on invalid state")

    monkeypatch.setattr(urllib.request, "urlopen", _explode)

    # State with NaN
    with pytest.raises(ValueError, match="state is not valid JSON"):
        ad.decide({"metric": float("nan")}, {"q1": {"type": "noul"}})

    # State with Inf
    with pytest.raises(ValueError, match="state is not valid JSON"):
        ad.decide({"metric": float("inf")}, {"q1": {"type": "noul"}})

    # State with non-serializable object
    class Unserializable:
        pass

    with pytest.raises(ValueError, match="state is not valid JSON"):
        ad.decide({"obj": Unserializable()}, {"q1": {"type": "noul"}})


# ── G33c ASCII key validation and __context__ clearing teeth ───────────────

def test_construction_non_ascii_key_raises_valueerror_and_loader_returns_bad_config(monkeypatch):
    bad_key = "SECRET€KEY"
    with pytest.raises(ValueError) as exc_info:
        DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, 10.0, bad_key)
    err_msg = str(exc_info.value)
    assert bad_key not in err_msg

    monkeypatch.setenv("CONSCIO_DECISION_KEY_NONASCII", bad_key)
    cfg = {
        "decision_adapter": {
            "url": "https://api.example.com/v1/decide",
            "model": "m",
            "api_key_env": "CONSCIO_DECISION_KEY_NONASCII",
            "timeout_s": 10.0,
        }
    }
    assert load_decision_adapter(cfg) == "bad_config"


@pytest.mark.parametrize(
    "exc_factory",
    [
        lambda s: ValueError(f"bad header Authorization: Bearer {s}"),
        lambda s: OSError(f"os network error with {s}"),
        lambda s: RuntimeError(f"runtime transport failure with {s}"),
        lambda s: urllib.error.URLError(f"url error {s}"),
        lambda s: KeyError(f"missing key {s}"),
        lambda s: http.client.InvalidURL(f"invalid url containing {s}"),
        lambda s: socket.timeout(f"socket timed out with {s}"),  # noqa: UP041
        lambda s: UnicodeEncodeError("latin-1", f"bad header Bearer {s}", 0, 1, "ordinal not in range"),
    ],
    ids=[
        "ValueError",
        "OSError",
        "RuntimeError",
        "URLError",
        "KeyError",
        "InvalidURL",
        "socket.timeout",
        "UnicodeEncodeError",
    ],
)
def test_transport_exceptions_clean_context_and_no_leak(monkeypatch, exc_factory):
    secret_key = "TOP_SECRET_API_KEY_xyz123"
    ad = DecisionAdapter("https://api.example.com/v1/decide", "m", "DECISION_API_KEY", None, 10.0, secret_key)

    exc_to_raise = exc_factory(secret_key)

    def _exploding_urlopen(req, timeout):
        raise exc_to_raise

    monkeypatch.setattr(urllib.request, "urlopen", _exploding_urlopen)

    with pytest.raises(DecisionError) as exc_info:
        ad.decide({"state": "ok"}, {"q1": {"type": "noul"}})

    err = exc_info.value
    assert err.status == "network"
    assert err.__cause__ is None
    assert err.__context__ is None
    assert secret_key not in str(err)
    assert secret_key not in repr(err)
    for arg in err.args:
        assert secret_key not in str(arg)

    tb_str = "".join(traceback.format_exception(type(err), err, err.__traceback__))
    assert secret_key not in tb_str

    # Walk the full cause and context chain to None
    visited = set()
    curr: BaseException | None = err
    while curr is not None:
        assert id(curr) not in visited
        visited.add(id(curr))
        assert secret_key not in str(curr)
        assert secret_key not in repr(curr)
        for arg in curr.args:
            assert secret_key not in str(arg)
        if isinstance(curr, UnicodeEncodeError):
            assert secret_key not in str(curr.object)
        curr = curr.__cause__ or curr.__context__


# ── A57 successors (cases moved out of the old judge transport tests) ──
# The judge no longer owns transport; the cases it used to pin now live
# here, next to the code that owns them. The A57 report carries the full
# migration table.

def test_envelope_top_level_keys_are_exact():
    """Successor of the judge's old loose-body teeth (A56): the request
    body is exactly {model, state, questions} at the root — no extra
    top-level key ever (the T5 defect was a root-level question with
    no model and no questions map)."""
    server, port, requests = start_stub(
        lambda i, r: (200, _canonical_choice_response(), None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide",
                             "m", "DECISION_API_KEY", None, 10.0, "k")
        ad.decide({"ctx": 1}, {"q_choice": {"type": "choice",
                                             "criteria": {"proceed": "",
                                                          "hold": "",
                                                          "veto": ""}}})
        assert set(requests[0]["body"]) == {"model", "state", "questions"}
        assert set(requests[0]["body"]["questions"]) == {"q_choice"}
    finally:
        server.shutdown()
        server.server_close()


def _choice_response_with_confidence(confidence: Any) -> dict:
    body: dict[str, Any] = {
        "model": "decision-model",
        "answers": {
            "q_choice": {
                "type": "choice",
                "choice": "proceed",
                "probabilities": {"proceed": 0.9, "hold": 0.05, "veto": 0.05},
            }
        },
    }
    if confidence is not None:
        body["answers"]["q_choice"]["confidence"] = confidence
    return body


@pytest.mark.parametrize("bad_conf, why", [
    (1.7, "H51 finding 3: a confidence above 1 is not 'confident', it is invalid"),
    (-0.1, "H51 finding 3: a confidence below 0 is invalid"),
    (float("nan"), "NaN is not a number (json.loads accepts it, it must still fail)"),
    (None, "emenda A51: confidence absent is a broken contract, not optional"),
], ids=["above-one", "below-zero", "nan", "missing"])
def test_decide_rejects_out_of_range_confidence(bad_conf, why):
    server, port, _ = start_stub(
        lambda i, r: (200, _choice_response_with_confidence(bad_conf), None))
    try:
        ad = DecisionAdapter(f"http://127.0.0.1:{port}/v1/decide",
                             "m", "DECISION_API_KEY", None, 10.0, "k")
        with pytest.raises(DecisionError) as exc:
            ad.decide({}, {"q_choice": {"type": "choice",
                                         "criteria": {"proceed": "",
                                                      "hold": "",
                                                      "veto": ""}}})
        assert exc.value.status == "malformed", why
    finally:
        server.shutdown()
        server.server_close()


def test_loader_non_utf8_key_file_is_no_key(tmp_path, monkeypatch):
    """Successor of the judge's A53 P1 case: a key file that is not
    UTF-8 is unreadable -> no key -> 'no_key', never
    UnicodeDecodeError (zero connections: the loader never opens
    transport)."""
    key_file = tmp_path / "keys.env"
    key_file.write_bytes(b"TEST_KEY_X=\xff\xfe\x00")
    vault = tmp_path / "vault"
    vault.mkdir()
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(vault))
    monkeypatch.delenv("TEST_KEY_X", raising=False)
    assert load_decision_adapter({
        "decision_adapter": {
            "url": "https://example.com/v1/decide",
            "model": "m",
            "api_key_env": "TEST_KEY_X",
            "api_key_file": str(key_file),
        },
    }) == "no_key"

