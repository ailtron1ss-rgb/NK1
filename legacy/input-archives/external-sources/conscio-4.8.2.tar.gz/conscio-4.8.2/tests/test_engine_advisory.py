# tests/test_engine_advisory.py
"""v1.6 (#5/#9): engine.advisory() — the host's pull surface.

The daemon perceives -> reflects -> acts, but the host had no cheap, documented
way to read what Conscio concluded, so awake output died unread. advisory() is a
read-only, no-LLM, no-mutation structured snapshot the host pulls each turn:
cognitive state + goals tagged by provenance (executable vs diagnostic, #7) +
operational status (lockdown / failure-brake, #8).
"""
import pathlib

import pytest

from conscio.content_layer import _RAG_DISABLED
from conscio.engine import ConsciousnessEngine
from conscio.goal_generator import GoalOrigin

_GRAPH = pathlib.Path(__file__).resolve().parent / "fixtures" / "graph_small.json"
_EXPECTED_KEYS = {"awake", "reflection", "meta", "goals", "coherence",
                  "status", "structural", "recommendations"}


def _assert_advisory_contract(eng):
    adv = eng.advisory()                          # MUST NOT raise
    assert isinstance(adv, dict)
    assert set(adv) >= _EXPECTED_KEYS, _EXPECTED_KEYS - set(adv)
    assert set(adv["status"]) >= {"action_lockdown", "dream_recommended", "brake"}
    return adv


@pytest.fixture
def engine(tmp_path):
    e = ConsciousnessEngine(model_name="glm-5.1", storage_path=tmp_path)
    e.content_layer._session_rag = _RAG_DISABLED   # hermetic: no Ollama probe
    yield e
    e.close()


class TestAdvisoryShape:
    def test_core_keys_present(self, engine):
        adv = engine.advisory()
        for key in ("awake", "reflection", "goals", "coherence",
                    "status", "recommendations"):
            assert key in adv, key
        for key in ("action_lockdown", "dream_recommended", "brake"):
            assert key in adv["status"], key

    def test_goals_is_a_list_of_tagged_dicts(self, engine):
        engine.goals.add_user_goal("ship the release")
        adv = engine.advisory()
        assert adv["goals"]
        g = adv["goals"][0]
        assert set(g) == {"description", "origin", "executable"}


class TestAdvisoryAwake:
    def test_tracks_awake_state(self, engine):
        engine.sleep()
        assert engine.advisory()["awake"] is False
        engine.wake()
        assert engine.advisory()["awake"] is True


class TestAdvisoryProvenance:
    def test_tags_executable_and_diagnostic_goals(self, engine):
        engine.goals.add_user_goal("real user task")            # executable
        engine.goals.generate_from_curiosity("a thought",
                                             source="self_prompt")  # diagnostic
        by_desc = {g["description"]: g for g in engine.advisory()["goals"]}
        user = next(g for d, g in by_desc.items() if "real user task" in d)
        diag = next(g for d, g in by_desc.items() if "a thought" in d)
        assert user["executable"] is True
        assert user["origin"] == GoalOrigin.USER.value
        assert diag["executable"] is False
        assert diag["origin"] == GoalOrigin.SELF_PROMPT.value

    def test_recommends_review_of_diagnostic_goals(self, engine):
        engine.goals.generate_from_curiosity("introspect", source="self_prompt")
        recs = " ".join(engine.advisory()["recommendations"]).lower()
        assert "diagnostic" in recs


class TestAdvisoryStatus:
    def test_reports_action_lockdown(self, engine):
        engine.state.action_lockdown = True
        assert engine.advisory()["status"]["action_lockdown"] is True

    def test_surfaces_failure_brake(self, engine):
        # The aggregate brake (#8) emits a system event when it trips; the host
        # reads it from the advisory rather than tailing the event log.
        engine.event_bus.emit(
            type="system", category="system",
            data={"message": "failure-rate brake: autonomous loop stopped",
                  "failures": 4, "cycles": 4, "failure_rate": 1.0},
            priority=8)
        assert "failure-rate brake" in (engine.advisory()["status"]["brake"] or "")

    def test_no_brake_when_none_emitted(self, engine):
        assert engine.advisory()["status"]["brake"] is None


class TestAdvisoryIsCheap:
    def test_read_only_no_adapter_required(self, engine):
        # No adapter is attached -> if advisory() called inference it would fail.
        # It must return cleanly and not mutate the active-goal count.
        engine.goals.add_user_goal("task")
        before = len(engine.goals.active_goals())
        engine.advisory()
        engine.advisory()
        assert len(engine.goals.active_goals()) == before


class TestAdvisoryNeverRaises:
    """I-C1/I-C2: advisory() returns the documented shape and NEVER raises across
    degraded states. Offline twin of the reviewer's live §9 probe 1 (they converge)."""

    def test_try_keep_fresh_engine(self, engine):
        adv = _assert_advisory_contract(engine)
        assert adv["structural"] is None             # no graph loaded

    def test_try_break_awake_on(self, engine):
        engine.wake()
        _assert_advisory_contract(engine)

    def test_try_break_with_diagnostic_goal(self, engine):
        engine.goals.add_user_goal("introspect", origin=GoalOrigin.SELF_PROMPT)
        adv = _assert_advisory_contract(engine)
        assert any(not g["executable"] for g in adv["goals"])

    def test_try_break_with_graph_and_workspace(self, engine):
        engine.load_structure(_GRAPH, workspace_id="wsA", root=engine.storage.parent)
        adv = _assert_advisory_contract(engine)
        assert adv["structural"] is not None
        assert "drift" in adv["structural"] and "freshness" in adv["structural"]

    def test_try_break_corrupt_drift_sidecar(self, engine):
        # Corrupt the drift store, THEN load with a workspace: load tolerates the
        # corrupt store and advisory() must still honor the contract, not raise.
        (engine.storage / "structural_drift.json").write_text("{ not json")
        engine.load_structure(_GRAPH, workspace_id="wsA", root=engine.storage.parent)
        _assert_advisory_contract(engine)


class TestFeed:
    """v4.0 BUG-08: engine.feed() — the embedder's push surface.

    Deliberately *thinner* than the ``conscio_feed`` MCP tool: no envelope
    normalization, no dedup by event_id, no metabolic charge, and no
    perceive/reflect cycle. These tests pin that divergence so it stays a
    documented choice instead of decaying into a silent one.
    """

    def test_emits_event_on_the_bus(self, engine):
        engine.feed({"type": "host:event", "category": "system",
                     "data": {"k": "v"}})
        hits = engine.event_bus.query(type="host:event")
        assert len(hits) == 1
        assert hits[0].data["k"] == "v"

    def test_returns_advisory_contract(self, engine):
        adv = engine.feed({"type": "host:event", "category": "system",
                           "data": {"probe": "advisory"}})
        assert isinstance(adv, dict)
        assert set(adv) >= _EXPECTED_KEYS, _EXPECTED_KEYS - set(adv)

    def test_absent_keys_are_defaulted(self, engine):
        engine.feed({})
        hits = engine.event_bus.query(type="host:event")
        assert len(hits) == 1
        assert hits[0].category == "system"

    def test_unknown_type_raises_valueerror_not_invalidparams(self, engine):
        # The EventBus vocabulary still guards the door, but embedders get a
        # raw ValueError — the MCP InvalidParams shaping lives in Bindings.
        with pytest.raises(ValueError):
            engine.feed({"type": "host:not-a-real-type", "data": {}})

    def test_does_not_run_the_perception_cycle(self, engine):
        # The docstring promises no cycle: the world model must stay untouched.
        # If this ever fails, feed() grew a cycle — revise the docstring on
        # purpose, do not just delete the assertion.
        before = engine.content_layer.world_model.entity_count()
        engine.feed({"type": "host:event", "category": "system",
                     "data": {"world_state": "Alice deployed the server"}})
        assert engine.content_layer.world_model.entity_count() == before
