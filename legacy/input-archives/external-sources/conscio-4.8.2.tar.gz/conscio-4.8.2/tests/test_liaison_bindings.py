# tests/test_liaison_bindings.py
import time
from types import SimpleNamespace

from conscio.agency import MockAdapter
from conscio.engine import ConsciousnessEngine
from conscio.liaison import mailbox, review, spool
from conscio.mcp.seen import SeenStore
from conscio.mcp.server import Bindings


def _publish(*ids):
    """A peer is reachable only if it has an address (v4.5.4): give the test
    peers the card their real server would publish at boot."""
    from conscio.liaison import directory
    for cid in ids:
        directory.publish({"instance_id": cid,
                           "spool": str(directory.spool_dir(cid)), "url": ""})


def _bind(tmp_path, *, instance_id, reviewers=(), hermes_review=True,
          act_flag=False, liaison_db=None, storage=None,
          relay=False, relay_peers=(), can_create_halls=False,
          identity_model="", identity_familia=""):
    eng = ConsciousnessEngine("glm-5.1", storage_path=storage or tmp_path)
    seen = SeenStore((storage or tmp_path) / "mcp_seen.db")
    b = Bindings(eng, seen, adapter_name=None, workspace_id="ws",
                 act_flag=act_flag, hermes_review=hermes_review,
                 reviewers=tuple(reviewers), self_instance_id=instance_id,
                 liaison_db=liaison_db or (tmp_path / "liaison.db"),
                 relay=relay, relay_peers=tuple(relay_peers),
                 can_create_halls=can_create_halls,
                 identity_model=identity_model,
                 identity_familia=identity_familia)
    return b, eng, seen


def test_liaison_tools_absent_without_flag(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="X", hermes_review=False)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert not any(n.startswith("conscio.review") for n in names)
        assert "conscio_reviews" not in names and "conscio_poll_reviews" not in names
    finally:
        seen.close()
        eng.close()


def test_reviewer_tools_present_without_act(tmp_path):
    """E3: the advertised surface is the DISPATCHER (conscio_review); the
    individual names stay as dispatch-only aliases. poll stays gated on act.
    Migrated from the pre-E3 contract, not skipped."""
    b, eng, seen = _bind(tmp_path, instance_id="X", hermes_review=True,
                         act_flag=False)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_review" in names
        for old in ("conscio_reviews", "conscio_review_approve",
                    "conscio_review_reject"):
            assert old not in names, old
            assert old in b._tools(), old                 # alias routes alive
        assert "conscio_poll_reviews" not in names        # needs --enable-act
        meta = b.conscio_meta()
        assert meta["hermes_review_enabled"] is True
    finally:
        seen.close()
        eng.close()


def test_reviews_lists_and_dedups_by_fp(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="HERMES", liaison_db=db)
    try:
        # two request rows, same fp (a duplicate) + one distinct fp
        for _ in range(2):
            mailbox.send(db, from_instance="CLAUDE", to_instance="HERMES",
                         type="review_request",
                         payload=review.build_request(
                             fp="fp1", tool="echo", args={"x": 1}, goal="g",
                             verdict="PASS", rationale="r"))
        mailbox.send(db, from_instance="CLAUDE", to_instance="HERMES",
                     type="review_request",
                     payload=review.build_request(
                         fp="fp2", tool="rm", args={}, goal="g2",
                         verdict="PASS", rationale="r2"))
        rows = b._reviews({})
        assert sorted(r["fp"] for r in rows) == ["fp1", "fp2"]   # deduped
        assert {r["from_instance"] for r in rows} == {"CLAUDE"}
    finally:
        seen.close()
        eng.close()


def test_review_approve_emits_verdict_and_marks_request_read(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="HERMES", liaison_db=db)
    _publish("CLAUDE", "HERMES")
    try:
        mailbox.send(db, from_instance="CLAUDE", to_instance="HERMES",
                     type="review_request",
                     payload=review.build_request(
                         fp="fp1", tool="echo", args={}, goal="g",
                         verdict="PASS", rationale="r"))
        res = b._review_approve({"fp": "fp1"})
        assert res["ok"] is True and res["to"] == "CLAUDE"
        # verdict landed in CLAUDE's inbox
        v = mailbox.inbox(db, "CLAUDE", types=["review_verdict"])
        assert v and v[0]["payload"]["decision"] == "approve"
        # request marked read on HERMES side
        assert b._reviews({}) == []
    finally:
        seen.close()
        eng.close()


def test_review_reject_emits_reject_verdict(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="HERMES", liaison_db=db)
    _publish("CLAUDE", "HERMES")
    try:
        mailbox.send(db, from_instance="CLAUDE", to_instance="HERMES",
                     type="review_request",
                     payload=review.build_request(
                         fp="fpz", tool="rm", args={}, goal="g",
                         verdict="PASS", rationale="r"))
        res = b._review_reject({"fp": "fpz", "reason": "too risky"})
        assert res["ok"] is True
        v = mailbox.inbox(db, "CLAUDE", types=["review_verdict"])
        assert v[0]["payload"] == {"fp": "fpz", "decision": "reject",
                                   "reason": "too risky"}
    finally:
        seen.close()
        eng.close()


def test_review_approve_unknown_fp(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="HERMES")
    try:
        assert b._review_approve({"fp": "ghost"}) == {"ok": False,
                                                      "reason": "unknown_fp"}
    finally:
        seen.close()
        eng.close()


# ── proposer side (auto-publish + poll) ──

class _PassSkeptic:
    """Force the host-act audit to PASS so propose() reaches pending — the
    liaison wiring under test is independent of the real Skeptic/adapter."""
    def audit(self, proposal, goal_text="", tool_doc=""):
        return SimpleNamespace(passed=True, verdict="PASS", reasons=[],
                               risk_flags=[], confidence=0.9)


_HR_MANIFEST = [{"name": "echo",
                 "params": {"msg": {"type": "str", "required": True}},
                 "risk": "low", "approval_policy": "hermes_review",
                 "description": "echo"}]
_INTENT = {"tool": "echo", "args": {"msg": "hi"}, "rationale": "r",
           "expected_outcome": "ok", "goal": "g"}


def _proposer(tmp_path, storage, *, instance_id, reviewers, liaison_db):
    _publish(instance_id, *reviewers)     # a peer with no card is unreachable
    eng = ConsciousnessEngine("glm-5.1", storage_path=storage)
    eng.attach_adapter(MockAdapter(script=[]))
    eng.wake()                                       # _gate() needs awake
    assert eng.enable_host_act(_HR_MANIFEST) is True
    eng.host_act.skeptic = _PassSkeptic()            # decouple from real skeptic
    seen = SeenStore(storage / "mcp_seen.db")
    b = Bindings(eng, seen, adapter_name="mock", workspace_id="ws",
                 act_flag=True, hermes_review=True, reviewers=tuple(reviewers),
                 self_instance_id=instance_id, liaison_db=liaison_db)
    return b, eng, seen


def test_propose_hermes_review_publishes_one_request_per_reviewer(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B", "C"), liaison_db=db)
    _publish("B", "C")
    try:
        res = b._act({"intent": _INTENT})
        assert res["status"] == "pending_approval"
        assert len(mailbox.inbox(db, "B", types=["review_request"])) == 1
        assert len(mailbox.inbox(db, "C", types=["review_request"])) == 1
    finally:
        seen.close()
        eng.close()


def test_flag_off_no_publish(tmp_path):
    db = tmp_path / "liaison.db"
    eng = ConsciousnessEngine("glm-5.1", storage_path=tmp_path / "A")
    eng.attach_adapter(MockAdapter(script=[]))
    eng.wake()
    eng.enable_host_act(_HR_MANIFEST)
    eng.host_act.skeptic = _PassSkeptic()
    seen = SeenStore(tmp_path / "A" / "mcp_seen.db")
    b = Bindings(eng, seen, adapter_name="mock", workspace_id="ws",
                 act_flag=True, hermes_review=False, reviewers=("B",),
                 self_instance_id="A", liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        assert mailbox.inbox(db, "B") == []           # nothing published
    finally:
        seen.close()
        eng.close()


def test_poll_applies_approve_and_returns_packet(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        req = mailbox.inbox(db, "B", types=["review_request"])[0]
        fp = req["payload"]["fp"]
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=fp, decision="approve",
                                                  reason=""))
        applied = b._poll_reviews({})
        assert len(applied) == 1
        assert applied[0]["decision"] == "approve"
        assert applied[0]["status"] == "executable"
        assert applied[0]["packet"]["tool"] == "echo"
    finally:
        seen.close()
        eng.close()


def test_poll_applies_reject(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        fp = mailbox.inbox(db, "B", types=["review_request"])[0]["payload"]["fp"]
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=fp, decision="reject",
                                                  reason="no"))
        applied = b._poll_reviews({})
        assert applied[0]["decision"] == "reject"
        assert applied[0]["status"] == "rejected"
    finally:
        seen.close()
        eng.close()


def test_poll_ignores_non_allowlisted_verdict(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        fp = mailbox.inbox(db, "B", types=["review_request"])[0]["payload"]["fp"]
        # a stranger (not in reviewers) tries to approve
        mailbox.send(db, from_instance="EVIL", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=fp, decision="approve",
                                                  reason=""))
        assert b._poll_reviews({}) == []              # ignored
        # the act is still pending (not released)
        assert b.engine.host_act.pending(10)[0]["status"] == "proposed"
    finally:
        seen.close()
        eng.close()


def test_poll_ignores_foreign_proposer_fp(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        # allowlisted reviewer, but fp computed for a DIFFERENT proposer
        bogus = review.fingerprint("OTHER", "g", "echo", {"msg": "hi"}, 1)
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=bogus, decision="approve",
                                                  reason=""))
        assert b._poll_reviews({}) == []              # no local match
    finally:
        seen.close()
        eng.close()


def test_poll_replay_is_noop(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        b._act({"intent": _INTENT})
        fp = mailbox.inbox(db, "B", types=["review_request"])[0]["payload"]["fp"]
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=fp, decision="approve",
                                                  reason=""))
        assert len(b._poll_reviews({})) == 1          # first apply
        # replay the same verdict (re-send a fresh row, same fp)
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_verdict",
                     payload=review.build_verdict(fp=fp, decision="approve",
                                                  reason=""))
        assert b._poll_reviews({}) == []              # row no longer 'proposed'
    finally:
        seen.close()
        eng.close()


def test_two_instance_end_to_end(tmp_path):
    """The review round trip with the v4.5.4 topology: A and B own separate
    dbs, so request and verdict only arrive through the spool. A shared db
    would let this pass while production never delivered anything."""
    db_a, db_b = tmp_path / "a.db", tmp_path / "b.db"
    A, engA, seenA = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                               reviewers=("B",), liaison_db=db_a)
    B, engB, seenB = _bind(tmp_path, instance_id="B", hermes_review=True,
                           liaison_db=db_b, storage=tmp_path / "B")
    try:
        A._act({"intent": _INTENT})                   # A proposes
        assert B._reviews({}) == []                    # nothing ingested yet
        assert spool.ingest(db_b, "B") == 1            # B pulls its own spool
        reqs = B._reviews({})                          # B sees it
        assert len(reqs) == 1
        B._review_approve({"fp": reqs[0]["fp"]})       # B approves
        assert A._poll_reviews({}) == []               # verdict still in spool
        assert spool.ingest(db_a, "A") == 1
        applied = A._poll_reviews({})                  # A applies
        assert applied[0]["status"] == "executable"
    finally:
        seenA.close()
        engA.close()
        seenB.close()
        engB.close()


def test_publish_failure_is_best_effort(tmp_path, monkeypatch, capsys):
    db = tmp_path / "liaison.db"
    b, eng, seen = _proposer(tmp_path, tmp_path / "A", instance_id="A",
                             reviewers=("B",), liaison_db=db)
    try:
        import conscio.mcp.server as srv

        def boom(*a, **k):
            raise OSError("disk full")
        monkeypatch.setattr(srv.mailbox, "send", boom)
        res = b._act({"intent": _INTENT})             # publish raises internally
        assert res["status"] == "pending_approval"    # act survives; ledgered
        assert "publish failed" in capsys.readouterr().err
    finally:
        seen.close()
        eng.close()


def test_argparser_accepts_liaison_flags():
    from conscio.mcp.server import _arg_parser
    ns = _arg_parser().parse_args(
        ["--enable-hermes-review", "--reviewer", "B", "--reviewer", "C",
         "--liaison-db", "/tmp/x.db"])
    assert ns.enable_hermes_review is True
    assert ns.reviewer == ["B", "C"]
    assert ns.liaison_db == "/tmp/x.db"


# ── v2.6.1 Relay ──

def test_relay_tools_absent_without_flag(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="X", hermes_review=False,
                         relay=False)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert not any(n.startswith("conscio.relay") for n in names)
        assert b.conscio_meta()["relay_enabled"] is False
    finally:
        seen.close()
        eng.close()


def test_relay_tools_present_with_flag(tmp_path):
    """E3: the advertised surface is the DISPATCHER, not the five tools —
    the individual names live as dispatch-only aliases (route alive, never
    advertised). Migrated from the pre-E3 contract, not skipped."""
    b, eng, seen = _bind(tmp_path, instance_id="X", hermes_review=False,
                         relay=True, relay_peers=("B",))
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_relay" in names
        for old in ("conscio_relay_send", "conscio_relay_inbox",
                    "conscio_relay_read", "conscio_relay_broadcast",
                    "conscio_relay_peers"):
            assert old not in names, old
        # alias: each old name still DISPATCHES through _tools()
        for old in ("conscio_relay_send", "conscio_relay_inbox",
                    "conscio_relay_read", "conscio_relay_broadcast",
                    "conscio_relay_peers"):
            assert old in b._tools(), old
        meta = b.conscio_meta()
        assert meta["relay_enabled"] is True
        assert meta["relay_peers_count"] == 1
    finally:
        seen.close()
        eng.close()


def test_relay_send_rejects_non_peer(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    try:
        r = b._relay_send({"to": "Z", "type": "note", "payload": {}})
        assert r["ok"] is False and "unknown peer" in r["reason"]
        assert mailbox.inbox(db, "Z", unread_only=False) == []   # nothing sent
    finally:
        seen.close()
        eng.close()


def test_relay_send_rejects_reserved_type(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",),
                         liaison_db=tmp_path / "liaison.db")
    try:
        r = b._relay_send({"to": "B", "type": "review_request", "payload": {}})
        assert r["ok"] is False and "reserved" in r["reason"]
    finally:
        seen.close()
        eng.close()


def test_relay_send_rejects_oversize(tmp_path):
    from conscio.liaison import relay as rl
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",),
                         liaison_db=tmp_path / "liaison.db")
    try:
        big = {"x": "a" * (rl.MAX_PAYLOAD_BYTES + 1)}
        r = b._relay_send({"to": "B", "type": "note", "payload": big})
        assert r["ok"] is False and "exceeds" in r["reason"]
    finally:
        seen.close()
        eng.close()


def test_relay_two_instance_end_to_end(tmp_path):
    """v4.5.4: each agent owns its db — the message crosses through the spool,
    never by one agent writing into the other's database."""
    db_a, db_b = tmp_path / "a.db", tmp_path / "b.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", hermes_review=False,
                           relay=True, relay_peers=("B",), liaison_db=db_a,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", hermes_review=False,
                           relay=True, relay_peers=("A",), liaison_db=db_b,
                           storage=tmp_path / "B")
    _publish("A", "B")
    try:
        r = A._relay_send({"to": "B", "type": "note", "payload": {"hi": 1}})
        assert r["ok"] is True
        assert mailbox.inbox(db_b, "B", unread_only=True) == []   # not yet
        assert spool.ingest(db_b, "B") == 1        # B ingests its own spool
        msgs = B._relay_inbox({})["messages"]
        assert len(msgs) == 1
        assert msgs[0]["from_instance"] == "A"
        assert msgs[0]["type"] == "note"
        assert msgs[0]["payload"].get("hi") == 1   # _meta envelope presente
        assert B._relay_read({"ids": [msgs[0]["id"]]})["marked"] == 1
        assert B._relay_inbox({})["messages"] == []           # consumed
    finally:
        seenA.close()
        engA.close()
        seenB.close()
        engB.close()


def test_relay_inbox_ignores_non_peer_and_marks_read(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    try:
        mailbox.send(db, from_instance="STRANGER", to_instance="A",
                     type="note", payload={"x": 1})
        assert b._relay_inbox({})["messages"] == []           # not surfaced
        assert mailbox.inbox(db, "A", unread_only=True) == []  # marked read
    finally:
        seen.close()
        eng.close()


def test_relay_inbox_excludes_reserved_and_leaves_untouched(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    try:
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="review_request", payload={"fp": "x"})
        assert b._relay_inbox({})["messages"] == []           # excluded
        # review channel still sees it UNREAD (relay never touched it)
        assert len(mailbox.inbox(db, "A", types=["review_request"],
                                 unread_only=True)) == 1
    finally:
        seen.close()
        eng.close()


def test_relay_send_invokes_purge_best_effort(tmp_path, monkeypatch, capsys):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    try:
        import conscio.mcp.server as srv
        calls = {"n": 0}

        def boom(*a, **k):
            calls["n"] += 1
            raise OSError("disk full")
        monkeypatch.setattr(srv.mailbox, "purge_read", boom)
        _publish("B")
        r = b._relay_send({"to": "B", "type": "note", "payload": {}})
        assert r["ok"] is True                # send survives a purge failure
        assert calls["n"] == 1                # purge attempted
        assert "purge failed" in capsys.readouterr().err
    finally:
        seen.close()
        eng.close()


def test_relay_read_filters_non_int_ids(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    try:
        mid = mailbox.send(db, from_instance="B", to_instance="A",
                           type="note", payload={})
        # bools/floats/strings dropped; only the genuine int applies
        res = b._relay_read({"ids": [True, 1.0, "x", mid]})
        assert res["marked"] == 1
    finally:
        seen.close()
        eng.close()


# ── v2.8.2 "Conversation": relay_broadcast fan-out tool ───────────────────────

def test_relay_broadcast_tool_present_with_flag(tmp_path):
    """E3: broadcast is routed by the dispatcher; its name is a dispatch-only
    alias, not an advertised tool. Migrated from the pre-E3 contract."""
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "C"))
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_relay" in names
        assert "conscio_relay_broadcast" not in names     # alias, not advertised
        assert "conscio_relay_broadcast" in b._tools()    # route alive
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_absent_without_flag(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=False)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_relay_broadcast" not in names
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_fans_out_to_all_peers(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "C"), liaison_db=db)
    _publish("B", "C")
    try:
        r = b._relay_broadcast({"type": "note", "payload": {"hi": 1}})
        assert r["ok"] is True
        assert {s["to"] for s in r["sent"]} == {"B", "C"}
        assert r["errors"] == []
        for peer in ("B", "C"):                  # each one reads its own db
            db_peer = tmp_path / f"{peer}.db"
            assert spool.ingest(db_peer, peer) == 1
            assert mailbox.inbox(db_peer, peer)[0]["payload"].get("hi") == 1
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_rejects_reserved_type_for_all(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "C"), liaison_db=db)
    try:
        r = b._relay_broadcast({"type": "review_request", "payload": {}})
        assert r["sent"] == []
        assert {e["to"] for e in r["errors"]} == {"B", "C"}
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_empty_allowlist(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=(), liaison_db=db)
    try:
        r = b._relay_broadcast({"type": "note", "payload": {"x": 1}})
        assert r == {"ok": True, "sent": [], "errors": [], "skipped": []}
    finally:
        seen.close()
        eng.close()


def test_argparser_accepts_relay_flags():
    from conscio.mcp.server import _arg_parser
    ns = _arg_parser().parse_args(
        ["--enable-relay", "--relay-peer", "B", "--relay-peer", "C"])
    assert ns.enable_relay is True
    assert ns.relay_peer == ["B", "C"]


def test_relay_broadcast_send_failure_isolated(tmp_path, monkeypatch):
    # docstring contract: a failing peer never aborts the rest
    import sqlite3 as _sq

    import conscio.mcp.server as srv
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "C"), liaison_db=db)
    try:
        real = srv.mailbox.send

        def flaky(dbp, *, from_instance, to_instance, type, payload,
                  identity=None, hall=None):
            if to_instance == "B":
                raise _sq.OperationalError("database is locked")
            return real(dbp, from_instance=from_instance,
                        to_instance=to_instance, type=type, payload=payload,
                        identity=identity, hall=hall)

        monkeypatch.setattr(srv.mailbox, "send", flaky)
        _publish("B", "C")
        r = b._relay_broadcast({"type": "note", "payload": {"hi": 1}})
        assert {s["to"] for s in r["sent"]} == {"C"}     # C still delivered
        assert {e["to"] for e in r["errors"]} == {"B"}   # B reported, not fatal
    finally:
        seen.close()
        eng.close()


# ── Ato 3 (v4.5): identity do runtime + peers dinâmicos ─────────────────

def test_identity_empty_without_self_instance(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="")
    try:
        b.identity_model = "opus-5"
        b.identity_familia = "claude"
        b.identity_runtime = "claude-code/2.x"
        b.identity_papel = "executor"
        # self_instance_id vazio → sem envelope (não inventa identidade)
        assert b._identity() == {}
    finally:
        seen.close()
        eng.close()


def test_identity_builds_envelope(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="inst-abc")
    try:
        b.identity_model = "gemini-2.5"
        b.identity_familia = "gemini"
        b.identity_runtime = "claude-code/2.x"
        b.identity_papel = "executor"
        env = b._identity()
        assert env["id"] == "inst-abc"
        assert env["modelo"] == "gemini-2.5"
        assert env["familia"] == "gemini"
        assert env["papel"] == "executor"
    finally:
        seen.close()
        eng.close()


def test_resolve_peers_falls_back_to_static(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="X", relay=True,
                         relay_peers=("A", "B"))
    try:
        # sem registro → fallback para --relay-peer
        assert b._resolve_peers() == {"A", "B"}
    finally:
        seen.close()
        eng.close()


def test_resolve_peers_uses_the_directory_and_excludes_self(tmp_path):
    """v4.5.4: a fonte é o diretório compartilhado, não o registro local — que
    só conhece quem já escreveu no MEU banco, ou seja, nunca um estreante. Sem
    filtro de vivacidade: o spool é arquivo, peer parado segue endereçável."""
    from conscio.liaison import directory
    b, eng, seen = _bind(tmp_path, instance_id="X", relay=True,
                         liaison_db=tmp_path / "liaison.db")
    try:
        for cid, age in (("X", 0), ("alive-1", 0), ("alive-2", 0),
                         ("quiet-peer", 10 * 3600)):
            directory.publish({"instance_id": cid, "spool": f"s/{cid}",
                               "url": "", "updated_at": time.time() - age})
        peers = b._resolve_peers()
        assert "X" not in peers                 # exclui o próprio
        assert {"alive-1", "alive-2"} <= peers
        assert "quiet-peer" in peers            # calado ≠ inalcançável
    finally:
        seen.close()
        eng.close()


def test_relay_peer_flag_wins_over_the_directory(tmp_path):
    """Nomear peers vira restrição deliberada: o humano que digitou --relay-peer
    quer aquele conjunto, mesmo com o diretório cheio."""
    from conscio.liaison import directory
    b, eng, seen = _bind(tmp_path, instance_id="X", relay=True,
                         relay_peers=("B", "X"),
                         liaison_db=tmp_path / "liaison.db")
    try:
        directory.publish({"instance_id": "outsider", "spool": "s",
                           "url": "", "updated_at": time.time()})
        peers = b._resolve_peers()
        assert peers == {"B"}                   # "X" é o próprio; sai
        assert "outsider" not in peers
    finally:
        seen.close()
        eng.close()


def test_relay_send_stamps_identity_envelope(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="X", relay=True,
                         relay_peers=("B",), liaison_db=tmp_path / "liaison.db")
    try:
        b.identity_model = "m-1"
        b.identity_familia = "fam"
        _publish("B")
        r = b._relay_send({"to": "B", "type": "chat", "payload": {"text": "oi"}})
        assert r["ok"] is True
        rows = mailbox.inbox(b.liaison_db, "B")          # my outbox copy
        meta = rows[0]["payload"].get("_meta")
        assert meta is not None
        assert meta["from"]["modelo"] == "m-1"
        # and the same envelope crosses the wire — an identity that only
        # exists in the sender's copy tells the recipient nothing
        db_b = tmp_path / "b.db"
        assert spool.ingest(db_b, "B") == 1
        wire = mailbox.inbox(db_b, "B")[0]["payload"]["_meta"]
        assert wire["from"]["modelo"] == "m-1"
    finally:
        seen.close()
        eng.close()


def test_relay_send_without_identity_fields_has_id_only(tmp_path):
    # self_instance_id existe → envelope SEMPRE sai, mas com campos de modelo
    # vazios quando o runtime não os forneceu (id é a âncora mínima).
    b, eng, seen = _bind(tmp_path, instance_id="X", relay=True,
                         relay_peers=("B",), liaison_db=tmp_path / "liaison.db")
    _publish("B")
    try:
        r = b._relay_send({"to": "B", "type": "chat", "payload": {"text": "oi"}})
        assert r["ok"] is True
        rows = mailbox.inbox(b.liaison_db, "B")
        meta = rows[0]["payload"].get("_meta")
        assert meta is not None
        assert meta["from"]["id"] == "X"
        assert meta["from"]["modelo"] == ""
    finally:
        seen.close()
        eng.close()


# ── Ato 4 (v4.5): Agent's Hall tools ─────────────────────────────────────

def test_hall_tools_absent_without_flag(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=True,
                         can_create_halls=False)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert not any(n.startswith("conscio_hall") for n in names)
    finally:
        seen.close()
        eng.close()


def test_hall_tools_present_with_flag(tmp_path):
    """E3: the advertised surface is the DISPATCHER (conscio_hall); the seven
    individual names stay as dispatch-only aliases. Migrated from the pre-E3
    contract, not skipped."""
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=True,
                         can_create_halls=True)
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_hall" in names
        for old in ("conscio_hall_create", "conscio_hall_list",
                    "conscio_hall_join", "conscio_hall_leave",
                    "conscio_hall_members", "conscio_hall_send",
                    "conscio_hall_manage"):
            assert old not in names, old
            assert old in b._tools(), old                 # alias routes alive
    finally:
        seen.close()
        eng.close()


def test_every_advertised_tool_is_dispatchable(tmp_path):
    """No tool may be listed and then answer 'method not found'.

    Halls delivered through the relay mailbox but were advertised on the halls
    flag alone, so --can-create-halls without --enable-relay published seven
    tools that dispatch never registered.
    """
    for relay in (True, False):
        b, eng, seen = _bind(tmp_path, instance_id="A", relay=relay,
                             can_create_halls=True)
        try:
            advertised = {t["name"] for t in b.tool_defs()}
            assert advertised <= set(b._tools()), (
                f"advertised but not dispatchable (relay={relay}): "
                f"{sorted(advertised - set(b._tools()))}")
        finally:
            seen.close()
            eng.close()


def test_halls_without_relay_are_off_not_broken(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=False,
                         can_create_halls=True)
    try:
        assert b.can_create_halls is False      # derived, not as passed
        assert b.halls_need_relay is True       # and the reason is legible
        assert not any(n.startswith("conscio_hall") for n in
                       {t["name"] for t in b.tool_defs()})
    finally:
        seen.close()
        eng.close()


def test_hall_create_and_owner_joins(tmp_path):
    from conscio.liaison import directory
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=True,
                         can_create_halls=True, liaison_db=db)
    try:
        r = b._hall_create({"name": "Squad QA"})
        assert r["ok"] is True
        hid = r["hall"]["hall_id"]
        assert hid == "a--squad-qa"
        # dono virou membro pelo cartão dele, não por linha em roster
        assert directory.get("A")["halls"] == [hid]
        assert b._hall_members({"hall_id": hid})["members"][0]["function"] \
            == "leader"
    finally:
        seen.close()
        eng.close()


def test_hall_create_requires_flag(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=True,
                         can_create_halls=False, liaison_db=tmp_path / "l.db")
    try:
        r = b._hall_create({"name": "squad"})
        assert r["ok"] is False
    finally:
        seen.close()
        eng.close()


def test_hall_create_duplicate_and_bad_name_are_explained(tmp_path):
    b, eng, seen = _bind(tmp_path, instance_id="A", relay=True,
                         can_create_halls=True, liaison_db=tmp_path / "l.db")
    try:
        assert b._hall_create({"name": "team"})["ok"] is True
        dup = b._hall_create({"name": "team"})
        assert dup["ok"] is False and "duplicado" in dup["motivo"]
        long = b._hall_create({"name": "n" * 90})
        assert long["ok"] is False and "hall_id" in long["motivo"]
    finally:
        seen.close()
        eng.close()


def test_hall_send_fanout(tmp_path):
    db_a, db_b = tmp_path / "a.db", tmp_path / "b.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", relay=True,
                           can_create_halls=True, liaison_db=db_a,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", relay=True,
                           can_create_halls=True, liaison_db=db_b,
                           storage=tmp_path / "B")
    try:
        r = A._hall_create({"name": "team"})
        hid = r["hall"]["hall_id"]
        A._hall_join({"hall_id": hid})       # A já está (dono)
        # B entra no mesmo hall (via _hall_join — precisa saber o hid)
        bj = B._hall_join({"hall_id": hid})
        assert bj["ok"] is True
        sent = A._hall_send({"hall_id": hid, "type": "chat",
                             "payload": {"text": "oi elenco"}})
        assert sent["delivered"] == 1        # B recebeu, A (remetente) não
        assert spool.ingest(db_b, "B") == 1  # entrega real, não cópia do autor
        inbox_B = mailbox.inbox(db_b, "B")
        assert len(inbox_B) == 1
        assert inbox_B[0]["payload"].get("text") == "oi elenco"
        # a mensagem diz de qual hall veio (agente em vários halls)
        assert inbox_B[0]["payload"]["_meta"]["hall"]["id"] == hid
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


def test_hall_manage_assigns_function_and_addresses_it(tmp_path):
    db = tmp_path / "liaison.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "B")
    try:
        hid = A._hall_create({"name": "council"})["hall"]["hall_id"]
        B._hall_join({"hall_id": hid})
        assert A._hall_manage({"action": "set_function", "hall_id": hid,
                               "instance_id": "B",
                               "function": "reviewer"})["ok"] is True
        # convocar só o revisor entrega ao revisor
        assert A._hall_send({"hall_id": hid, "type": "chat", "payload": {},
                             "function": "reviewer"})["delivered"] == 1
        assert A._hall_send({"hall_id": hid, "type": "chat", "payload": {},
                             "function": "security"})["delivered"] == 0
        # função desconhecida não vira executor calado
        bad = A._hall_manage({"action": "set_function", "hall_id": hid,
                              "instance_id": "B", "function": "reviewerr"})
        assert bad["ok"] is False and "unknown hall function" in bad["motivo"]
        # quem não é dono não manda
        denied = B._hall_manage({"action": "set_function", "hall_id": hid,
                                 "instance_id": "A", "function": "executor"})
        assert denied["ok"] is False and "owner" in denied["motivo"]
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


def test_hall_manage_imports_and_transfers(tmp_path):
    db = tmp_path / "liaison.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "B")
    try:
        B._ensure_registered()               # B publica o cartão, sem entrar
        hid = A._hall_create({"name": "team"})["hall"]["hall_id"]
        imp = A._hall_manage({"action": "import", "hall_id": hid,
                              "instance_ids": ["B"]})
        assert imp["ok"] is True and imp["imported"] == 1
        ids = [m["instance_id"]
               for m in A._hall_members({"hall_id": hid})["members"]]
        assert ids == ["A", "B"]             # entrou sem configurar nada
        assert A._hall_manage({"action": "transfer", "hall_id": hid,
                               "new_owner": "B"})["ok"] is True
        # agora quem manda é B
        assert B._hall_manage({"action": "set_function", "hall_id": hid,
                               "instance_id": "A",
                               "function": "tester"})["ok"] is True
        assert A._hall_manage({"action": "transfer", "hall_id": hid,
                               "new_owner": "A"})["ok"] is False
        assert A._hall_manage({"action": "nope", "hall_id": hid})["ok"] is False
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


def test_hall_leave_refuses_an_import(tmp_path):
    db = tmp_path / "liaison.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "B")
    try:
        B._ensure_registered()
        hid = A._hall_create({"name": "team"})["hall"]["hall_id"]
        A._hall_manage({"action": "import", "hall_id": hid,
                        "instance_ids": ["B"]})
        assert B._hall_leave({"hall_id": hid})["ok"] is True
        ids = [m["instance_id"]
               for m in A._hall_members({"hall_id": hid})["members"]]
        assert ids == ["A"]                  # recusa é do agente
        assert A._hall_send({"hall_id": hid, "type": "chat",
                             "payload": {}})["delivered"] == 0
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


def test_hall_list_shows_mine_and_owned(tmp_path):
    db = tmp_path / "liaison.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", relay=True,
                           can_create_halls=True, liaison_db=db,
                           storage=tmp_path / "B")
    try:
        hid = A._hall_create({"name": "team"})["hall"]["hall_id"]
        B._hall_create({"name": "other"})
        assert [h["hall_id"] for h in A._hall_list({})["halls"]] == [hid]
        B._hall_join({"hall_id": hid})
        assert {h["hall_id"] for h in B._hall_list({})["halls"]} == \
            {hid, "b--other"}
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


def test_relay_inbox_exposes_read_messages_when_unread_only_false(tmp_path):
    """Correcao (a): com o reactor rodando, tudo ja esta marcado lido na
    ingestao (reactor.py:173). O agente precisa poder enxergar as lidas por
    parametro — unread_only=False destrava a leitura que hoje devolve vazio."""
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    _publish("B")
    try:
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="note", payload={"n": 1})
        rid = mailbox.inbox(db, "A", unread_only=True)[0]["id"]
        mailbox.mark_read(db, [rid])          # simula o reactor na ingestao
        # default: unread_only=True -> vazio (comportamento atual)
        assert b._relay_inbox({})["messages"] == []
        # novo: unread_only=False -> expoe a lida
        msgs = b._relay_inbox({"unread_only": False})["messages"]
        assert [m["id"] for m in msgs] == [rid]
    finally:
        seen.close()
        eng.close()


def test_relay_inbox_since_id_filters_newer_only(tmp_path):
    """Correcao (a): since_id=N retorna apenas id > N — o executor le o
    incremento desde o seu cursor, sem reprocessar o que ja viu."""
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    _publish("B")
    try:
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="note", payload={"n": 1})
        first = mailbox.inbox(db, "A", unread_only=True)[0]["id"]
        mailbox.send(db, from_instance="B", to_instance="A",
                     type="note", payload={"n": 2})
        second = next(m for m in mailbox.inbox(db, "A", unread_only=True)
                      if m["id"] > first)["id"]
        got = b._relay_inbox({"since_id": first})["messages"]
        assert [m["id"] for m in got] == [second]
    finally:
        seen.close()
        eng.close()


# ── E3: dispatchers for RELAY / REVIEW / HALL (ADR-20260913133108-1fac9c) ──

def test_relay_dispatch_routes_all_ops(tmp_path):
    """E3: conscio_relay(op=...) roteia cada op para o mesmo handler das
    tools individuais. Um despachante, cinco verbos, zero diferenca de
    comportamento — o op e argumento, a rota e a tool. Dois dbs, como no
    e2e: o outbox de um agente nao entra na caixa do outro."""
    db_a, db_b = tmp_path / "a.db", tmp_path / "b.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db_a,
                         storage=tmp_path / "A")
    _publish("B")
    try:
        # send pelo despachante == send pela tool individual
        r = b._relay_dispatch({"op": "send", "to": "B",
                               "type": "note", "payload": {"hi": 1}})
        assert r["ok"] is True
        # inbox pelo despachante expoe a mesma surface (unread_only/since_id);
        # B ingere o PROPRIO spool e le com o PROPRIO despachante, como no e2e
        db2, eng2, seen2 = _bind(tmp_path, instance_id="B", hermes_review=False,
                                 relay=True, relay_peers=("A",), liaison_db=db_b,
                                 storage=tmp_path / "B")
        try:
            assert spool.ingest(db_b, "B") == 1   # B ingere o proprio spool
            inbox = db2._relay_dispatch({"op": "inbox"})["messages"]
            assert len(inbox) == 1 and inbox[0]["from_instance"] == "A"
        finally:
            seen2.close()
            eng2.close()
        # op desconhecido e erro com a lista de ops validas
        try:
            b._relay_dispatch({"op": "delete"})
            raise AssertionError("expected InvalidParams")
        except Exception as exc:
            assert "delete" in str(exc) and "send" in str(exc)
        # op ausente e erro
        try:
            b._relay_dispatch({})
            raise AssertionError("expected InvalidParams")
        except Exception:
            pass
    finally:
        seen.close()
        eng.close()


def test_relay_dispatch_advertised_instead_of_five_tools(tmp_path):
    """E3: tools/list anuncia o despachante, nao as 5 tools individuais.
    Os nomes individuais continuam no DISPATCH (alias, retrocompat) mas nao
    no anuncio — e isso que economiza os bytes da ADR."""
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",))
    try:
        names = {t["name"] for t in b.tool_defs()}
        assert "conscio_relay" in names
        for old in ("conscio_relay_send", "conscio_relay_inbox",
                    "conscio_relay_read", "conscio_relay_broadcast",
                    "conscio_relay_peers"):
            assert old not in names, old
        # alias: o nome antigo DESPACHA (rota viva), so nao e anunciado
        assert "conscio_relay_send" in b._tools()
    finally:
        seen.close()
        eng.close()


def test_hall_dispatch_routes_and_hides_seven_tools(tmp_path):
    """E3: conscio_hall(op=...) roteia os 7 verbos; os nomes individuais
    ficam como alias de dispatch, fora do tools/list."""
    db = tmp_path / "liaison.db"
    A, engA, seenA = _bind(tmp_path, instance_id="A", hermes_review=False,
                           relay=True, relay_peers=("B",), can_create_halls=True,
                           liaison_db=db, storage=tmp_path / "A")
    B, engB, seenB = _bind(tmp_path, instance_id="B", hermes_review=False,
                           relay=True, relay_peers=("A",), can_create_halls=True,
                           liaison_db=db, storage=tmp_path / "B")
    try:
        hid = A._hall_dispatch({"op": "create", "name": "team"})["hall"]["hall_id"]
        names_a = {t["name"] for t in A.tool_defs()}
        assert "conscio_hall" in names_a
        assert "conscio_hall_create" not in names_a
        assert "conscio_hall_create" in A._tools()      # alias vivo
        # send pelo despachante == fan-out da tool individual
        r = B._hall_dispatch({"op": "join", "hall_id": hid})
        assert r["ok"] is True
        members = A._hall_dispatch({"op": "members", "hall_id": hid})
        assert len(members["members"]) == 2
    finally:
        seenA.close(); engA.close(); seenB.close(); engB.close()


# ── v4.7.2: dormant peers — skipped by broadcast, warned on direct send ──────

def _publish_aged(cid, days, **kw):
    from conscio.liaison import directory
    card = {"instance_id": cid, "spool": str(directory.spool_dir(cid)),
            "url": "", "updated_at": time.time() - days * 86400}
    card.update(kw)
    directory.publish(card)


def test_relay_broadcast_skips_dormant_peer_and_says_so(tmp_path):
    """2026-09-24: 8fb1197f, dead for 20 days, still got every broadcast."""
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "C"), liaison_db=db)
    _publish("B")
    _publish_aged("C", days=20)
    try:
        r = b._relay_broadcast({"type": "note", "payload": {"hi": 1}})
        assert {s["to"] for s in r["sent"]} == {"B"}
        assert [s["to"] for s in r["skipped"]] == ["C"]
        assert "20d" in r["skipped"][0]["reason"]
        assert r["errors"] == []
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_never_skips_a_paired_remote(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("R",), liaison_db=db)
    _publish_aged("R", days=60, spool="", url="http://10.0.0.2:8789")
    try:
        r = b._relay_broadcast({"type": "note", "payload": {}})
        assert r["skipped"] == []
    finally:
        seen.close()
        eng.close()


def test_relay_send_to_dormant_peer_delivers_with_warning(tmp_path):
    """Named explicitly = honoured. But "ok" alone would read as "seen"."""
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("C",), liaison_db=db)
    _publish_aged("C", days=5)
    try:
        r = b._relay_send({"to": "C", "type": "note", "payload": {"x": 1}})
        assert r["ok"] is True
        assert "5d" in r["warning"]
        assert spool.ingest(tmp_path / "C.db", "C") == 1
    finally:
        seen.close()
        eng.close()


def test_relay_send_to_live_peer_has_no_warning(tmp_path):
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B",), liaison_db=db)
    _publish("B")
    try:
        r = b._relay_send({"to": "B", "type": "note", "payload": {}})
        assert r["ok"] is True and "warning" not in r
    finally:
        seen.close()
        eng.close()


def _remote_answers(monkeypatch, outcome):
    from conscio.liaison import relay_transport
    monkeypatch.setattr(relay_transport, "transport_post",
                        lambda url, msg, token, **kw: outcome)


def test_relay_send_to_silent_remote_parks_it_for_pull(tmp_path, monkeypatch):
    """2026-10-03: Jade's card points at a port nobody listens on; she pulls
    this host's spool instead. Every send failed "unreachable" while her
    mailbox sat one directory away."""
    from conscio.liaison import directory, relay_transport
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("J",), liaison_db=db)
    directory.publish({"instance_id": "J", "spool": "",
                       "url": "http://10.0.0.9:8788"})
    _remote_answers(monkeypatch, relay_transport.UNREACHABLE)
    try:
        r = b._relay_send({"to": "J", "type": "chat", "payload": {"t": "oi"}})
        assert r["ok"] is True
        assert "parked" in r["warning"] and "http://10.0.0.9:8788" in r["warning"]
        parked = list(directory.spool_dir("J").glob("*.json"))
        assert len(parked) == 1
        assert '"oi"' in parked[0].read_text(encoding="utf-8")
        # the outbox row exists only because the delivery was accepted (A4)
        assert [m["id"] for m in mailbox.thread(db, "A", "J")] == [r["id"]]
    finally:
        seen.close()
        eng.close()


def test_relay_broadcast_to_silent_remote_says_it_parked(tmp_path, monkeypatch):
    """The broadcast twin of the test above: a fan-out entry with only an id
    reads as "it arrived" while the message sits in this host's spool."""
    from conscio.liaison import directory, relay_transport
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("B", "J"), liaison_db=db)
    _publish("B")
    directory.publish({"instance_id": "J", "spool": "",
                       "url": "http://10.0.0.9:8788"})
    _remote_answers(monkeypatch, relay_transport.UNREACHABLE)
    try:
        r = b._relay_broadcast({"type": "note", "payload": {"x": 1}})
        by_peer = {s["to"]: s for s in r["sent"]}
        assert set(by_peer) == {"B", "J"}
        assert "parked" in by_peer["J"]["warning"]
        assert "http://10.0.0.9:8788" in by_peer["J"]["warning"]
        assert "warning" not in by_peer["B"]
        assert len(list(directory.spool_dir("J").glob("*.json"))) == 1
    finally:
        seen.close()
        eng.close()


def test_relay_send_to_rejecting_remote_fails_and_parks_nothing(tmp_path,
                                                                 monkeypatch):
    """A bridge that ANSWERS no (bad token) is alive and misconfigured — that
    must surface, not be papered over by parking."""
    from conscio.liaison import directory, relay_transport
    db = tmp_path / "liaison.db"
    b, eng, seen = _bind(tmp_path, instance_id="A", hermes_review=False,
                         relay=True, relay_peers=("J",), liaison_db=db)
    directory.publish({"instance_id": "J", "spool": "",
                       "url": "http://10.0.0.9:8788"})
    _remote_answers(monkeypatch, relay_transport.REJECTED)
    try:
        r = b._relay_send({"to": "J", "type": "chat", "payload": {}})
        assert r["ok"] is False and "unreachable" in r["reason"]
        assert list(directory.spool_dir("J").glob("*.json")) == []
    finally:
        seen.close()
        eng.close()
