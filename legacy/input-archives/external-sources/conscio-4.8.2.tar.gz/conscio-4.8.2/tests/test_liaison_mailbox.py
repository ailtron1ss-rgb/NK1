# tests/test_liaison_mailbox.py
from conscio.liaison import mailbox


def test_send_then_inbox_roundtrip(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="review_request",
                 payload={"fp": "x", "tool": "echo"})
    rows = mailbox.inbox(db, "B")
    assert len(rows) == 1
    assert rows[0]["from_instance"] == "A"
    assert rows[0]["type"] == "review_request"
    assert rows[0]["payload"] == {"fp": "x", "tool": "echo"}   # parsed, not str
    assert rows[0]["read_ts"] is None


def test_inbox_is_directed_only(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="review_request",
                 payload={"fp": "1"})
    mailbox.send(db, from_instance="A", to_instance="C", type="review_request",
                 payload={"fp": "2"})
    assert [r["payload"]["fp"] for r in mailbox.inbox(db, "B")] == ["1"]
    assert [r["payload"]["fp"] for r in mailbox.inbox(db, "C")] == ["2"]


def test_inbox_filters_by_type_and_unread(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="review_request",
                 payload={"fp": "r"})
    mailbox.send(db, from_instance="A", to_instance="B", type="review_verdict",
                 payload={"fp": "v"})
    only_v = mailbox.inbox(db, "B", types=["review_verdict"])
    assert [r["type"] for r in only_v] == ["review_verdict"]


def test_mark_read_flips_only_named_unread_rows(tmp_path):
    db = tmp_path / "liaison.db"
    mid = mailbox.send(db, from_instance="A", to_instance="B",
                       type="review_request", payload={"fp": "1"})
    assert mailbox.mark_read(db, [mid]) == 1
    assert mailbox.inbox(db, "B", unread_only=True) == []        # now hidden
    assert len(mailbox.inbox(db, "B", unread_only=False)) == 1   # still present
    assert mailbox.mark_read(db, [mid]) == 0                     # idempotent


def test_per_row_read_ts_independence(tmp_path):
    db = tmp_path / "liaison.db"
    m1 = mailbox.send(db, from_instance="A", to_instance="B",
                      type="review_request", payload={"fp": "1"})
    mailbox.send(db, from_instance="A", to_instance="B",
                 type="review_request", payload={"fp": "2"})
    mailbox.mark_read(db, [m1])
    left = mailbox.inbox(db, "B", unread_only=True)
    assert [r["payload"]["fp"] for r in left] == ["2"]


def test_missing_db_inbox_returns_empty(tmp_path):
    assert mailbox.inbox(tmp_path / "nope.db", "B") == []
    assert mailbox.mark_read(tmp_path / "nope.db", [1]) == 0


def test_corrupt_db_inbox_returns_empty(tmp_path):
    db = tmp_path / "liaison.db"
    db.write_bytes(b"this is not a sqlite database")
    assert mailbox.inbox(db, "B") == []


def test_first_send_creates_db(tmp_path):
    db = tmp_path / "sub" / "liaison.db"
    assert not db.exists()
    mailbox.send(db, from_instance="A", to_instance="B", type="review_request",
                 payload={})
    assert db.exists()


def test_purge_read_deletes_old_read(tmp_path):
    import time
    db = tmp_path / "liaison.db"
    old = time.time() - 8 * 86400
    mid = mailbox.send(db, from_instance="A", to_instance="B",
                       type="note", payload={}, ts=old)
    mailbox.mark_read(db, [mid], read_ts=old)
    assert mailbox.purge_read(db, 7.0) == 1
    assert mailbox.inbox(db, "B", unread_only=False) == []


def test_purge_read_keeps_recent_read(tmp_path):
    db = tmp_path / "liaison.db"
    mid = mailbox.send(db, from_instance="A", to_instance="B",
                       type="note", payload={})
    mailbox.mark_read(db, [mid])
    assert mailbox.purge_read(db, 7.0) == 0
    assert len(mailbox.inbox(db, "B", unread_only=False)) == 1


def test_purge_read_keeps_unread_old(tmp_path):
    import time
    db = tmp_path / "liaison.db"
    old = time.time() - 30 * 86400
    mailbox.send(db, from_instance="A", to_instance="B",
                 type="note", payload={}, ts=old)
    assert mailbox.purge_read(db, 7.0) == 0            # unread never deleted
    assert len(mailbox.inbox(db, "B", unread_only=True)) == 1


def test_purge_read_missing_db(tmp_path):
    assert mailbox.purge_read(tmp_path / "nope.db", 7.0) == 0


# ── v2.8.2 "Conversation": pure two-party thread() history reader ──────────────

def test_thread_both_directions_chronological(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="note",
                 payload={"t": "1"}, ts=100.0)
    mailbox.send(db, from_instance="B", to_instance="A", type="note",
                 payload={"t": "2"}, ts=200.0)
    mailbox.send(db, from_instance="A", to_instance="B", type="note",
                 payload={"t": "3"}, ts=300.0)
    rows = mailbox.thread(db, "A", "B")
    assert [r["payload"]["t"] for r in rows] == ["1", "2", "3"]   # oldest-first
    assert {r["from_instance"] for r in rows} == {"A", "B"}       # both dirs


def test_thread_is_symmetric(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="note",
                 payload={"t": "1"}, ts=100.0)
    mailbox.send(db, from_instance="B", to_instance="A", type="note",
                 payload={"t": "2"}, ts=200.0)
    assert mailbox.thread(db, "A", "B") == mailbox.thread(db, "B", "A")


def test_thread_excludes_third_party(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="note",
                 payload={"t": "ab"}, ts=100.0)
    mailbox.send(db, from_instance="A", to_instance="C", type="note",
                 payload={"t": "ac"}, ts=200.0)
    mailbox.send(db, from_instance="C", to_instance="B", type="note",
                 payload={"t": "cb"}, ts=300.0)
    assert [r["payload"]["t"] for r in mailbox.thread(db, "A", "B")] == ["ab"]


def test_thread_limit_keeps_newest(tmp_path):
    db = tmp_path / "liaison.db"
    for i in range(5):
        mailbox.send(db, from_instance="A", to_instance="B", type="note",
                     payload={"i": i}, ts=float(i))
    rows = mailbox.thread(db, "A", "B", limit=2)
    assert [r["payload"]["i"] for r in rows] == [3, 4]            # newest 2, asc


def test_thread_missing_db_returns_empty(tmp_path):
    assert mailbox.thread(tmp_path / "nope.db", "A", "B") == []


def test_thread_payload_parsed(tmp_path):
    db = tmp_path / "liaison.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="note",
                 payload={"x": 1}, ts=1.0)
    assert mailbox.thread(db, "A", "B")[0]["payload"] == {"x": 1}  # dict not str


# ── v2.10.0 "Initiative": broadcast outstanding-guard reader ──────────────────

def test_last_broadcast_ts_none_when_no_broadcast(tmp_path):
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "hi"})
    assert mailbox.last_broadcast_ts(db, "A") is None


def test_last_broadcast_ts_returns_newest_broadcast(tmp_path):
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "x", "broadcast": True}, ts=100.0)
    mailbox.send(db, from_instance="A", to_instance="C", type="chat",
                 payload={"text": "y", "broadcast": True}, ts=200.0)
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "z"}, ts=300.0)          # not a broadcast
    assert mailbox.last_broadcast_ts(db, "A") == 200.0


def test_last_broadcast_ts_filters_by_sender(tmp_path):
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="OTHER", to_instance="B", type="chat",
                 payload={"text": "x", "broadcast": True}, ts=500.0)
    assert mailbox.last_broadcast_ts(db, "A") is None


def test_last_broadcast_ts_missing_db_is_none(tmp_path):
    assert mailbox.last_broadcast_ts(tmp_path / "nope.db", "A") is None


# ── Envelope _meta.from (v4.5) ───────────────────────────────────────

def test_send_with_identity_stamps_meta_from(tmp_path):
    db = tmp_path / "m.db"
    ident = {"id": "A", "modelo": "opus-5", "familia": "claude",
             "runtime": "claude-code/2.x", "papel": "executor"}
    mid = mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                       payload={"text": "oi"}, identity=ident)
    rows = mailbox.inbox(db, "B")
    assert len(rows) == 1
    meta = rows[0]["payload"].get("_meta")
    assert meta is not None
    assert meta.get("from") == ident
    assert meta.get("id") == mid


def test_send_without_identity_has_no_meta(tmp_path):
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "oi"})
    rows = mailbox.inbox(db, "B")
    assert "_meta" not in rows[0]["payload"]


def test_send_identity_overrides_existing_meta(tmp_path):
    db = tmp_path / "m.db"
    # payload já veio com _meta do corpo (auto-declarado) — runtime vence
    ident = {"id": "B", "modelo": "gemini", "familia": "gemini"}
    mailbox.send(db, from_instance="B", to_instance="A", type="chat",
                 payload={"text": "x", "_meta": {"from": {"modelo": "fake"}}},
                 identity=ident)
    rows = mailbox.inbox(db, "A")
    assert rows[0]["payload"]["_meta"]["from"] == ident


def test_send_identity_preserves_text(tmp_path):
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "conteudo original"}, identity={"id": "A"})
    rows = mailbox.inbox(db, "B")
    assert rows[0]["payload"]["text"] == "conteudo original"


# ── Quarentena (v4.5) ────────────────────────────────────────────────

def test_inbox_quarantines_malformed_and_delivers_rest(tmp_path):
    import sqlite3
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "ok"})
    # injeta um row malformado direto no sqlite
    conn = sqlite3.connect(str(db))
    conn.execute(
        "INSERT INTO messages (from_instance,to_instance,type,payload,ts)"
        " VALUES (?,?,?,?,?)",
        ("A", "B", "chat", "{not valid json!!", 1.0))
    conn.commit(); conn.close()
    rows = mailbox.inbox(db, "B")
    txts = [r["payload"]["text"] for r in rows]
    assert "ok" in txts                      # o válido entrega
    q = mailbox.list_quarantine(db)
    assert len(q) == 1                       # o malformado foi p/ quarentena
    assert q[0]["payload_raw"] is not None


def test_thread_quarantines_malformed(tmp_path):
    import sqlite3
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "ok"})
    conn = sqlite3.connect(str(db))
    conn.execute(
        "INSERT INTO messages (from_instance,to_instance,type,payload,ts)"
        " VALUES (?,?,?,?,?)",
        ("B", "A", "chat", "{bad", 2.0))
    conn.commit(); conn.close()
    t = mailbox.thread(db, "A", "B")
    assert len(t) >= 1
    q = mailbox.list_quarantine(db)
    assert len(q) == 1


def test_purge_quarantine_removes_old(tmp_path):
    import sqlite3
    import time
    db = tmp_path / "m.db"
    mailbox.send(db, from_instance="A", to_instance="B", type="chat",
                 payload={"text": "seed"})   # cria schema (rw)
    conn = sqlite3.connect(str(db))
    conn.execute(
        "INSERT INTO quarantine (source_row, motivo, payload_raw, ts)"
        " VALUES (?,?,?,?)", (1, "payload_nao_json", "{bad", time.time() - 100.0))
    conn.commit(); conn.close()
    assert len(mailbox.list_quarantine(db)) == 1
    n = mailbox.purge_quarantine(db, older_than_days=0.0001)  # cutoff 8.64s; row 100s velho > cutoff → remove
    assert n == 1
    assert mailbox.list_quarantine(db) == []


# ── v4.5.4: liaison.db por agente + migração do legado ──────────────────

def test_db_in_space_is_single_source_of_path(tmp_path):
    assert mailbox.db_in_space(tmp_path) == tmp_path / "liaison.db"


def test_migrate_legacy_imports_only_my_threads(tmp_path):
    legacy = tmp_path / "legacy.db"
    mailbox.send(legacy, from_instance="a", to_instance="me", type="relay",
                 payload={"t": 1})
    mailbox.send(legacy, from_instance="me", to_instance="b", type="relay",
                 payload={"t": 2})
    mailbox.send(legacy, from_instance="x", to_instance="y", type="relay",
                 payload={"t": 3})
    new = tmp_path / "space" / "liaison.db"
    assert mailbox.migrate_legacy(new, legacy, "me") == 2
    got = {r["payload"]["t"] for r in mailbox.inbox(new, "me", unread_only=False)}
    assert got == {1}
    assert mailbox.thread(new, "me", "b") != []      # outbox veio junto
    # a linha alheia ficou no legado, não veio junto
    assert mailbox.inbox(new, "y", unread_only=False) == []


def test_migrate_legacy_is_noop_when_db_exists(tmp_path):
    legacy = tmp_path / "legacy.db"
    mailbox.send(legacy, from_instance="a", to_instance="me", type="relay",
                 payload={})
    new = tmp_path / "liaison.db"
    mailbox.send(new, from_instance="z", to_instance="me", type="relay",
                 payload={})           # db já existe
    assert mailbox.migrate_legacy(new, legacy, "me") == 0
    assert len(mailbox.inbox(new, "me", unread_only=False)) == 1


def test_migrate_legacy_survives_missing_legacy(tmp_path):
    assert mailbox.migrate_legacy(tmp_path / "n.db", tmp_path / "nope.db",
                                  "me") == 0
    assert not (tmp_path / "n.db").exists()   # não cria db por engano


def test_migrate_legacy_preserves_read_state(tmp_path):
    legacy = tmp_path / "legacy.db"
    mid = mailbox.send(legacy, from_instance="a", to_instance="me",
                       type="relay", payload={"t": 1})
    mailbox.mark_read(legacy, [mid])
    new = tmp_path / "space" / "liaison.db"
    assert mailbox.migrate_legacy(new, legacy, "me") == 1
    assert mailbox.inbox(new, "me") == []      # lida continua lida
    assert len(mailbox.inbox(new, "me", unread_only=False)) == 1


def _spool_in(db, *, frm="peer", mid=None, spool_id="s", text="oi"):
    meta = {"from": frm}
    if mid is not None:
        meta["id"] = mid
    return mailbox.insert_from_spool(db, from_instance=frm, to_instance="me",
                                     type="chat", spool_id=spool_id,
                                     payload={"text": text, "_meta": meta})


def test_replayed_envelope_lands_once(tmp_path):
    """A spool_id is minted per deposit, so re-POSTing a captured message to
    the bridge used to create a second file and a second inbox row. The
    sender's baked id is stable, so the second copy must be dropped."""
    db = tmp_path / "l.db"
    assert _spool_in(db, mid=42, spool_id="s1") is True
    assert _spool_in(db, mid=42, spool_id="s2") is False      # replay
    assert _spool_in(db, mid=42, spool_id="s3", text="tampered") is False
    assert len(mailbox.inbox(db, "me")) == 1


def test_dedupe_never_swallows_distinct_traffic(tmp_path):
    db = tmp_path / "l.db"
    _spool_in(db, mid=1, spool_id="a1")
    _spool_in(db, mid=2, spool_id="a2")               # next message, same peer
    _spool_in(db, frm="other", mid=1, spool_id="a3")  # id 1 of ANOTHER sender
    _spool_in(db, frm="old", mid=None, spool_id="a4")  # legacy, no _meta.id
    _spool_in(db, frm="old", mid=None, spool_id="a5")  # ...never deduped
    assert len(mailbox.inbox(db, "me")) == 5


# ── v4.7.2: waiting() — the read-only view `relay doctor` uses ───────────────

def test_waiting_lists_unconsumed_oldest_first_without_payload(tmp_path):
    db = tmp_path / "liaison.db"
    a = mailbox.send(db, from_instance="X", to_instance="me", type="chat",
                     payload={"text": "segredo"})
    b = mailbox.send(db, from_instance="Y", to_instance="me", type="note",
                     payload={})
    mailbox.send(db, from_instance="X", to_instance="other", type="chat",
                 payload={})
    mailbox.mark_read(db, [b])
    rows = mailbox.waiting(db, "me")
    assert [r["id"] for r in rows] == [a]
    assert rows[0]["from_instance"] == "X"
    assert "payload" not in rows[0]


def test_waiting_never_creates_the_db(tmp_path):
    db = tmp_path / "nope" / "liaison.db"
    assert mailbox.waiting(db, "me") == []
    assert not db.exists()
