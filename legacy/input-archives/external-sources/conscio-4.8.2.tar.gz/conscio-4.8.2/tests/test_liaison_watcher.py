# tests/test_liaison_watcher.py
"""Tests for conscio.liaison.watcher — native A2A relay watchdog.

Covers per-peer cursor, payload filtering, exit-code contract, and the
silent-when-idle cron contract. Origin: external relay_watch_hermes.py
replaced with a native module so peers/self_id have a single source of
truth and the cursor survives restarts in liaison.db itself.
"""
import sqlite3

import pytest

from conscio.liaison import mailbox
from conscio.liaison.watcher import (
    ExitCode,
    _load_state,
    poll_digest,
    tick_once,
)

# ── Fixtures ──────────────────────────────────────────────────────────

SELF = "self-1111"
PEER_A = "peer-aaaa"
PEER_B = "peer-bbbb"
STRANGER = "stranger-9999"


def _build_mailbox(db):
    """Populate a liaison.db with the standard cross-peer mix."""
    mailbox.send(db, from_instance=PEER_A, to_instance=SELF,
                 type="note", payload={"hi": 1})                 # id 1
    mailbox.send(db, from_instance=SELF, to_instance=PEER_A,
                 type="note", payload={"selfout": 1})            # id 2 (self)
    mailbox.send(db, from_instance=STRANGER, to_instance=SELF,
                 type="note", payload={"x": 1})                  # id 3
    mailbox.send(db, from_instance=PEER_A, to_instance=SELF,
                 type="review_request", payload={})              # id 4 reserved
    mailbox.send(db, from_instance=PEER_A, to_instance=SELF,
                 type="note", payload={"second": 2})             # id 5
    mailbox.send(db, from_instance=PEER_B, to_instance=SELF,
                 type="note", payload={"fromb": 1})              # id 6
    return db


@pytest.fixture
def mailbox_db(tmp_path):
    return _build_mailbox(tmp_path / "liaison.db")


def _max_id(db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        return con.execute("SELECT COALESCE(MAX(id),0) FROM messages").fetchone()[0]
    finally:
        con.close()


# ── poll_digest: pure selection ────────────────────────────────────────

class TestPollDigest:
    def test_selects_peer_messages_after_cursor(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=0, self_id=SELF,
                           peers=[PEER_A, PEER_B])
        assert {m["id"] for m in msgs} == {1, 5, 6}
        for m in msgs:
            assert m["from_instance"] in {PEER_A, PEER_B}

    def test_cursor_filters_older(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=1, self_id=SELF,
                           peers=[PEER_A, PEER_B])
        assert {m["id"] for m in msgs} == {5, 6}

    def test_single_peer_filters_others(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=0, self_id=SELF,
                           peers=[PEER_A])
        assert {m["id"] for m in msgs} == {1, 5}
        assert all(m["from_instance"] == PEER_A for m in msgs)

    def test_reserved_types_never_surfaced(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=0, self_id=SELF,
                           peers=[PEER_A])
        assert all(m["type"] != "review_request" for m in msgs)
        assert all(m["type"] != "review_verdict" for m in msgs)

    def test_ignores_self_and_stranger(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=0, self_id=SELF,
                           peers=[PEER_A, PEER_B])
        assert all(m["from_instance"] in {PEER_A, PEER_B} for m in msgs)

    def test_missing_db_degrades_empty(self, tmp_path):
        assert poll_digest(tmp_path / "nope.db", 0, SELF, [PEER_A]) == []

    def test_empty_peers_returns_empty(self, mailbox_db):
        assert poll_digest(mailbox_db, 0, SELF, []) == []

    def test_empty_self_id_returns_empty(self, mailbox_db):
        assert poll_digest(mailbox_db, 0, "", [PEER_A]) == []

    def test_max_id_cursor(self, mailbox_db):
        assert _max_id(mailbox_db) == 6

    def test_payload_decoded(self, mailbox_db):
        msgs = poll_digest(mailbox_db, since_id=0, self_id=SELF,
                           peers=[PEER_A])
        assert msgs[0]["payload"] == {"hi": 1}


# ── watcher_state: per-peer persistence ──────────────────────────────

class TestState:
    def test_roundtrip_state(self, tmp_path):
        from conscio.liaison.watcher import _save_state
        st = tmp_path / "liaison.db"
        _save_state(st, {
            PEER_A: {"last_seen_id": 5, "status": "idle"},
            PEER_B: {"last_seen_id": 9, "status": "pending_consumption"},
        })
        loaded = _load_state(st)
        assert loaded[PEER_A] == {"last_seen_id": 5, "status": "idle"}
        assert loaded[PEER_B] == {"last_seen_id": 9,
                                  "status": "pending_consumption"}

    def test_load_missing_returns_empty(self, tmp_path):
        assert _load_state(tmp_path / "missing.db") == {}

    def test_upsert_overwrites_existing(self, tmp_path):
        from conscio.liaison.watcher import _save_state
        st = tmp_path / "liaison.db"
        _save_state(st, {PEER_A: {"last_seen_id": 5, "status": "idle"}})
        _save_state(st, {PEER_A: {"last_seen_id": 9, "status": "pending"}})
        assert _load_state(st)[PEER_A] == {"last_seen_id": 9, "status": "pending"}


# ── tick_once: end-to-end contract ────────────────────────────────────

class TestTickOnce:
    def test_consumed_then_idle(self, mailbox_db):
        """First tick consumes all, second tick is silent-idle."""
        outbox = mailbox_db.parent / "relay_inbox.json"
        msgs, code = tick_once(mailbox_db, self_id=SELF,
                               peers=[PEER_A, PEER_B], outbox=outbox)
        assert code == ExitCode.OK
        assert {m["id"] for m in msgs} == {1, 5, 6}
        assert outbox.exists()

        msgs2, code2 = tick_once(mailbox_db, self_id=SELF,
                                 peers=[PEER_A, PEER_B], outbox=outbox)
        assert msgs2 == []
        assert code2 == ExitCode.OK

    def test_new_messages_advance_per_peer_cursor(self, mailbox_db):
        outbox = mailbox_db.parent / "relay_inbox.json"
        _, code = tick_once(mailbox_db, self_id=SELF,
                               peers=[PEER_A, PEER_B], outbox=outbox)
        assert code == ExitCode.OK
        state = _load_state(mailbox_db)
        assert state[PEER_A]["last_seen_id"] == 5
        assert state[PEER_B]["last_seen_id"] == 6
        assert state[PEER_A]["status"] == "pending_consumption"

    def test_outbox_written_with_peer_grouping(self, mailbox_db):
        outbox = mailbox_db.parent / "relay_inbox.json"
        tick_once(mailbox_db, self_id=SELF, peers=[PEER_A, PEER_B],
                  outbox=outbox)
        import json
        data = json.loads(outbox.read_text())
        assert data["self_id"] == SELF
        assert set(data["messages_by_peer"].keys()) == {PEER_A, PEER_B}
        assert data["status"] == "pending_consumption"

    def test_outbox_failure_marks_pending_capture(self, tmp_path):
        db = tmp_path / "liaison.db"
        _build_mailbox(db)
        blocker = tmp_path / "blocker"
        blocker.write_text("not a dir")
        bad_outbox = blocker / "relay_inbox.json"
        _, code = tick_once(db, self_id=SELF,
                               peers=[PEER_A], outbox=bad_outbox)
        assert code == ExitCode.PENDING_CAPTURE
        # cursor NOT advanced — next tick must re-surface.
        state = _load_state(db)
        assert state[PEER_A]["status"] == "pending_capture"
        assert state[PEER_A]["last_seen_id"] == 0

    def test_missing_db_is_config_error(self, tmp_path):
        msgs, code = tick_once(tmp_path / "nope.db", self_id=SELF,
                               peers=[PEER_A], outbox=None)
        assert msgs == []
        assert code == ExitCode.CONFIG_ERROR

    def test_no_peers_is_config_error(self, mailbox_db):
        msgs, code = tick_once(mailbox_db, self_id=SELF,
                               peers=[], outbox=None)
        assert msgs == []
        assert code == ExitCode.CONFIG_ERROR

    def test_no_self_id_is_config_error(self, mailbox_db):
        msgs, code = tick_once(mailbox_db, self_id="",
                               peers=[PEER_A], outbox=None)
        assert msgs == []
        assert code == ExitCode.CONFIG_ERROR

    def test_no_outbox_surfaces_and_advances_cursor(self, mailbox_db):
        """Without an outbox, stdout IS the delivery: the watcher prints the
        new messages AND advances the per-peer cursor (legacy cron contract).
        Next tick is then silent — no re-spam of the same set."""
        msgs, code = tick_once(mailbox_db, self_id=SELF,
                               peers=[PEER_A, PEER_B], outbox=None)
        assert code == ExitCode.OK
        assert {m["id"] for m in msgs} == {1, 5, 6}
        # cursor advanced because stdout delivered them
        st = _load_state(mailbox_db)
        assert st[PEER_A]["last_seen_id"] == 5
        assert st[PEER_B]["last_seen_id"] == 6
        # and the next tick is silent-idle (no re-delivery / spam)
        msgs2, code2 = tick_once(mailbox_db, self_id=SELF,
                                 peers=[PEER_A, PEER_B], outbox=None)
        assert msgs2 == []
        assert code2 == ExitCode.OK

    def test_pending_capture_does_not_advance_other_peer(self, mailbox_db):
        """Peer-B advances even when Peer-A's outbox fails? No: outbox is
        global — a single emit failure stalls all cursors. This asserts the
        conservative contract (no partial advance)."""
        # Point outbox at dir we cannot create files in: use a file as parent.
        from pathlib import Path
        blocker = Path(mailbox_db).parent / "blocker"
        blocker.write_text("x")
        bad_outbox = blocker / "inbox.json"
        _, code = tick_once(mailbox_db, self_id=SELF,
                               peers=[PEER_A, PEER_B], outbox=bad_outbox)
        assert code == ExitCode.PENDING_CAPTURE
        state = _load_state(mailbox_db)
        # No cursor advanced because emit (shared) failed.
        assert all(st["last_seen_id"] == 0 for st in state.values())


# ── Exit-code contract ────────────────────────────────────────────────

class TestExitCode:
    def test_enum_values_are_honest(self):
        assert int(ExitCode.OK) == 0
        assert int(ExitCode.PENDING_CAPTURE) == 2
        assert int(ExitCode.CONFIG_ERROR) == 3


# ── Ato 3a: legacy-compat flags (--since, --interval) ──────────────────────

class TestLegacyCompat:
    def test_since_rewinds_then_tick_resurfaces(self, mailbox_db, capsys):
        """Legacy --since rewinds the per-peer cursor; the single --once tick
        that main() performs then re-surfaces everything after that id
        (replay/recover hook) — printed and cursor re-advanced."""
        from conscio.liaison.watcher import main as wmain
        # consume everything first (cursor for PEER_A ends at 5)
        outbox = mailbox_db.parent / "inbox.json"
        tick_once(mailbox_db, self_id=SELF, peers=[PEER_A, PEER_B],
                  outbox=outbox)
        assert _load_state(mailbox_db)[PEER_A]["last_seen_id"] == 5

        # --since 1 rewinds, then main's single tick re-surfaces ids 5,6
        rc = wmain([
            "--liaison-db", str(mailbox_db),
            "--self-id", SELF,
            "--relay-peer", PEER_A, "--relay-peer", PEER_B,
            "--since", "1",
        ])
        assert rc == 0
        # the replay tick printed both peer ids 5 and 6
        out = capsys.readouterr().out
        assert '"id": 5' in out and '"id": 6' in out
        # cursor re-advanced to the new max (5 and 6)
        st = _load_state(mailbox_db)
        assert st[PEER_A]["last_seen_id"] == 5
        assert st[PEER_B]["last_seen_id"] == 6

    def test_since_requires_self_id(self, mailbox_db):
        from conscio.liaison.watcher import main as wmain
        rc = wmain(["--liaison-db", str(mailbox_db),
                    "--self-id", "", "--relay-peer", PEER_A])
        assert rc == int(ExitCode.CONFIG_ERROR)


# ── Ato 2 (v4.5): heartbeat 3 estados + presença ─────────────────────────

class TestHeartbeat3Estados:
    def test_nada_novo_when_empty(self, tmp_path):
        from conscio.liaison.watcher import tick_summary
        db = tmp_path / "m.db"
        s = tick_summary(db, self_id=SELF, peers=[PEER_A], outbox=None)
        assert s["estado"] == "nada_novo"
        assert s["motivo"] == ""
        assert s["par"] == SELF

    def test_nao_entregue_when_config_error(self, tmp_path):
        from conscio.liaison.watcher import tick_summary
        # sem peers → CONFIG_ERROR → não_entregue (diagnóstico honesto)
        s = tick_summary(tmp_path / "m.db", self_id="", peers=[], outbox=None)
        assert s["estado"] == "não_entregue"
        assert s["motivo"]

    def test_nao_entregue_when_db_blocked(self, tmp_path):
        from conscio.liaison.watcher import tick_summary
        # caminho que não é db (arquivo que impede sqlite) → degrada honesto
        blocker = tmp_path / "blocker"
        blocker.write_text("not a dir")
        s = tick_summary(blocker / "m.db", self_id=SELF, peers=[PEER_A],
                         outbox=None)
        assert s["estado"] in ("nada_novo", "não_entregue")

    def test_entregue_when_messages(self, mailbox_db, capsys):
        from conscio.liaison.watcher import tick_summary
        s = tick_summary(mailbox_db, self_id=SELF,
                         peers=[PEER_A, PEER_B], outbox=None)
        assert s["estado"] == "entregue"
        assert s["cursor"].get(PEER_A, 0) > 0

    def test_nunca_levanta(self, tmp_path):
        from conscio.liaison.watcher import tick_summary
        # db apontando pra um arquivo não-db (diretório) → degrada
        s = tick_summary(tmp_path, self_id=SELF, peers=[PEER_A], outbox=None)
        assert s["estado"] in ("nada_novo", "não_entregue")


class TestPresenca:
    def test_tick_registers_self(self, tmp_path):
        from conscio.liaison import agents
        from conscio.liaison.watcher import tick_summary
        db = tmp_path / "m.db"
        tick_summary(db, self_id=SELF, peers=[PEER_A], outbox=None)
        row = agents.get_agent(db, SELF)
        assert row is not None
        assert row["status"] == "alive"

    def test_tick_renovates_heartbeat(self, tmp_path):
        import time

        from conscio.liaison import agents
        from conscio.liaison.watcher import tick_summary
        db = tmp_path / "m.db"
        tick_summary(db, self_id=SELF, peers=[PEER_A], outbox=None)
        hb1 = agents.get_agent(db, SELF)["last_heartbeat"]
        time.sleep(0.01)
        tick_summary(db, self_id=SELF, peers=[PEER_A], outbox=None)
        hb2 = agents.get_agent(db, SELF)["last_heartbeat"]
        assert hb2 > hb1

# ── Ato 3b (v4.5.4): --persistent — nada além de um sinal encerra ─────────

class TestPersistentWatcher:
    """The watcher used to end its own run on the first delivery and again
    on a 600s deadline, which is why every exchange between agents needed a
    re-arm (and why the field units carried RELAY_INACTIVITY=31536000).
    Under --persistent neither happens."""

    @staticmethod
    def _stop_after(monkeypatch, ticks: int) -> list[float]:
        """Let the loop run `ticks` iterations, then signal it. Records the
        interval each iteration slept for."""
        slept: list[float] = []

        def fake_sleep(seconds):
            slept.append(seconds)
            if len(slept) >= ticks:
                raise KeyboardInterrupt
        monkeypatch.setattr("time.sleep", fake_sleep)
        return slept

    def test_delivery_does_not_end_the_run(self, mailbox_db, monkeypatch,
                                           capsys):
        from conscio.liaison.watcher import main as wmain
        slept = self._stop_after(monkeypatch, 3)

        rc = wmain(["--liaison-db", str(mailbox_db), "--self-id", SELF,
                    "--relay-peer", PEER_A, "--persistent"])

        assert rc == int(ExitCode.OK)          # signal exits clean
        assert len(slept) == 3                 # kept polling past the delivery
        lines = capsys.readouterr().out.splitlines()
        # it delivered on the first tick...
        assert any('"messages"' in ln for ln in lines)
        # ...then went on beating instead of returning, which is the whole
        # point: no re-arm between two exchanges.
        first_delivery = next(i for i, ln in enumerate(lines)
                              if '"messages"' in ln)
        assert any('"estado": "nada_novo"' in ln
                   for ln in lines[first_delivery + 1:])

    def test_empty_peers_is_awaited_not_fatal(self, tmp_path, monkeypatch,
                                              capsys):
        """No peers yet reads as `config` inside the tick — for a supervised
        watcher armed before the other agents publish their cards that is
        'nobody has shown up yet', not a reason to die. (A missing db is not
        even that: the presence heartbeat creates it on the first tick.)"""
        from conscio.liaison.watcher import main as wmain
        slept = self._stop_after(monkeypatch, 2)

        rc = wmain(["--liaison-db", str(tmp_path / "nope.db"),
                    "--self-id", SELF, "--persistent"])

        assert rc == int(ExitCode.OK)
        assert len(slept) == 2                 # did not bail out on config
        out = capsys.readouterr().out
        assert '"motivo": "config' in out      # but says why, every tick

    def test_defaults_to_2s_and_honours_interval(self, mailbox_db,
                                                 monkeypatch):
        from conscio.liaison.watcher import PERSISTENT_INTERVAL
        from conscio.liaison.watcher import main as wmain
        args = ["--liaison-db", str(mailbox_db), "--self-id", SELF,
                "--relay-peer", PEER_A, "--persistent"]

        slept = self._stop_after(monkeypatch, 1)
        wmain(args)
        assert slept == [PERSISTENT_INTERVAL] == [2.0]

        slept = self._stop_after(monkeypatch, 1)
        wmain([*args, "--interval", "0.5"])
        assert slept == [0.5]

    def test_timeout_is_ignored_when_persistent(self, mailbox_db,
                                                monkeypatch):
        """A deadline is an exit of one's own accord: --persistent has none,
        even if a stale unit file still passes --timeout."""
        from conscio.liaison.watcher import main as wmain
        slept = self._stop_after(monkeypatch, 4)

        rc = wmain(["--liaison-db", str(mailbox_db), "--self-id", SELF,
                    "--relay-peer", PEER_A, "--persistent",
                    "--timeout", "0"])

        assert rc == int(ExitCode.OK)
        assert len(slept) == 4                 # 0s deadline did not apply

    def test_legacy_interval_still_exits_on_delivery(self, mailbox_db,
                                                     monkeypatch, capsys):
        """Regression: without --persistent the old contract is untouched."""
        from conscio.liaison.watcher import main as wmain
        self._stop_after(monkeypatch, 5)       # loop must end before this

        rc = wmain(["--liaison-db", str(mailbox_db), "--self-id", SELF,
                    "--relay-peer", PEER_A, "--interval", "0.1"])

        assert rc == int(ExitCode.OK)
        assert '"messages"' in capsys.readouterr().out
