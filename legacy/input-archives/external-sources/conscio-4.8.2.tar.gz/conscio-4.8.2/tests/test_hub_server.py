# tests/test_hub_server.py
import json as _json

import pytest

import conscio.adapter_config as ac
from conscio.hub import control as _control
from conscio.hub import model_test, providers, server


def test_parse_json_body_ok():
    assert server.parse_json_body(b'{"a": 1}') == {"a": 1}


def test_parse_json_body_oversize():
    with pytest.raises(ValueError):
        server.parse_json_body(b"{}", max_bytes=1)


def test_parse_json_body_not_object():
    with pytest.raises(ValueError):
        server.parse_json_body(b"[1,2]")


def test_route_health():
    r = server.route("GET", "/api/health", {}, None, token=None, auth=None)
    assert r.status == 200 and r.payload["ok"] is True
    assert "version" in r.payload


def test_get_config_redacts(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps(
        {"model": "m", "adapter": {"type": "openai", "api_key": "leak"}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/config", {}, None, token=None, auth=None)
    assert r.status == 200 and "api_key" not in r.payload["adapter"]


def test_get_providers_lists_builtin(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/providers", {}, None, token=None, auth=None)
    assert r.status == 200 and "openai" in r.payload["builtin"]


def test_put_config_writes(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    body = {"model": "glm-5.1", "adapter": {"type": "openai"}}
    r = server.route("PUT", "/api/config", {}, body, token=None, auth=None)
    assert r.status == 200
    assert _json.loads(p.read_text())["model"] == "glm-5.1"


def test_put_config_invalid_400(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    body = {"model": "m", "adapter": {"type": "bogus"}}    # valid model, bad type
    r = server.route("PUT", "/api/config", {}, body, token=None, auth=None)
    assert r.status == 400 and not p.exists()


def test_put_config_resolves_builtin_provider(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("PUT", "/api/config", {},
                     {"model": "llama3.1", "provider": "ollama"},
                     token=None, auth=None)
    assert r.status == 200
    a = _json.loads(p.read_text())["adapter"]
    assert a["type"] == "ollama" and a["base_url"] == "http://localhost:11434"


def test_put_config_resolves_custom_provider(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps(
        {"model": "m", "adapter": {"type": "openai"},
         "providers": {"logfare": {"type": "openai-compat",
                                   "base_url": "https://x/v1",
                                   "api_key_env": "LOGFARE_KEY"}}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("PUT", "/api/config", {},
                     {"model": "glm-5.1", "provider": "logfare"},
                     token=None, auth=None)
    assert r.status == 200
    a = _json.loads(p.read_text())["adapter"]
    assert a["type"] == "openai-compat" and a["api_key_env"] == "LOGFARE_KEY"


def test_post_provider_adds(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps({"model": "m", "adapter": {"type": "openai"}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    body = {"name": "logfare", "type": "openai-compat",
            "base_url": "https://x/v1", "api_key_env": "LOGFARE_KEY"}
    r = server.route("POST", "/api/providers", {}, body, token=None, auth=None)
    assert r.status == 200
    assert "logfare" in _json.loads(p.read_text())["providers"]


def test_post_provider_rejects_raw_key(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps({"model": "m", "adapter": {"type": "openai"}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    body = {"name": "x", "type": "openai", "api_key_env": "sk-raw-key"}
    r = server.route("POST", "/api/providers", {}, body, token=None, auth=None)
    assert r.status == 400


def test_get_models_resolves_and_probes(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    monkeypatch.setattr(providers, "probe_models",
                        lambda pc, **k: {"models": ["m1"], "source": "api",
                                         "probed": True})
    r = server.route("GET", "/api/models", {"provider": "ollama"}, None,
                     token=None, auth=None)
    assert r.status == 200 and r.payload["models"] == ["m1"]


def test_get_models_unknown_provider_404(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/models", {"provider": "nope"}, None,
                     token=None, auth=None)
    assert r.status == 404


def test_get_models_missing_param_400(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/models", {}, None, token=None, auth=None)
    assert r.status == 400


def test_post_model_test(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    monkeypatch.setattr(model_test, "smoke_test",
                        lambda pc, model, **k: {"ok": True, "latency_ms": 5,
                                                "sample_output": "OK", "model": model})
    body = {"provider": "ollama", "model": "llama3.1"}
    r = server.route("POST", "/api/model/test", {}, body, token=None, auth=None)
    assert r.status == 200 and r.payload["ok"] is True


def test_token_gate_blocks_without_auth():
    r = server.route("GET", "/api/config", {}, None, token="secret", auth=None)
    assert r.status == 401


def test_token_gate_allows_with_auth(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text("{}")
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/config", {}, None,
                     token="secret", auth="Bearer secret")
    assert r.status == 200


def test_static_index_served():
    r = server.route("GET", "/", {}, None, token=None, auth=None)
    assert r.status == 200 and r.content_type == "text/html"


def test_static_traversal_blocked():
    r = server.route("GET", "/static/../config.py", {}, None,
                     token=None, auth=None)
    assert r.status == 404


def test_post_provider_rejects_raw_api_key_field(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps({"model": "m", "adapter": {"type": "openai"}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    body = {"name": "x", "type": "openai", "api_key": "sk-live-xxx"}
    r = server.route("POST", "/api/providers", {}, body, token=None, auth=None)
    assert r.status == 400


def test_get_config_redacts_providers(tmp_path, monkeypatch):
    p = tmp_path / "config.json"
    p.write_text(_json.dumps(
        {"model": "m", "adapter": {"type": "openai"},
         "providers": {"x": {"type": "openai", "api_key": "leak"}}}))
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    r = server.route("GET", "/api/config", {}, None, token=None, auth=None)
    assert "api_key" not in r.payload["providers"]["x"]


def test_check_host_allows_loopback():
    server._check_host("127.0.0.1")
    server._check_host("::1")
    server._check_host("localhost")             # no raise = pass


def test_check_host_refuses_non_loopback():
    for bad in ("0.0.0.0", "192.168.1.5", "10.0.0.1"):
        with pytest.raises(ValueError):
            server._check_host(bad)


def test_token_gate_wrong_token_401():
    r = server.route("GET", "/api/config", {}, None,
                     token="secret", auth="Bearer wrong")
    assert r.status == 401


# ── v2.7.1: dropped control endpoints + vault wiring ───────────────
def test_dropped_endpoints_404():
    # these live in the Observatory (v2.8.0), never on the Hub
    for p in ("/api/daemon/status", "/api/identity", "/api/relay/inbox"):
        r = server.route("GET", p, {}, None, token=None, auth=None)
        assert r.status == 404


def test_put_config_raw_key_goes_to_vault(tmp_path, monkeypatch):
    from conscio.hub import config
    p = tmp_path / "config.json"
    monkeypatch.setattr(ac, "_CONFIG_PATHS", [p])
    monkeypatch.setenv("CONSCIO_VAULT_DIR", str(tmp_path / "keys"))
    body = {"model": "gpt-4o",
            "adapter": {"type": "openai", "api_key": "sk-raw"}}
    r = server.route("PUT", "/api/config", {}, body, token=None, auth=None)
    assert r.status == 200
    saved = config.load()
    assert "api_key" not in saved["adapter"]
    env = saved["adapter"]["api_key_env"]
    assert env.startswith("CONSCIO_KEY_")
    assert config.vault_load(env) == "sk-raw"
    # GET must report presence without echoing the raw key
    g = server.route("GET", "/api/config", {}, None, token=None, auth=None)
    assert g.payload["adapter"]["api_key_present"] is True
    assert "api_key" not in g.payload["adapter"]


# ── v2.8.1: Hub awake control (gated) ──────────────────────────────
def test_daemon_awake_404_when_flag_off(tmp_path):
    # flag off (default) -> route not exposed
    r = server.route("PUT", "/api/daemon/awake", {}, {"awake": True},
                     token=None, auth=None)
    assert r.status == 404
    r = server.route("GET", "/api/daemon/control", {}, None,
                     token=None, auth=None)
    assert r.status == 404


def test_put_awake_writes_control_when_enabled(tmp_path):
    r = server.route("PUT", "/api/daemon/awake", {}, {"awake": True},
                     token=None, auth=None,
                     storage=tmp_path, daemon_control=True)
    assert r.status == 200 and r.payload["awake"] is True
    assert _control.read_control(tmp_path)["awake"] is True


def test_put_awake_requires_bool(tmp_path):
    r = server.route("PUT", "/api/daemon/awake", {}, {"awake": "yes"},
                     token=None, auth=None,
                     storage=tmp_path, daemon_control=True)
    assert r.status == 400


def test_put_awake_missing_storage_dir_500(tmp_path):
    # review finding: refuse to write into a non-existent storage dir
    ghost = tmp_path / "does-not-exist"
    r = server.route("PUT", "/api/daemon/awake", {}, {"awake": True},
                     token=None, auth=None,
                     storage=ghost, daemon_control=True)
    assert r.status == 500
    assert not (ghost / _control.CONTROL_FILENAME).exists()


def test_get_control_reads_back(tmp_path):
    server.route("PUT", "/api/daemon/awake", {}, {"awake": False},
                 token=None, auth=None, storage=tmp_path, daemon_control=True)
    r = server.route("GET", "/api/daemon/control", {}, None,
                     token=None, auth=None, storage=tmp_path, daemon_control=True)
    assert r.status == 200 and r.payload["awake"] is False


def test_health_advertises_daemon_control():
    off = server.route("GET", "/api/health", {}, None, token=None, auth=None)
    assert off.payload["daemon_control"] is False
    on = server.route("GET", "/api/health", {}, None, token=None, auth=None,
                      daemon_control=True)
    assert on.payload["daemon_control"] is True


def test_daemon_control_without_storage_500():
    # storage=None must be an explicit error — the old fallback silently wrote
    # daemon_control.json into the CONFIG dir, where no daemon ever reads it
    r = server.route("PUT", "/api/daemon/awake", {}, {"awake": True},
                     token=None, auth=None, storage=None, daemon_control=True)
    assert r.status == 500
    r = server.route("GET", "/api/daemon/control", {}, None,
                     token=None, auth=None, storage=None, daemon_control=True)
    assert r.status == 500


def test_vault_dir_flag_binds_process_vault(tmp_path, monkeypatch):
    monkeypatch.delenv("CONSCIO_VAULT_DIR", raising=False)
    from conscio.hub import config
    server._bind_vault_dir(str(tmp_path / "vk"))
    config.vault_store("CONSCIO_KEY_TEST", "sekret")
    assert (tmp_path / "vk" / "CONSCIO_KEY_TEST").is_file()   # per-host vault
    assert config.vault_load("CONSCIO_KEY_TEST") == "sekret"


def test_arg_parser_accepts_vault_dir():
    ns = server._arg_parser().parse_args(["--vault-dir", "/x"])
    assert ns.vault_dir == "/x"


def test_make_server_refuses_daemon_control_without_storage():
    # fail at construction, not per-request: an embedder that enables the
    # awake toggle without a storage dir would serve nothing but 500s
    with pytest.raises(ValueError):
        server.make_server("127.0.0.1", 0, "tok", daemon_control=True)
