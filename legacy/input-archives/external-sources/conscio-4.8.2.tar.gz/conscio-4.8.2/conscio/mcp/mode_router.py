"""ModeRouter — lê daemon_control.json e chunkifica output das MCP tools.

Design: wrapper de presentation no MCP server. Não modifica lógica das vozes
em gates.py. Recebe o dict completo do council/evaluate/cognitive_cycle
e chunkifica conforme o modo: minimal, compact, full, agent_host.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_VALID_COMPLEXITIES = {"minimal", "compact", "full", "agent_host"}


class ModeRouter:
    """Lê prompt_complexity do daemon_control.json e chunkifica output."""

    def __init__(self, storage_path: Path | str):
        storage = Path(storage_path)
        self.complexity = self._read_complexity(storage)

    @staticmethod
    def _read_complexity(storage: Path) -> str:
        """Lê prompt_complexity do daemon_control.json. Default: compact."""
        ctrl = storage / "daemon_control.json"
        if ctrl.exists():
            try:
                data = json.loads(ctrl.read_text(encoding="utf-8"))
                complexity = data.get("prompt_complexity", "compact")
                if complexity in _VALID_COMPLEXITIES:
                    return complexity
            except (json.JSONDecodeError, OSError):
                logger.warning("daemon_control.json corrupted, falling back to compact")
        return "compact"

    def format_council(self, council_result: dict) -> dict:
        """Formats the council result for the output mode.

        The mode comes from the result itself (calibration spec section
        6.3/6.4): council() has emitted ``mode`` ("judged" or
        "deterministic") since the readiness-gate step. The old
        detection by the "LLM" string in the voice analyses was dead
        code since v4.6.8 (the critic never calls an LLM) and was
        deleted, with no whitelist entry (section 6.4).
        """
        mode = council_result.get("mode", "deterministic")
        complexity = self.complexity

        if complexity == "minimal":
            return {
                "mode": mode,
                "recommendation": council_result["recommendation"],
                "votes": council_result["votes_summary"],
            }

        if complexity == "agent_host":
            return {
                "mode": "agent_host",
                "question": council_result.get("question", ""),
                "context": council_result.get("context", ""),
                "hint": "Produce 4 voices: architect (structural integrity), "
                       "skeptic (contradictions), pragmatist (cost/feasibility), "
                       "critic (failure modes). Return verdict + concerns.",
            }

        if complexity == "compact":
            voices = []
            for v in council_result.get("voices", []):
                top = v.get("concerns", ["none"])
                voices.append({
                    "role": v["role"],
                    "vote": v["vote"],
                    "top_concern": top[0] if top else "none",
                })
            return {
                "mode": mode,
                "recommendation": council_result["recommendation"],
                "votes": council_result["votes_summary"],
                "voices": voices,
            }

        # full
        return {"mode": mode, **council_result}

    def format_cognitive_cycle(self, cycle_result: dict) -> dict:
        """Formata cognitive_cycle conforme o modo."""
        mode = "deterministic"
        if any("LLM" in str(v) for v in cycle_result.values()):
            mode = "llm"

        complexity = self.complexity

        if complexity == "minimal":
            return {
                "mode": mode,
                "coherence": cycle_result.get("coherence", {}),
                "metabolic": cycle_result.get("metabolic", ""),
            }

        if complexity == "compact":
            dissonance = cycle_result.get("dissonance", [])
            top_dissonance = dissonance[:3] if isinstance(dissonance, list) else [str(dissonance)]
            return {
                "mode": mode,
                "coherence": cycle_result.get("coherence", {}),
                "reflection_quality": cycle_result.get("reflection_quality", ""),
                "top_dissonance": top_dissonance,
            }

        # full
        return {"mode": mode, **cycle_result}

    def format_evaluate(self, evaluate_result: dict) -> dict:
        """Format an evaluation for the active mode, keeping all five axes.

        Reads the shape ``EvaluationReport.to_dict()`` actually produces: the axes
        live under ``axes`` and ``overall`` is a float. Reading ``axis_scores``
        and calling ``.get`` on that float made every minimal/compact caller of
        conscio_evaluate fail with a bare "internal error".
        """
        axes = evaluate_result.get("axes") or []
        mode = "deterministic"
        for axis in axes:
            if "LLM" in str(axis.get("evidence", "")):
                mode = "llm"
                break

        if self.complexity in ("minimal", "compact"):
            scored = {a.get("axis", ""): a.get("score", 0) for a in axes}
            return {
                "mode": mode,
                "overall": evaluate_result.get("overall", 0.0),
                "strongest": max(scored, key=lambda k: scored[k]) if scored else "",
                "weakest": min(scored, key=lambda k: scored[k]) if scored else "",
            }

        return {"mode": mode, **evaluate_result}