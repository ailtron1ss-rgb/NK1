# conscio/mcp/server.py
"""Engine-backed bindings (propose-only) + the stdio serve loop + the
conscio-mcp CLI. stdout is the protocol channel; logging goes to stderr."""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from conscio import __version__
from conscio.engine import ConsciousnessEngine
from conscio.workspace import WorkspaceContext

from ..agency import review_apply
from ..liaison import mailbox, relay, review
from . import capabilities, modes
from . import jsonrpc as j
from .protocol import SUPPORTED_PROTOCOLS, Dispatcher
from .schemas import (
    ACT_TOOL_DEFS,
    BASE_TOOL_DEFS,
    BOARD_DISPATCH_DEF,
    HALL_DISPATCH_DEF,
    LIAISON_TOOL_DEFS,
    MODE_TOOL_DEF,
    RELAY_DISPATCH_DEF,
    RESOURCE_DEFS,
    REVIEW_DISPATCH_DEF,
    derive_event_id,
    event_to_frame,
    validate_event,
)
from .seen import SeenStore


def _flatten(d: dict) -> dict:
    """One-sentence description, bare-typed properties. For small models."""
    desc = d.get("description", "")     # `.get`: o corpo v3.9.9 tolerava a ausência
    first = desc.split(".")[0] + "." if "." in desc else desc
    schema = d.get("inputSchema", {})
    props = {k: {"type": v.get("type", "string")}
             for k, v in schema.get("properties", {}).items()}
    return {"name": d["name"],
            "description": first[:120],
            "inputSchema": {"type": "object",
                            "properties": props,
                            "required": schema.get("required", [])}}


def _legacy_name(name: str) -> str:
    """The pre-v4.1 dotted spelling of a tool, mapped to the current one.

    v4.1 renamed every tool ``conscio.x`` → ``conscio_x``: a dot is legal in
    MCP, but hosts that reuse the Anthropic/OpenAI function-name rule
    (``^[A-Za-z0-9_-]{1,128}$``) reject it — Verdent loads the server, reports
    it healthy, and disables every tool it was served (18 of 18 in ``balanced``).
    ``tools/list`` only ever advertises the new spelling;
    this exists so a caller scripted against the old one keeps dispatching
    instead of getting MethodNotFound on a rename it never saw.
    """
    return name.replace(".", "_", 1) if name.startswith("conscio.") else name


# v2.6.3 #2: floor between auto-review SQL polls so --auto-review does not open a
# liaison SELECT on every single tool call in a chatty session. host_act.approve
# remains the authority; this only paces the opportunistic poll.
AUTO_APPLY_THROTTLE_S = 5.0
CARD_REPUBLISH_S = 60.0        # v4.5.4 I6: _ensure_registered roda toda ferramenta


class Bindings:
    def __init__(self, engine: ConsciousnessEngine, seen: SeenStore, *,
                 adapter_name: str | None = None,
                 workspace_id: str = "", act_flag: bool = False,
                 hermes_review: bool = False,
                 reviewers: tuple[str, ...] = (),
                 self_instance_id: str = "",
                 liaison_db: Path | None = None,
                 relay: bool = False,
                 relay_peers: tuple[str, ...] = (),
                 auto_review: bool = False,
                 mode: str = modes.DEFAULT_MODE,
                 identity_model: str = "", identity_familia: str = "",
                 identity_runtime: str = "", identity_papel: str = "",
                 can_create_halls: bool = False) -> None:
        self.engine = engine
        self.seen = seen
        self.adapter_name = adapter_name
        self.workspace_id = workspace_id
        self.act_flag = act_flag             # v2.0.1: --enable-act
        self._act_error = ""
        self.hermes_review = hermes_review    # v2.6.0: --enable-hermes-review
        self.reviewers = tuple(reviewers)
        self.self_instance_id = self_instance_id
        self.liaison_db: Path = (Path(liaison_db) if liaison_db is not None
                                 else mailbox.default_db())
        self.relay = relay                   # v2.6.1: --enable-relay
        self.relay_peers = tuple(relay_peers)
        self.auto_review = auto_review        # v2.6.2: --auto-review
        self.last_auto_apply_ts = 0.0         # v2.6.3 #2: throttle clock
        self.mode = mode                      # v4.0: lite / balanced / ultra
        # v4.5 identity do runtime (preenchido pelo cli/runtime, não pelo agente)
        self.identity_model = identity_model
        self.identity_familia = identity_familia
        self.identity_runtime = identity_runtime
        self.identity_papel = identity_papel
        # v4.5: Agent's Hall tools. A hall delivers through the relay mailbox,
        # so halls without relay would be a way around the relay flag. One
        # invariant, derived once: advertisement and dispatch can never drift.
        self.can_create_halls = bool(can_create_halls and relay)
        self.halls_need_relay = bool(can_create_halls and not relay)
        # v4.5.4: cartão público no diretório (C2). Erro fica visível em vez
        # de virar agente invisível que se acha publicado.
        self.card_error: str = ""
        self._card_ts: float = 0.0
        self._halls_migrated = False     # migração preguiçosa do roster legado
        self._pending_notifications: list[dict] = []

        # v4.5.4 (C5): reactivity without systemd. The loop lives in the
        # session that has an agent to wake, and dies with it — no unit to
        # arm, no watcher to re-arm after every restart.
        self.reactor_thread = None
        notify_cmd = os.environ.get("CONSCIO_NOTIFY_CMD", "").strip()
        if self.relay and notify_cmd and self.self_instance_id:
            from ..liaison.reactor import ReactorThread
            self.reactor_thread = ReactorThread(
                self.liaison_db, self.self_instance_id, notify_cmd)
            self.reactor_thread.start()

        # v3.7: ModeRouter — chunkifica output conforme prompt_complexity
        import tempfile as _tempfile

        from .mode_router import ModeRouter
        storage = getattr(engine, "storage", Path(_tempfile.gettempdir()))
        self._router = ModeRouter(storage)

    # ── server-initiated frames ──
    def enqueue_notification(self, method: str,
                             params: dict | None = None) -> None:
        """Queue a server-initiated frame. Written after the current response."""
        frame: dict = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            frame["params"] = params
        self._pending_notifications.append(frame)

    def drain_notifications(self) -> list[dict]:
        queued, self._pending_notifications = self._pending_notifications, []
        return queued

    # ── discovery ──
    def version(self) -> str:
        return __version__

    def on_initialize(self, params: dict) -> None:
        """v2.0.1: read the host tool manifest from initialize params and enable
        act. Independent of session init — a bad/missing manifest never
        half-enables act (act stays off, act_error set)."""
        self._act_error = ""
        if not self.act_flag:
            return
        tools = (params.get("conscio") or {}).get("tools")
        if not tools:
            self._act_error = "no tool manifest in initialize params"
            return
        if not self.engine.enable_host_act(tools):
            self._act_error = self.engine.host_act_error or "act not enabled"

    def _act_enabled(self) -> bool:
        return self.act_flag and self.engine.host_act is not None

    def conscio_meta(self) -> dict:
        ha = self.engine.host_act
        return {"workspace_id": self.workspace_id,
                "awake": bool(self.engine.awake),
                "act_enabled": self._act_enabled(),
                "act_error": self._act_error,
                "host_tools_count": len(ha.registry.names()) if ha else 0,
                "adapter_ready": self.adapter_name is not None,
                "manifest_hash": getattr(self.engine, "_host_act_hash", ""),
                "adapter": self.adapter_name,
                "hermes_review_enabled": self.hermes_review,
                "reviewers_count": len(self.reviewers),
                "relay_enabled": self.relay,
                "relay_peers_count": len(self.relay_peers),
                "auto_review_enabled": self.auto_review,
                "supported_protocols": SUPPORTED_PROTOCOLS}

    def tool_defs(self) -> list[dict]:
        defs = list(BASE_TOOL_DEFS)
        flagged: list[dict] = []             # ligados explicitamente pelo operador
        if self._act_enabled():
            flagged += list(ACT_TOOL_DEFS)
        if self.hermes_review:
            # E3: one advertised dispatcher (the individual names stay in
            # _tools() as dispatch-only aliases); poll stays gated on act
            # because the proposer path needs it too.
            flagged.append(REVIEW_DISPATCH_DEF)
            if self._act_enabled():
                poll = next(d for d in LIAISON_TOOL_DEFS
                            if d["name"] == "conscio_poll_reviews")
                flagged.append(poll)
        if self.relay:
            flagged.append(RELAY_DISPATCH_DEF)
            flagged.append(BOARD_DISPATCH_DEF)
        if self.can_create_halls:                # v4.5: Agent's Hall tools
            flagged.append(HALL_DISPATCH_DEF)

        # 1. seleção: o modo filtra só a superfície BASE
        allowed = {"lite": modes.LITE_TOOLS,
                   "balanced": modes.BALANCED_TOOLS,
                   "high": modes.HIGH_TOOLS}.get(self.mode)
        if allowed is not None:
            defs = [d for d in defs if d["name"] in allowed]
        defs += flagged                      # flag digitada nunca é filtrada
        defs.append(MODE_TOOL_DEF)           # a saída de volta existe em todo modo

        # 2. formatação: em lite, tudo que sai é achatado
        if self.mode == "lite":
            defs = [_flatten(d) for d in defs]
        return defs

    def resource_defs(self) -> list[dict]:
        return list(RESOURCE_DEFS)

    # ── tool dispatch ──
    def call_tool(self, name: str, args: dict) -> dict:
        self._maybe_auto_apply()             # v2.6.2: opportunistic on dispatch
        tools = self._tools()
        fn = tools.get(name) or tools.get(_legacy_name(name))
        if fn is None:
            raise j.MethodNotFound(f"tool '{name}' not available")
        return {"content": [{"type": "text", "text": json.dumps(fn(args))}]}

    def _tools(self):
        tools = {
            "conscio_feed": self._feed,
            "conscio_note": self._note,
            "conscio_advisory": lambda a: self.engine.advisory(),
            "conscio_recall": lambda a: {"snippets": self.engine.recall(
                self._require(a, "query"), int(a.get("k", 3)),
                a.get("categories"))},
            "conscio_remember": self._remember,
            "conscio_observe": lambda a: {"observation_id": self.engine.observe(
                self._require(a, "tool"), a.get("input", ""),
                a.get("output", ""), a.get("project", ""),
                a.get("agent", ""))},
            "conscio_recall_observations": self._recall_observations,
            "conscio_propose_action": lambda a: self.engine.propose_action(
                self._require(a, "intent")),
            "conscio_propose_plan": lambda a: self.engine.propose_plan(
                self._require(a, "goal"), a.get("tools")),
            "conscio_state": lambda a: self._state_payload(),
            "conscio_events": lambda a: self._events_payload(a),
            "conscio_handoff": lambda a: self._handoff_payload(),
            "conscio_structure": self._structure,
            "conscio_structural_lookup": self._structural_lookup,
            "conscio_cognitive_cycle": self._cognitive_cycle,
            "conscio_evaluate": lambda a: self._router.format_evaluate(
                self.engine.evaluate(
                    a.get("task_description", ""), a.get("output")).to_dict()),
            # ── v3.0 Gate tools ──
            "conscio_decide": lambda a: self.engine.decide(
                title=a.get("title", ""), context=a.get("context", ""),
                alternatives=a.get("alternatives"), adr_id=a.get("adr_id"),
                status=a.get("status", "proposed"), deciders=a.get("deciders")),
            "conscio_council": lambda a: self._router.format_council(
                            self.engine.council(
                                question=a.get("question", ""), context=a.get("context", ""),
                                options=a.get("options"))),
            "conscio_squad_experts": lambda a: self.engine.squad_experts(
                            question=a.get("question", ""), context=a.get("context", ""),
                            voices=a.get("voices"), use_llm=a.get("use_llm", False)),
            "conscio_squad_opositors": lambda a: self.engine.squad_opositors(
                            question=a.get("question", ""), context=a.get("context", ""),
                            voices=a.get("voices"), use_llm=a.get("use_llm", False)),
            "conscio_loop_gate": lambda a: self.engine.loop_gate(
                task=a.get("task", ""), frequency=a.get("frequency", ""),
                verifiable=a.get("verifiable", True),
                budget_ok=a.get("budget_ok", True),
                has_tools=a.get("has_tools", True)),
            "conscio_delivery_check": lambda a: self.engine.delivery_check(),
            "conscio_investigate": lambda a: self.engine.investigate(
                target=a.get("target", ""), action_type=a.get("action_type", "")),
            # ── v3.0 Pipeline tools ──
            "conscio_acceptance_criteria": lambda a: self.engine.acceptance_criteria(
                goal=a.get("goal", ""), depth=a.get("depth", ""),
                risk_domains=a.get("risk_domains")),
            "conscio_verify": lambda a: self.engine.verify(
                criteria=a.get("criteria"), criteria_source=a.get("criteria_source", "")),
            "conscio_continuous_loop": lambda a: self.engine.continuous_loop(
                task=a.get("task", ""), pattern=a.get("pattern", ""),
                frequency=a.get("frequency", ""),
                verifiable=a.get("verifiable", True),
                budget_ok=a.get("budget_ok", True),
                has_tools=a.get("has_tools", True)),
            "conscio_strategic_compact": lambda a: self.engine.strategic_compact(
                phase=a.get("phase", ""), context_tokens=a.get("context_tokens", 0),
                context_window=a.get("context_window", 0)),
            "conscio_ledger": lambda a: self.engine.ledger(
                action=a.get("action", "record"), rollout_id=a.get("rollout_id"),
                candidates=a.get("candidates"), fresh_info=a.get("fresh_info", ""),
                search_space_size=a.get("search_space_size", 0),
                marks=a.get("marks"), prior_winner=a.get("prior_winner", ""),
                coherence_mark=a.get("coherence_mark")),
            # ── v3.0 Diagnostic tools ──
            "conscio_context_budget": lambda a: self.engine.context_budget(
                context_tokens=a.get("context_tokens", 0),
                context_window=a.get("context_window", 0),
                detail=a.get("detail", "summary")),
            "conscio_eval_harness": lambda a: self.engine.eval_harness(
                action=a.get("action", "define"),
                eval_id=a.get("eval_id"),
                eval_type=a.get("eval_type", "capability"),
                task=a.get("task", ""),
                criteria=a.get("criteria"),
                results=a.get("results"),
                k_values=a.get("k_values")),
            "conscio_rules_distill": lambda a: self.engine.rules_distill(
                action=a.get("action", "scan"),
                source_types=a.get("source_types"),
                min_occurrences=a.get("min_occurrences", 2),
                rule_text=a.get("rule_text", ""),
                rule_id=a.get("rule_id")),
            "conscio_health": lambda a: self.engine.health_check(),
            "conscio_intercept": self._intercept,
            # ── v3.2 Memory tools ──
            "conscio_kg_query": lambda a: self._kg_query(a),
            "conscio_wings_search": lambda a: self._wings_search(a),
            "conscio_export": lambda a: self._export(a),
            # ── v3.3.1 Auto-index + KG builder ──
            "conscio.enable_auto_index": lambda a: self.engine.enable_auto_index(
                run_kg_builder=a.get("run_kg_builder", True)),
            "conscio.kg_build": lambda a: self._kg_build(a),
        }
        if self._act_enabled():
            ha = self.engine.host_act
            assert ha is not None  # guarded by _act_enabled()
            tools.update({
                "conscio_act": self._act,
                "conscio_report_result": self._report_result,
                "conscio_pending": lambda a, _ha=ha: _ha.pending(
                    self._int_arg(a, "limit", 20)),
                "conscio_approve": lambda a, _ha=ha: _ha.approve(
                    self._int_arg(a, "ledger_id")),
                "conscio_reject": lambda a, _ha=ha: _ha.reject(
                    self._int_arg(a, "ledger_id"), str(a.get("reason", ""))),
            })
        if self.hermes_review:
            tools["conscio_review"] = self._review_dispatch
            # E3: dispatch-only aliases — route alive, never advertised
            tools["conscio_reviews"] = self._reviews
            tools["conscio_review_approve"] = self._review_approve
            tools["conscio_review_reject"] = self._review_reject
            if self._act_enabled():
                tools["conscio_poll_reviews"] = self._poll_reviews
        if self.relay:
            tools["conscio_relay"] = self._relay_dispatch
            tools["conscio_board"] = self._board_dispatch
            # E3: dispatch-only aliases — route alive, never advertised
            tools["conscio_relay_send"] = self._relay_send
            tools["conscio_relay_inbox"] = self._relay_inbox
            tools["conscio_relay_read"] = self._relay_read
            tools["conscio_relay_broadcast"] = self._relay_broadcast
            tools["conscio_relay_peers"] = self._relay_peers_tool
            if self.can_create_halls:      # v4.5: Agent's Hall tools
                tools["conscio_hall"] = self._hall_dispatch
                # E3: dispatch-only aliases — route alive, never advertised
                tools["conscio_hall_create"] = self._hall_create
                tools["conscio_hall_list"] = self._hall_list
                tools["conscio_hall_join"] = self._hall_join
                tools["conscio_hall_leave"] = self._hall_leave
                tools["conscio_hall_members"] = self._hall_members
                tools["conscio_hall_send"] = self._hall_send
                tools["conscio_hall_manage"] = self._hall_manage
        tools["conscio_mode"] = self._mode_toggler   # existe em todo modo
        return tools

    def _mode_toggler(self, args: dict) -> dict:
        """Read the tool surface, or switch it and tell the host to re-list.

        The write is persisted before ``self.mode`` moves: if the disk write
        fails the session keeps serving the surface the host already has, and
        no listChanged is emitted for a switch that did not happen.
        """
        unknown = set(args) - {"set"}
        if unknown:
            raise j.InvalidParams(
                f"unknown argument(s) {sorted(unknown)}; the only parameter is "
                f"'set' (one of {list(modes.MODES)}); omit it to read the mode")
        requested = args.get("set")
        if requested is not None:
            if requested not in modes.MODES:
                raise j.InvalidParams(
                    f"unknown mode {requested!r}; expected one of {modes.MODES}")
            if requested != self.mode:
                modes.write_mode(self.engine.storage, requested)
                self.mode = requested
                self.enqueue_notification("notifications/tools/list_changed")
        return {"mode": self.mode,
                "tools": len(self.tool_defs()),
                "modes": list(modes.MODES)}

    def _int_arg(self, args: dict, key: str,
                 default: int | None = None) -> int:
        if key not in args:
            if default is not None:
                return default
            raise j.InvalidParams(f"missing '{key}'")
        val = args[key]
        if isinstance(val, bool) or not isinstance(val, int):  # not str/float/None
            raise j.InvalidParams(f"'{key}' must be an integer")
        return val

    def _report_result(self, args: dict) -> dict:
        ledger_id = self._int_arg(args, "ledger_id")
        result = self._require(args, "result")
        if not isinstance(result, dict):
            raise j.InvalidParams("result must be an object")
        ha = self.engine.host_act
        assert ha is not None  # only callable via act tools
        return ha.report(ledger_id, result)

    # ── v2.6.0 Liaison: reviewer side (pure mailbox; no host_act) ──
    def _reviews(self, args: dict) -> list[dict]:
        limit = self._int_arg(args, "limit", 50)
        rows = mailbox.inbox(self.liaison_db, self.self_instance_id,
                             types=["review_request"], unread_only=True,
                             limit=limit)
        out: list[dict] = []
        seen_fp: set[str] = set()
        for m in rows:                       # newest-first -> first per fp = latest
            try:
                rq = review.parse_request(m["payload"])
            except ValueError:
                continue
            if rq.fp in seen_fp:
                continue
            seen_fp.add(rq.fp)
            out.append({"fp": rq.fp, "from_instance": m["from_instance"],
                        "tool": rq.tool, "args": rq.args, "goal": rq.goal,
                        "verdict": rq.verdict, "ts": m["ts"]})
        return out

    def _review_approve(self, args: dict) -> dict:
        return self._send_verdict(args, "approve")

    def _review_reject(self, args: dict) -> dict:
        return self._send_verdict(args, "reject")

    def _send_verdict(self, args: dict, decision: str) -> dict:
        fp = self._require(args, "fp")
        reason = str(args.get("reason", ""))
        rows = mailbox.inbox(self.liaison_db, self.self_instance_id,
                             types=["review_request"], unread_only=True,
                             limit=200)
        match = [m for m in rows if (m["payload"] or {}).get("fp") == fp]
        if not match:
            return {"ok": False, "reason": "unknown_fp"}
        proposer = match[0]["from_instance"]
        verdict = review.build_verdict(fp=fp, decision=decision, reason=reason)
        # v4.5.4: the verdict travels the same road as any other message —
        # the proposer reads only its OWN db, so writing it here would be a
        # verdict nobody ever reads. Unreached ⇒ the request stays unread and
        # the reviewer can retry, instead of a decision lost in silence.
        delivered, why = self._deliver_to_peer(proposer, "review_verdict",
                                               verdict, self._identity() or None)
        if not delivered:
            return {"ok": False, "fp": fp, "reason": why}
        mailbox.send(self.liaison_db, from_instance=self.self_instance_id,
                     to_instance=proposer, type="review_verdict",
                     payload=verdict)
        mailbox.mark_read(self.liaison_db, [m["id"] for m in match])  # all fp rows
        return {"ok": True, "fp": fp, "decision": decision, "to": proposer}

    # ── v2.6.0 Liaison: proposer side ──
    def _maybe_publish_review(self, result: dict) -> None:
        if not (self.hermes_review and self.reviewers):
            return
        if result.get("status") != "pending_approval":
            return
        if result.get("approval_policy") != "hermes_review":
            return
        row = self.engine.host_act.ledger.get(result["ledger_id"]) if self.engine.host_act else None
        if row is None:
            return
        args = self._row_args(row)
        fp = review.fingerprint(self.self_instance_id, row["goal_fp"],
                                row["tool"], args, row["id"])
        payload = review.build_request(
            fp=fp, tool=row["tool"], args=args,
            goal=row.get("goal_text", ""), verdict=row.get("verdict", ""),
            rationale=row.get("rationale", ""))
        identity = self._identity() or None
        for r in self.reviewers:      # best-effort: the act is already ledgered
            try:                      # pending; publishing the request is 2nd
                delivered, why = self._deliver_to_peer(r, "review_request",
                                                       payload, identity)
                if not delivered:     # a reviewer nobody can reach is a fact
                    print(f"liaison: review_request to {r} not delivered: {why}",
                          file=sys.stderr)
                    continue
                mailbox.send(self.liaison_db, from_instance=self.self_instance_id,
                             to_instance=r, type="review_request", payload=payload)
            except Exception as exc:               # never break act on a bad mailbox
                print(f"liaison: review_request publish failed: {exc}",
                      file=sys.stderr)

    @staticmethod
    def _row_args(row: dict) -> dict:
        try:
            args = json.loads(row.get("args_json") or "{}")
        except (TypeError, ValueError):
            return {}
        return args if isinstance(args, dict) else {}

    def _poll_reviews(self, args: dict) -> list[dict]:
        limit = self._int_arg(args, "limit", 50)
        return review_apply.apply_verdicts(
            self.engine.host_act, self.liaison_db, self.self_instance_id,
            self.reviewers, limit=limit)

    def _maybe_auto_apply(self) -> None:
        """v2.6.2: when armed (--auto-review) and the engine is awake, apply
        inbound allowlisted verdicts to pending acts. Inert without act/reviewers;
        never raises into a request (a bad mailbox must not break a tool call)."""
        if not (self.auto_review and getattr(self.engine, "awake", False)):
            return
        if self.engine.host_act is None or not self.reviewers:
            return
        now = time.monotonic()               # v2.6.3 #2: pace the SQL poll
        if now - self.last_auto_apply_ts < AUTO_APPLY_THROTTLE_S:
            return
        self.last_auto_apply_ts = now
        try:
            review_apply.apply_verdicts(self.engine.host_act, self.liaison_db,
                                        self.self_instance_id, self.reviewers)
        except Exception as exc:             # never break a request
            print(f"auto-review apply failed: {exc}", file=sys.stderr)

    # ── v2.6.1 Relay: general cross-agent messaging (pure mailbox; no engine) ──
    def _relay_send(self, args: dict) -> dict:
        to = str(args.get("to", ""))
        mtype = str(args.get("type", ""))
        payload = args.get("payload", {})
        self._ensure_registered()                     # v4.5: presença
        try:
            relay.validate_send(to=to, type=mtype, payload=payload,
                                peers=self._resolve_peers())
        except ValueError as exc:
            return {"ok": False, "reason": str(exc)}
        identity = self._identity() or None           # v4.5: envelope
        delivered, reason = self._deliver_to_peer(to, mtype, payload, identity)
        if not delivered:
            return {"ok": False, "reason": reason}
        # Local copy is the OUTBOX and only exists after an accepted delivery
        # (v4.5.4 A4): a row claiming "sent" with nothing delivered is the lie
        # that made every past debugging session start from a false premise.
        mid = mailbox.send(self.liaison_db, from_instance=self.self_instance_id,
                           to_instance=to, type=mtype, payload=payload,
                           identity=identity)
        self._retention_tick()
        out: dict = {"ok": True, "id": mid, "to": to}
        # v4.7.2: a direct send to a dormant peer is honoured — the sender
        # named it — but not silently: "ok" alone reads as "it will be seen".
        from ..liaison import directory
        warnings = [reason] if reason else []
        silent = directory.dormant_for(directory.get(to))
        if silent is not None:
            warnings.append(f"{to} has been silent for {silent / 86400:.0f}d;"
                            " the message is parked until it comes back")
        if warnings:
            out["warning"] = "; ".join(warnings)
        return out

    def _retention_tick(self) -> None:
        """R2 best-effort retention, on the send path.

        Three things age, not one: read messages, quarantine, and — since
        v4.7.2 — the directory. The quarantine had no collector until v4.5.4
        (A7); `directory.prune` existed and was tested, but nothing in
        production ever called it, so extinct cards kept attracting mail.
        Never raises: retention must not break delivery."""
        try:
            mailbox.purge_read(self.liaison_db, relay.RETENTION_DAYS)
            mailbox.purge_quarantine(self.liaison_db,
                                     older_than_days=relay.RETENTION_DAYS)
        except Exception as exc:
            print(f"liaison: relay purge failed: {exc}", file=sys.stderr)
        try:
            from ..liaison import directory
            directory.prune()
        except Exception as exc:
            print(f"liaison: directory prune failed: {exc}", file=sys.stderr)

    def _deliver_to_peer(self, to: str, mtype: str, payload: dict,
                         identity: dict | None,
                         hall: dict | None = None) -> tuple[bool, str]:
        """Hand one message to the peer's own address. Returns (ok, reason).

        Single delivery path for send / broadcast / hall fan-out: three copies
        of "how do I reach a peer" is how one of them keeps writing into a db
        nobody reads. On success ``reason`` is empty, or a note the sender
        should see — a remote peer that did not answer gets its mail parked
        here for it to pull, and "ok" alone would read as "it arrived".
        """
        from ..liaison import directory, relay_transport
        card = directory.get(to)
        if card is None:
            return False, f"peer {to} is not in the directory"
        envelope = {"from": self.self_instance_id, "to": to, "type": mtype,
                    "payload": mailbox.with_envelope(payload, identity, hall)}
        route = relay_transport.deliver_route(card, envelope)
        if not route:
            return False, f"peer {to} unreachable"
        if route == relay_transport.PARKED:
            return True, (f"{to} did not answer at {card.get('url')}; the message"
                          " is parked in this host's spool for it to pull")
        return True, ""

    def _recall_observations(self, args: dict) -> dict:
        """FTS search over observations, scoped to this session unless widened.

        A bad scope is the caller's mistake, so it comes back as INVALID_PARAMS
        with the reason — "internal error" would give an agent nothing to correct.
        """
        from ..obsstore import project_root

        query = self._require(args, "query")
        k = int(args.get("k", 5))
        full = bool(args.get("full", False))
        scope = str(args.get("scope", "session"))
        raw_project = str(args.get("project", "")).strip()
        raw_sid = str(args.get("session_id", "")).strip()

        resolved_sid = ""
        session_source = ""
        if raw_project:
            expanded = os.path.expanduser(raw_project)
            project = project_root(expanded) if os.path.exists(expanded) else raw_project
        else:
            project = ""

        if scope == "session":
            if raw_sid:
                resolved_sid = raw_sid
                session_source = "explicit"
            elif getattr(self.engine, "_session_explicitly_set", False):
                resolved_sid = getattr(self.engine, "_obs_session", "")
                session_source = "explicit"
            else:
                target_project = project or project_root(os.getcwd())
                resolved_sid = self.engine.latest_session_for_project(target_project)
                if not resolved_sid and not raw_project:
                    resolved_sid = self.engine.latest_session_for_project("")
                if not resolved_sid:
                    raise j.InvalidParams(
                        "scope='session' requires a session_id or an existing "
                        f"observation in project {target_project!r}"
                    )
                session_source = "latest_in_project"

        try:
            found = self.engine.recall_observations(
                query,
                k,
                full,
                scope,
                project,
                session_id=resolved_sid,
            )
        except ValueError as exc:
            raise j.InvalidParams(str(exc)) from exc

        res: dict[str, Any] = {"observations": found}
        if scope == "session":
            res["session_id"] = resolved_sid
            res["session_source"] = session_source
        return res

    def _relay_broadcast(self, args: dict) -> dict:
        """v2.8.2: fan-out a relay message to ALL allowlisted peers. Best-effort
        per peer (a failing peer never aborts the rest); a mailbox write, never
        host_act -> daemon-perceives/server-acts holds.

        v4.7.2: a LOCAL peer silent past DORMANT_AFTER_S is skipped and listed
        in `skipped`, never dropped quietly. Remote and card-less peers are
        not judged: their age is unknowable from here."""
        from ..liaison import directory
        mtype = str(args.get("type", ""))
        payload = args.get("payload", {})
        self._ensure_registered()                     # v4.5: presença
        peers = self._resolve_peers()
        identity = self._identity() or None           # v4.5: envelope
        sent: list[dict] = []
        errors: list[dict] = []
        skipped: list[dict] = []
        for peer in sorted(peers):
            silent = directory.dormant_for(directory.get(peer))
            if silent is not None:
                skipped.append({"to": peer, "reason":
                                f"dormant: silent for {silent / 86400:.0f}d"})
                continue
            try:
                relay.validate_send(to=peer, type=mtype, payload=payload,
                                    peers=peers)
            except ValueError as exc:
                errors.append({"to": peer, "reason": str(exc)})
                continue
            try:
                delivered, reason = self._deliver_to_peer(peer, mtype, payload,
                                                          identity)
                if not delivered:
                    errors.append({"to": peer, "reason": reason})
                    continue
                mid = mailbox.send(self.liaison_db,
                                   from_instance=self.self_instance_id,
                                   to_instance=peer, type=mtype,
                                   payload=payload, identity=identity)
            except Exception as exc:      # per-peer isolation: keep fanning out
                errors.append({"to": peer,
                               "reason": f"send failed: {type(exc).__name__}"})
                continue
            entry = {"to": peer, "id": mid}
            if reason:                    # e.g. parked for an unreachable peer
                entry["warning"] = reason
            sent.append(entry)
        if sent:                                  # best-effort retention, once
            self._retention_tick()
        return {"ok": True, "sent": sent, "errors": errors, "skipped": skipped}

    def _board_dispatch(self, args: dict) -> dict:
        """v4.8 S3: the actor is ALWAYS this server's identity (§8, no `as=`).
        Refusals come back as {"ok": false, "error": <exact text>}: the agent
        has to read them, and a JSON-RPC error would hide the text."""
        from ..ambient import surface
        return surface.run_op(args, actor=self.self_instance_id or "",
                              space=Path(self.engine.storage))

    def _relay_dispatch(self, args: dict) -> dict:
        """E3 (ADR-20260913133108-1fac9c): one dispatcher for the five relay
        verbs. The op is an argument; the route is the tool. The individual
        names stay in _tools() as dispatch-only aliases (zero MethodNotFound
        for scripted hosts) but are not advertised in tools/list — that is
        where the ADR's byte savings live."""
        op = self._require(args, "op")
        handler = {
            "send":      lambda: self._relay_send(args),
            "inbox":     lambda: self._relay_inbox(args),
            "read":      lambda: self._relay_read(args),
            "broadcast": lambda: self._relay_broadcast(args),
            "peers":     lambda: self._relay_peers_tool(args),
        }.get(op)
        if handler is None:
            raise j.InvalidParams(
                f"unknown op {op!r}; expected one of "
                f"send|inbox|read|broadcast|peers")
        return handler()

    def _hall_dispatch(self, args: dict) -> dict:
        """E3: one dispatcher for the seven hall verbs, same alias policy as
        _relay_dispatch."""
        op = self._require(args, "op")
        handler = {
            "create":  lambda: self._hall_create(args),
            "list":    lambda: self._hall_list(args),
            "join":    lambda: self._hall_join(args),
            "leave":   lambda: self._hall_leave(args),
            "members": lambda: self._hall_members(args),
            "send":    lambda: self._hall_send(args),
            "manage":  lambda: self._hall_manage(args),
        }.get(op)
        if handler is None:
            raise j.InvalidParams(
                f"unknown op {op!r}; expected one of "
                f"create|list|join|leave|members|send|manage")
        return handler()

    def _review_dispatch(self, args: dict) -> dict:
        """E3: one dispatcher for the four reviewer verbs."""
        op = self._require(args, "op")
        handler = {
            "reviews": lambda: self._reviews(args),
            "approve": lambda: self._review_approve(args),
            "reject":  lambda: self._review_reject(args),
            "poll":    lambda: self._poll_reviews(args),
        }.get(op)
        if handler is None:
            raise j.InvalidParams(
                f"unknown op {op!r}; expected one of "
                f"reviews|approve|reject|poll")
        return handler()

    def _relay_inbox(self, args: dict) -> dict:
        # Reception is symmetric with sending: the same peer source on both
        # sides, and the spool is drained first — nobody writes into my db.
        self._ensure_registered()
        limit = self._int_arg(args, "limit", 50)
        # v4.6 fix (a): the reactor marks messages read on INGESTION
        # (reactor.py:173) before the agent ever looks. Default legibility
        # stays unread_only=True, but a host that runs a reactor needs
        # unread_only=False + since_id to read its own inbox by tool instead
        # of going to SQLite directly.
        unread_only = not (args.get("unread_only") is False)
        since_id = args.get("since_id")
        if since_id is not None and (isinstance(since_id, bool)
                                     or not isinstance(since_id, int)):
            raise j.InvalidParams("'since_id' must be an integer")
        rows = mailbox.inbox(self.liaison_db, self.self_instance_id,
                             types=None, unread_only=unread_only,
                             since_id=since_id, limit=limit)
        peers = self._resolve_peers()
        out: list[dict] = []
        junk: list[int] = []
        for r in rows:
            if r.get("type") in relay.RESERVED_TYPES:
                continue                          # review channel owns it
            if relay.is_relay_message(r, peers):
                out.append({k: r[k] for k in
                            ("id", "from_instance", "type", "payload", "ts")})
            else:
                junk.append(r["id"])              # non-peer / oversized
        if junk:
            mailbox.mark_read(self.liaison_db, junk)
        return {"messages": out}

    def _relay_read(self, args: dict) -> dict:
        ids = [i for i in args.get("ids", [])
               if isinstance(i, int) and not isinstance(i, bool)]  # R1-menor
        n = mailbox.mark_read(self.liaison_db, ids)
        return {"ok": True, "marked": n}

    # ── v4.5: identidade do runtime + descoberta dinâmica de peers ──────

    def _identity(self) -> dict:
        """Runtime identity envelope (v4.5). Empty {} when self_instance_id is
        absent — never invents identity from the body."""
        if not self.self_instance_id:
            return {}
        return {
            "id": self.self_instance_id,
            "modelo": self.identity_model,
            "familia": self.identity_familia,
            "runtime": self.identity_runtime,
            "papel": self.identity_papel,
        }

    def _relay_peers_tool(self, args: dict) -> dict:
        """Contrapartida obrigatória de tirar a allowlist manual: se o humano
        não configura mais peer na mão, o agente precisa descobrir o `to`.

        Chaves de saída em inglês (regra do projeto); o cartão em disco mantém
        os nomes legados `modelo/familia/papel` — a tradução é aqui, na borda,
        e não numa migração de formato no meio da v4.5.4."""
        from ..liaison import directory
        allowed = self._resolve_peers()
        cards = {c.get("instance_id", ""): c
                 for c in directory.peers(exclude=self.self_instance_id)}
        out = []
        for cid in sorted(allowed):
            card = cards.get(cid, {})
            if not card:
                # nomeado à mão e sem cartão local: alcançável por remotes.json,
                # mas mentir "local" mandaria o doctor procurar spool que não há
                reach = "unknown"
            else:
                reach = "remote" if card.get("url") else "local"
            out.append({
                "instance_id": cid,
                "model": card.get("modelo", ""),
                "family": card.get("familia", ""),
                "runtime": card.get("runtime", ""),
                "role": card.get("papel", ""),
                "alive": directory.is_live(card) if card else False,
                "reachability": reach,
                # peer nomeado em --relay-peer que nunca publicou cartão aqui:
                # continua endereçável (remotes.json), mas o agente precisa ver
                # que não sabemos nada sobre ele.
                "known": bool(card),
            })
        return {"peers": out, "self": self.self_instance_id,
                "card_error": self.card_error,
                "squad": self._squad_state(),
                "reactor": self._reactor_state()}

    def _squad_state(self) -> dict:
        """Who leads, and what am I. The role model shipped in v4.5 with the
        invariant enforced and nobody asking — an answer nobody reads is the
        same as no answer (A10)."""
        from ..liaison import roles
        return {"orchestrator": roles.who_is_orchestrator(self.liaison_db),
                "my_role": roles.get_role(self.liaison_db,
                                          self.self_instance_id)}

    def _reactor_state(self) -> dict:
        """Reactivity is invisible when it works and, until v4.5.4, also when
        it broke: the loop kept `last_error` for a `relay_health` that never
        existed. "Por que não fui notificado?" now has a place to look."""
        r = self.reactor_thread
        if r is None or not r.is_alive():
            return {"running": False}
        return {"running": True, "ticks": r.ticks, "last_error": r.last_error}

    def _publish_card(self) -> None:
        """Publica o endereço público no diretório. Throttled (I6). Falha não
        derruba a chamada, mas fica em self.card_error — agente invisível que
        se acha visível é a falha silenciosa que R1 proíbe."""
        from ..liaison import directory
        now = time.monotonic()
        if self._card_ts and now - self._card_ts < CARD_REPUBLISH_S:
            return
        self._card_ts = now
        try:
            # membership (halls) é do agente e sobrevive ao republish (Task 3b)
            # v4.6.7: o servidor é o único escritor autoritativo do espaço —
            # ele é o único destes processos que o resolveu. O reactor publica
            # sem o argumento e herda o valor já no cartão.
            # `self.engine` itself may be absent: a Bindings built for card
            # publishing alone has no engine, and an agent must stay findable
            # either way. No engine simply means no space to publish — the card
            # still goes out, and the field is left to whatever already held it.
            storage = getattr(getattr(self, "engine", None), "storage", None)
            # v4.6.8: o servidor SABE a identidade (sempre escreve) e o espaço
            # (escreve quando resolveu). Sem storage, space=None preserva o
            # campo — escrever "" apagaria o que um servidor anterior resolveu.
            directory.publish_self(
                self.self_instance_id,
                modelo=self.identity_model, familia=self.identity_familia,
                runtime=self.identity_runtime, papel=self.identity_papel,
                space=str(storage) if storage else None)
            self.card_error = ""
        except Exception as exc:
            self.card_error = f"cartão não publicado: {exc}"

    def _sync_directory_registry(self) -> None:
        """Projeta os cartões do diretório na tabela `agents` local. Com o db
        por agente, ninguém mais escreve no meu banco — sem esta projeção, o
        observatory e `conscio_agents` param de enxergar a sociedade."""
        from ..liaison import agents, directory
        # Oldest card first. register_agent enforces one orchestrator by
        # demoting the incumbent, so the LAST claim projected is the one that
        # survives — in directory order that was whoever sorted last by id.
        # Ordering by the card's own timestamp makes the freshest claim win.
        cards = sorted(directory.peers(exclude=self.self_instance_id),
                       key=lambda c: float(c.get("updated_at") or 0.0))
        for card in cards:
            cid = card.get("instance_id")
            if not cid:
                continue
            try:
                agents.register_agent(
                    self.liaison_db, instance_id=cid,
                    model=card.get("modelo", ""), familia=card.get("familia", ""),
                    runtime=card.get("runtime", ""), papel=card.get("papel", ""),
                    capabilities=tuple(card.get("capabilities") or ("relay",)),
                    status="alive" if directory.is_live(card) else "stale",
                    # o heartbeat é o do CARTÃO, não `agora`: projetar com o
                    # relógio local faria peer morto parecer vivo para sempre
                    heartbeat=float(card.get("updated_at") or 0.0))
            except Exception:
                continue          # um cartão ruim não derruba a projeção

    def announce_presence(self) -> None:
        """Publish the card as soon as the server boots (v4.5.4 C2).

        An agent that only becomes addressable after its FIRST tool call is
        invisible exactly when a peer tries to reach it first — the "he is not
        in the directory" that every plug-and-play attempt died on.
        """
        if not (self.relay or self.can_create_halls):
            return
        try:
            self._ensure_registered()
        except Exception as exc:      # boot must survive a broken directory
            print(f"liaison: presence announce failed: {exc}", file=sys.stderr)

    def _ensure_registered(self) -> None:
        """Self-register + refresh presence + publica o cartão (v4.5.4 C2)."""
        if not self.self_instance_id:
            return
        self._publish_card()
        try:                                   # drain my spool into my db
            from ..liaison import spool
            spool.ingest(self.liaison_db, self.self_instance_id)
        except Exception as exc:               # a stuck spool is not fatal,
            print(f"liaison: spool ingest failed: {exc}",   # but never silent
                  file=sys.stderr)
        try:
            from ..liaison import agents
            agents.register_agent(
                self.liaison_db, instance_id=self.self_instance_id,
                model=self.identity_model, familia=self.identity_familia,
                runtime=self.identity_runtime, papel=self.identity_papel,
                capabilities=("relay",), status="alive")
            self._sync_directory_registry()
        except Exception:
            pass

    def _resolve_peers(self) -> set[str]:
        """Peers do DIRETÓRIO (v4.5.4 C2), sem filtro de vivacidade: o spool é
        arquivo, peer parado continua endereçável. --relay-peer deixa de ser
        REQUISITO e vira RESTRIÇÃO opcional; vazio = todos do diretório.

        Nomeou peers ⇒ é exatamente esse conjunto. Não é interseção com o
        diretório: peer de OUTRA máquina (remotes.json, via Tailscale) não tem
        cartão aqui, e interseção o apagaria em silêncio — que é a falha que
        esta versão existe para acabar."""
        from ..liaison import directory
        allow = {p for p in self.relay_peers if p and p != self.self_instance_id}
        if allow:
            return allow
        return {c["instance_id"] for c in directory.peers(
            exclude=self.self_instance_id) if c.get("instance_id")}

    # ── v4.5: Agent's Hall tools ──────────────────────────────────────

    def _hall_fail(self, motivo: str) -> dict:
        return {"ok": False, "motivo": motivo}

    def _send_to_peer(self, *, from_instance: str, to_instance: str, type: str,
                      payload: dict, identity: dict | None = None,
                      hall: dict | None = None) -> int:
        """One delivery point for the hall fan-out — halls.py resolves names
        and never learns about transport. Raises so the caller's per-peer
        isolation counts an unreachable member as NOT delivered (R1)."""
        delivered, reason = self._deliver_to_peer(to_instance, type, payload,
                                                  identity, hall)
        if not delivered:
            raise RuntimeError(reason)
        return mailbox.send(self.liaison_db, from_instance=from_instance,
                            to_instance=to_instance, type=type,
                            payload=payload, identity=identity, hall=hall)

    def _halls_ready(self) -> bool:
        """Migração preguiçosa: quem nunca usa hall não paga nada."""
        if not self.self_instance_id:
            return False
        if not self._halls_migrated:
            self._halls_migrated = True
            try:
                from ..liaison import halls
                halls.migrate_from_db(self.liaison_db, self.self_instance_id)
            except Exception:
                pass                     # legado ilegível nunca trava a sessão
        return True

    def _hall_create(self, args: dict) -> dict:
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        if not self.can_create_halls:
            return self._hall_fail("agente sem permissao de criar hall")
        name = str(args.get("name", "")).strip()
        if not name:
            return self._hall_fail("name vazio")
        self._ensure_registered()        # publica o cartão: create exige dono visível
        invited = [str(i) for i in (args.get("invited") or [])]
        try:
            h = halls.create_hall(owner=self.self_instance_id, name=name,
                                  policy=str(args.get("policy", "open")),
                                  invited=invited)
        except (ValueError, PermissionError) as exc:
            return self._hall_fail(str(exc))
        if h is None:
            return self._hall_fail("hall duplicado")
        return {"ok": True, "hall": h}

    def _hall_list(self, args: dict) -> dict:
        from ..liaison import directory, halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        card = directory.get(self.self_instance_id) or {}
        joined = list(card.get("halls") or [])
        out = [d for d in halls.list_halls()
               if d["hall_id"] in joined or d.get("owner") == self.self_instance_id]
        # hall sem doc (id combinado, dono ainda não criou) continua listado:
        # o cartão é a verdade sobre a MINHA participação
        seen = {d["hall_id"] for d in out}
        out += [{"hall_id": h, "name": h, "owner": "", "members": []}
                for h in joined if h not in seen]
        return {"ok": True, "halls": out}

    def _hall_join(self, args: dict) -> dict:
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        hall_id = str(args.get("hall_id", "")).strip()
        self._ensure_registered()        # sem cartão publicado não há o que declarar
        try:
            ok = halls.join(instance_id=self.self_instance_id, hall_id=hall_id)
        except ValueError as exc:
            return self._hall_fail(str(exc))
        return {"ok": ok, "hall_id": hall_id}

    def _hall_leave(self, args: dict) -> dict:
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        hall_id = str(args.get("hall_id", "")).strip()
        try:
            ok = halls.leave(instance_id=self.self_instance_id, hall_id=hall_id)
        except ValueError as exc:
            return self._hall_fail(str(exc))
        return {"ok": ok, "hall_id": hall_id}

    def _hall_members(self, args: dict) -> dict:
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        hall_id = str(args.get("hall_id", "")).strip()
        if not hall_id:
            return self._hall_fail("hall_id vazio")
        alive_only = bool(args.get("alive_only", True))
        members = halls.members_of(hall_id, alive_only=alive_only)
        return {"ok": True, "hall_id": hall_id, "members": members}

    def _hall_send(self, args: dict) -> dict:
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        hall_id = str(args.get("hall_id", "")).strip()
        mtype = str(args.get("type", ""))
        payload = args.get("payload", {})
        if not hall_id or not mtype or not isinstance(payload, dict):
            return self._hall_fail("hall_id/type/payload invalidos")
        self._ensure_registered()
        identity = self._identity() or None
        try:
            n = halls.send_to_hall(from_instance=self.self_instance_id,
                                   hall_id=hall_id, type=mtype, payload=payload,
                                   identity=identity,
                                   function=args.get("function") or None,
                                   send=self._send_to_peer)
        except ValueError as exc:        # função desconhecida chega ao agente
            return self._hall_fail(str(exc))
        return {"ok": True, "delivered": n}

    def _hall_manage(self, args: dict) -> dict:
        """As três ações do dono são a mesma operação — ele reescrevendo o doc
        dele — com a mesma checagem e o mesmo modo de falha."""
        from ..liaison import halls
        if not self._halls_ready():
            return self._hall_fail("sem self_instance_id")
        action = str(args.get("action", "")).strip()
        hall_id = str(args.get("hall_id", "")).strip()
        me = self.self_instance_id
        try:
            if action == "set_function":
                halls.set_function(hall_id=hall_id, owner=me,
                                   instance_id=str(args.get("instance_id", "")),
                                   function=str(args.get("function", "")))
                return {"ok": True, "hall": halls.get_hall(hall_id)}
            if action == "import":
                ids = [str(i) for i in (args.get("instance_ids") or [])]
                n = halls.import_members(hall_id=hall_id, owner=me,
                                         instance_ids=ids)
                return {"ok": True, "imported": n,
                        "hall": halls.get_hall(hall_id)}
            if action == "transfer":
                halls.transfer_owner(hall_id=hall_id, current_owner=me,
                                     new_owner=str(args.get("new_owner", "")))
                return {"ok": True, "hall": halls.get_hall(hall_id)}
        except (ValueError, PermissionError) as exc:
            return self._hall_fail(str(exc))
        return self._hall_fail(f"action invalida: {action!r}")

    def _intercept(self, args: dict) -> dict:
        """Evaluate a safe expression via the Intercepter AST evaluator.

        If the expression is an equation (contains ``=``) and ``solve`` is
        true (default when no variables are provided), automatically solve
        for the unknown variable using sympy.
        """
        from conscio.agency.intercepter import Intercepter, _latex_to_python

        expr = self._require(args, "expression")
        variables = args.get("variables") or {}
        solve_flag = args.get("solve")

        # Auto-enable solve when: expression has '=', no variables given,
        # and solve not explicitly set to false.
        has_eq = '=' in expr and '==' not in expr
        auto_solve = has_eq and not variables and solve_flag is not False
        if solve_flag is True:
            auto_solve = True

        # Equation solving path (requires sympy)
        if auto_solve:
            try:
                import sympy
                from sympy import Eq
                from sympy import solve as sym_solve
                from sympy.parsing.sympy_parser import (
                    implicit_multiplication_application,
                    parse_expr,
                    standard_transformations,
                )
                transformations = standard_transformations + (
                    implicit_multiplication_application,
                )

                # Convert LaTeX if needed, or fix implied multiplication
                from conscio.agency.intercepter import _LATEX_MARKERS, _fix_implied_mult
                py_expr = expr
                if _LATEX_MARKERS.search(expr):
                    py_expr = _latex_to_python(expr)
                else:
                    # Fix plain expressions with ^ or implied mult (x^2, 2x)
                    py_expr = _fix_implied_mult(expr)

                if '=' in py_expr and '==' not in py_expr:
                    lhs_str, rhs_str = py_expr.split('=', 1)
                    lhs = parse_expr(lhs_str, transformations=transformations)
                    rhs = parse_expr(rhs_str, transformations=transformations)
                else:
                    lhs = parse_expr(py_expr, transformations=transformations)
                    rhs = sympy.Integer(0)

                # Find free symbols (the unknowns)
                free = lhs.free_symbols | rhs.free_symbols
                if len(free) == 0:
                    return {"ok": False, "error": "no variable found in expression",
                            "expression": expr}
                if len(free) > 1:
                    return {"ok": False,
                            "error": f"multiple variables found: {sorted(str(s) for s in free)}. "
                                     f"Provide values via 'variables' or use a single variable.",
                            "expression": expr}

                var = next(iter(free))  # exactly one: len 0 and >1 returned above
                eq = Eq(lhs, rhs)
                solutions = sym_solve(eq, var)
                if not solutions:
                    return {"ok": False, "error": "no solution found",
                            "expression": expr, "equation": str(eq)}
                
                def _sol_to_float(s):
                    """Safely convert sympy solution to float or string."""
                    try:
                        if hasattr(s, 'is_real') and s.is_real:
                            return float(s)
                        return str(s)
                    except (TypeError, ValueError):
                        return str(s)
                
                if len(solutions) == 1:
                    sol = solutions[0]
                    return {"ok": True, "expression": expr,
                            "equation": str(eq), "variable": str(var),
                            "result": _sol_to_float(sol),
                            "exact": str(sol)}
                else:
                    return {"ok": True, "expression": expr,
                            "equation": str(eq), "variable": str(var),
                            "result": [_sol_to_float(s) for s in solutions],
                            "exact": [str(s) for s in solutions]}
            except Exception:
                # Fall through to normal evaluation
                pass

        # Normal evaluation path
        itc = Intercepter()
        for name, value in variables.items():
            try:
                itc.set_variable(name, value)
            except ValueError as exc:
                return {"ok": False, "error": str(exc),
                        "expression": expr}

        tag = expr if expr.strip().startswith("[INTERCEPT:") else f"[INTERCEPT: {expr}]"
        result = itc.process(tag)

        # Extract the result value from the inline format
        if "[RESULT:" in result.text:
            value_str = result.text.split("[RESULT:")[1].rstrip("]")
            try:
                if "." in value_str or "e" in value_str.lower():
                    value: int | float | str = float(value_str)
                else:
                    value = int(value_str)
            except ValueError:
                value = value_str
        elif "[ERROR:" in result.text:
            error_msg = result.text.split("[ERROR:")[1].rstrip("]")
            return {"ok": False, "error": error_msg, "expression": expr}
        else:
            return {"ok": False, "error": "no result or error in output",
                    "expression": expr, "raw": result.text}

        return {"ok": True, "expression": expr, "result": value,
                "intercepted": result.intercepted, "count": result.count,
                "errors": [e for e in result.errors if e]}

    @staticmethod
    def _require(args: dict, key: str):
        if key not in args:
            raise j.InvalidParams(f"missing '{key}'")
        return args[key]

    def _remember(self, args: dict) -> dict:
        """Durable write into the same store conscio_recall reads from.

        Not note/feed: those land in the EventBus, which recall never reads.
        """
        text = self._require(args, "text")
        label = args.get("label") or "memory"
        source_id = self.engine.content_store.index(
            label=label,
            content=text,
            category="consciousness",
            session_id=getattr(self.engine, "_obs_session", ""))
        return {"stored": True, "id": source_id, "label": label}

    def _structure(self, args: dict) -> dict:
        """Report the currently loaded workspace structure (consent-gated).

        Read-only: the graph is synced at server startup (see
        _sync_structure_at_startup). Returns loaded=False when none is loaded.
        """
        sig = self.engine.structural_signal()
        if sig is None:
            return {"loaded": False}
        from conscio.structural import render_structural, structural_budget
        budget = structural_budget(self.engine.model_info.context_window)
        return {
            "loaded": True,
            "node_count": sig.node_count,
            "link_count": sig.link_count,
            "hyperedges": len(sig.hyperedges),
            "communities": len(sig.communities),
            "built_at_commit": sig.built_at_commit,
            "content_hash": sig.content_hash,
            "digest": render_structural(sig, budget),
        }

    def _structural_lookup(self, args: dict) -> dict:
        """Resolve a structural node / hyperedge / community id to detail."""
        key = self._require(args, "key")
        return {"result": self.engine.structural_lookup(str(key))}

    def _cognitive_cycle(self, args: dict) -> dict:
        """Run one explicit cognitive pass and return a per-stage report.

        The act stage runs only when act is enabled on this server; otherwise
        it is propose-only (reflect/synthesize/self-improve). Accepts
        session_tokens so the loop also feeds the metabolic tier.
        Output is chunkified via ModeRouter.
        """
        st = args.get("session_tokens")
        if isinstance(st, int) and not isinstance(st, bool) and st >= 0:
            self.engine.session_tokens_used = st
        raw = self.engine.cognitive_cycle(
            world_state=args.get("world_state", "") or "",
            act=self._act_enabled())
        return self._router.format_cognitive_cycle(raw)

    # ── v3.2 Memory tool handlers ────────────────────────────────────

    def _kg_query(self, args: dict) -> dict:
        """Query the Knowledge Graph for entity/relationship info."""
        from conscio.kg import KnowledgeGraph
        name = args.get("name", "")
        if not name:
            return {"error": "name required"}
        kg_path = self.engine.storage / "kg.db" if hasattr(self.engine, "storage") else None
        if kg_path is None or not kg_path.exists():
            return {"entity": None, "relationships": [], "timeline": []}
        kg = KnowledgeGraph(db_path=kg_path)
        entity = kg.query_entity(name)
        relationships = kg.query_relationship(name)
        timeline = kg.timeline(name)
        kg.close()
        return {
            "entity": entity,
            "relationships": [dict(r) for r in relationships] if relationships else [],
            "timeline": [dict(t) for t in timeline] if timeline else [],
        }

    def _kg_build(self, args: dict) -> dict:
        """Run KG builder incrementally to extract entities from ContentStore."""
        from conscio.content_store import ContentStore
        from conscio.kg import KnowledgeGraph
        from conscio.kg_builder import KGBuilder

        sp = self.engine.storage if hasattr(self.engine, "storage") else None
        if sp is None:
            return {"error": "no storage_path configured"}

        cs = ContentStore(db_path=sp / "content_store.db")
        kg = KnowledgeGraph(db_path=sp / "kg.db")
        builder = KGBuilder(cs, kg)
        limit = int(args.get("limit", 500))
        result = builder.run(limit=limit)
        kg.close()
        cs.close()
        return result

    def _wings_search(self, args: dict) -> dict:
        """Search content by wing/room hierarchy."""
        from conscio.content_store import ContentStore
        from conscio.wings import WingManager
        query = args.get("query", "")
        if not query:
            return {"error": "query required"}
        wing = args.get("wing")
        limit = int(args.get("limit", 5))
        cs_path = self.engine.storage / "content_store.db" if hasattr(self.engine, "storage") else None
        hw_path = self.engine.storage / "hallways.db" if hasattr(self.engine, "storage") else None
        if cs_path is None or not cs_path.exists():
            return {"results": []}
        cs = ContentStore(db_path=cs_path)
        wm = WingManager(hallways_db=str(hw_path), content_store=cs)
        results = wm.search(query, wing=wing, limit=limit)
        items = [{"title": r.title, "content": r.content[:200], "rank": r.rank} for r in results]
        wm.close()
        cs.close()
        return {"results": items}

    def _export(self, args: dict) -> dict:
        """Export Conscio memory to tar.gz archive."""
        from conscio.hallways import Hallways
        from conscio.kg import KnowledgeGraph
        from conscio.migration import export_archive
        path = args.get("path", "")
        if not path:
            return {"error": "path required"}
        sp = self.engine.storage if hasattr(self.engine, "storage") else None
        if sp is None:
            return {"error": "no storage_path configured"}
        self.engine.content_layer if hasattr(self.engine, "content_layer") else None
        kg_path = sp / "kg.db" if (sp / "kg.db").exists() else None
        hw_path = sp / "hallways.db" if (sp / "hallways.db").exists() else None
        kg = KnowledgeGraph(db_path=kg_path) if kg_path else None
        hw = Hallways(db_path=hw_path) if hw_path else None
        cs_obj = getattr(self.engine, "content_layer", None)
        store = getattr(cs_obj, "store", None) if cs_obj else None
        meta = export_archive(path, content_store=store, kg=kg, hallways=hw)
        if kg:
            kg.close()
        if hw:
            hw.close()
        return {"metadata": meta}

    def _normalize_event(self, event: Any) -> Any:
        """Map host-side event aliases to the internal Event schema.

        The schema (schemas.py EVENT_SCHEMA) requires ``type``, ``source``,
        ``category`` and ``payload``. Hosts that predate the schema — or use
        different conventions — send ``data`` instead of ``payload`` and omit
        ``source``. This normalises those aliases *before* validation so the
        caller does not need to know the internal field names. Fields already
        in schema form pass through unchanged.

        Never raises: if the input is not a dict, it is returned as-is and
        validate_event will produce the appropriate error.
        """
        if not isinstance(event, dict):
            return event
        # Copy so the caller's dict is not mutated.
        out = dict(event)
        # data -> payload (the one field hosts commonly alias).
        if "payload" not in out and "data" in out:
            out["payload"] = out["data"]
        # source defaults to "host" when absent.
        if "source" not in out:
            out["source"] = "host"
        # category defaults to the type when absent (common in host reports).
        if "category" not in out and "type" in out:
            out["category"] = out["type"]
        return out

    def _feed(self, args: dict) -> dict:
        event = self._normalize_event(self._require(args, "event"))
        errors = validate_event(event)
        if errors:
            raise j.InvalidParams("; ".join(errors))
        eid = derive_event_id(event)
        prior = self.seen.seen(eid)
        if prior is not None:
            return json.loads(prior)
        # Host-reported live context usage feeds the metabolic tier. Reject
        # bad values (bools are ints; negatives) so a malformed field can't
        # poison the tier. Absent -> engine keeps its prior/None (healthy).
        st = args.get("session_tokens")
        if isinstance(st, int) and not isinstance(st, bool) and st >= 0:
            self.engine.session_tokens_used = st
        world_state = event_to_frame(event).to_world_state()
        self.engine.perceive(world_state)
        self.engine.reflect(world_state)
        result = {"event_id": eid, "advisory": self.engine.advisory()}
        self.seen.mark(eid, json.dumps(result),
                       float(event.get("ts") or time.time()))
        return result

    def _note(self, args: dict) -> dict:
        event = self._normalize_event(self._require(args, "event"))
        errors = validate_event(event)
        if errors:
            raise j.InvalidParams("; ".join(errors))
        eid = derive_event_id(event)
        prior = self.seen.seen(eid)
        if prior is not None:
            return json.loads(prior)
        self.engine.event_bus.emit(
            type="host:event", category="external",
            data={"host_type": event["type"],
                  "host_category": event["category"],
                  "source": event["source"],
                  "payload": event.get("payload", {}) or {}})
        result = {"event_id": eid, "noted": True}
        self.seen.mark(eid, json.dumps(result),
                       float(event.get("ts") or time.time()))
        return result

    def _act(self, args: dict) -> dict:
        intent = self._require(args, "intent")
        if not isinstance(intent, dict):
            raise j.InvalidParams("intent must be an object")
        key = intent.get("idempotency_key")
        skey = None
        if key is not None:
            if not isinstance(key, str) or len(key) > 256:
                raise j.InvalidParams("idempotency_key must be a str <= 256 chars")
            skey = f"act:{self.workspace_id}:{intent.get('tool', '')}:{key}"
            prior = self.seen.seen(skey)
            if prior is not None:
                return json.loads(prior)
        result = self.engine.host_act.propose(intent) if self.engine.host_act else {"status": "error", "message": "act not enabled"}
        if skey is not None:
            self.seen.mark(skey, json.dumps(result), time.time())
        self._maybe_publish_review(result)
        return result

    # ── read-only state payloads (shared by resources + tools, v2.4) ──
    def _state_payload(self) -> dict:
        import dataclasses
        st = self.engine.state
        payload = dataclasses.asdict(st)
        # context_mode é um enum; asdict o deixa cru (não-serializável e inútil
        # pro host). Normaliza pra .value em vez de vazar o enum.
        cm = payload.get("context_mode")
        if cm is not None and hasattr(cm, "value"):
            payload["context_mode"] = cm.value
        return payload

    def _events_payload(self, params: dict) -> list[dict]:
        def s(key: str) -> str | None:
            v = params.get(key)
            return str(v) if v not in (None, "") else None
        try:
            limit = int(params.get("limit", 50))
        except (TypeError, ValueError):
            limit = 50
        rows = self.engine.event_bus.query(
            type=s("type"), category=s("category"), since=s("since"), limit=limit)
        return [e.to_dict() for e in rows]

    def _handoff_payload(self) -> str:
        return self._handoff_text()

    # ── resources ──
    def read_resource(self, uri: str) -> dict:
        parsed = urlparse(uri)
        base = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
        if base == "conscio://advisory":
            return self._json_resource(uri, self.engine.advisory())
        if base == "conscio://state":
            return self._json_resource(uri, self._state_payload())
        if base == "conscio://events":
            q = parse_qs(parsed.query)
            params = {k: (v[0] if v else None) for k, v in q.items()}
            return self._json_resource(uri, self._events_payload(params))
        if base == "conscio://handoff":
            return {"contents": [{"uri": uri, "mimeType": "text/markdown",
                                 "text": self._handoff_payload()}]}
        raise j.InvalidParams(f"unknown resource '{uri}'")

    @staticmethod
    def _json_resource(uri: str, data: Any) -> dict:
        return {"contents": [{"uri": uri, "mimeType": "application/json",
                             "text": json.dumps(data)}]}

    def _handoff_text(self) -> str:
        path = Path(self.engine.storage) / "handoff" / "_session_handoff.md"
        try:
            return path.read_text()
        except OSError:
            return ""


def serve(bindings: Bindings, instream, outstream, *,
          max_bytes: int = j.DEFAULT_MAX_FRAME_BYTES) -> None:
    dispatcher = Dispatcher(bindings)
    bindings.announce_presence()      # addressable from boot, not from use
    for frame in j.read_frames(instream, max_bytes):
        if frame is j.OVERSIZE:
            _write(outstream, j.make_error(None, j.INVALID_REQUEST,
                                           "frame too large"))
            continue
        try:
            msg = json.loads(frame)
        except json.JSONDecodeError:
            _write(outstream, j.make_error(None, j.PARSE_ERROR, "parse error"))
            continue
        if not isinstance(msg, dict):
            _write(outstream, j.make_error(None, j.INVALID_REQUEST,
                                           "request must be an object"))
            continue
        response = dispatcher.handle(msg)
        if response is not None:
            _write(outstream, response)
        for note in bindings.drain_notifications():
            _write(outstream, note)


def _write(outstream, obj: dict) -> None:
    outstream.write(json.dumps(obj) + "\n")
    outstream.flush()


def _build_adapter(spec: str):
    """spec forms: 'mock' | 'ollama:<model>'."""
    from conscio.agency import MockAdapter, OllamaAdapter
    if spec == "mock":
        return MockAdapter(script=[])
    if spec.startswith("ollama:"):
        return OllamaAdapter(model=spec.split(":", 1)[1])
    raise SystemExit(f"unsupported --adapter '{spec}'")


def _arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="conscio-mcp",
                                     description="Conscio MCP stdio server")
    parser.add_argument("--storage", default=None)
    parser.add_argument("--model", default=None,
                        help="model name, 'auto' for auto-detect, or omit")
    parser.add_argument("--base-url", default=None,
                        help="OpenAI-compatible endpoint to probe")
    parser.add_argument("--adapter", default=None)
    parser.add_argument("--max-frame-bytes", type=int,
                        default=j.DEFAULT_MAX_FRAME_BYTES)
    parser.add_argument("--seen-max-rows", type=int, default=10_000)
    parser.add_argument("--seen-max-age-days", type=int, default=30)
    parser.add_argument("--enable-act", action="store_true",
                        help="enable opt-in host-executed audited act")
    parser.add_argument("--awake", action="store_true",
                        help="set the engine Awake at startup (act gate)")
    parser.add_argument("--enable-hermes-review", action="store_true",
                        help="enable opt-in cross-agent hermes_review comms")
    parser.add_argument("--reviewer", action="append", default=[],
                        metavar="INSTANCE_ID",
                        help="trusted reviewer instance_id (repeatable)")
    parser.add_argument("--liaison-db", default=None,
                        help="mailbox db path (default $CONSCIO_HOME/liaison.db)")
    parser.add_argument("--enable-relay", action="store_true",
                        help="enable opt-in general cross-agent messaging")
    parser.add_argument("--relay-peer", action="append", default=[],
                        metavar="INSTANCE_ID",
                        help="trusted relay peer instance_id (repeatable); "
                             "v4.5: seed/fallback — authority vira o registro")
    parser.add_argument("--identity-model", default="",
                        help="v4.5: modelo do runtime (ex: claude-opus-5); "
                             "no envelope, não no corpo")
    parser.add_argument("--identity-familia", default="",
                        help="v4.5: familia do modelo (ex: claude, gemini)")
    parser.add_argument("--identity-runtime", default="",
                        help="v4.5: runtime (ex: claude-code/2.x)")
    parser.add_argument("--identity-papel", default="",
                        help="v4.5: papel (ex: executor, researcher)")
    parser.add_argument("--can-create-halls", action="store_true",
                        help="v4.5: habilita tools do Agent's Hall "
                             "(agente pode criar grupos/equipes)")
    parser.add_argument("--auto-review", action="store_true",
                        help="auto-apply inbound review verdicts each request "
                             "when awake (needs --enable-act + "
                             "--enable-hermes-review)")
    parser.add_argument("--lite", action="store_true",
                        help="lite mode: strip verbose descriptions from tool "
                             "schemas to reduce token usage for small models "
                             "(Qwen 0.8B, etc.). Saves ~80%% of schema tokens.")
    parser.add_argument("--mode", choices=modes.MODES, default=None,
                        help="tool surface: lite (10), balanced (19), high (21) "
                             "or ultra (all 37). A mode persisted in the space "
                             "wins over this flag; a fresh install defaults to "
                             "balanced, an existing install keeps its own.")
    parser.add_argument("--default-model", default=None, metavar="NAME",
                        help="model name used ONLY when --model, config.json and "
                             "$CONSCIO_MODEL are all empty (last resort)")
    return parser


def _resolve_model(args) -> str:
    """Resolve the model name: --model > config.json 'model' > CONSCIO_MODEL > --default-model.

    v3.1: --model auto triggers auto-detection from the LM Studio /v1/models
    endpoint. Tests each model with a minimal prompt and returns the first
    that responds. Persists the winner to ~/.config/conscio/config.json so
    the next boot skips detection.

    Mirrors the daemon's precedence so a host that registers ``conscio-mcp``
    with only ``--storage`` (e.g. the Claude Code bundle) still picks up the
    ``model`` from ~/.config/conscio/config.json instead of failing to start.
    Raises ``ValueError`` when none of the four channels supplies a model —
    ``--default-model`` is the last resort, consulted only after the other
    three have failed, so a plugin install with no local config still boots.
    """
    from conscio.adapter_config import load_config
    from conscio.models import resolve_model_name

    # v3.1: auto-detect mode
    if args.model == "auto":
        detected, all_models = _auto_detect_model(args.base_url)
        if detected is not None:
            _persist_model(detected)
            # Store all_models for FallbackAdapter construction in main()
            args._auto_fallback_models = all_models
            return detected
        # fall through to normal resolution if auto-detect failed

    try:
        return resolve_model_name(cli_arg=args.model if args.model != "auto" else None,
                                  config_model=load_config().get("model"))
    except ValueError:
        fallback = getattr(args, "default_model", None)   # last-resort channel
        if not fallback:
            raise
        return fallback


def _auto_detect_model(base_url: str | None) -> tuple[str | None, list[str]]:
    """v3.1: Auto-detect working models from the LM Studio /v1/models endpoint.

    Returns (first_working_model, all_chat_models).
    The first_working_model is used for immediate startup; all_chat_models
    is used to build a FallbackAdapter chain.
    """
    import json as _json
    import urllib.request

    url = (base_url or "http://localhost:1234/v1").rstrip("/")
    models_url = f"{url}/models"

    try:
        req = urllib.request.Request(models_url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = _json.loads(resp.read())
    except Exception as exc:
        print(f"[conscio-mcp] auto-detect: cannot reach {models_url}: {exc}",
              file=sys.stderr)
        return None, []

    models = data.get("data", [])
    if not models:
        print("[conscio-mcp] auto-detect: no models available", file=sys.stderr)
        return None, []

    # Filter out embedding models (they can't do chat completions)
    chat_models = [
        m["id"] for m in models
        if "embed" not in m["id"].lower()
        and "nomic" not in m["id"].lower()
    ]

    if not chat_models:
        print("[conscio-mcp] auto-detect: no chat models found (all embedding?)",
              file=sys.stderr)
        return None, []

    print(f"[conscio-mcp] auto-detect: {len(chat_models)} chat models found: "
          f"{', '.join(chat_models[:5])}{'...' if len(chat_models) > 5 else ''}",
          file=sys.stderr)

    # Test each model with a minimal prompt to find the first that works
    for model_id in chat_models:
        if _test_model(url, model_id):
            print(f"[conscio-mcp] auto-detect: '{model_id}' responded OK",
                  file=sys.stderr)
            return model_id, chat_models
        print(f"[conscio-mcp] auto-detect: '{model_id}' failed, trying next...",
              file=sys.stderr)

    print("[conscio-mcp] auto-detect: no model responded to test prompt",
          file=sys.stderr)
    return None, chat_models


def _test_model(base_url: str, model_id: str) -> bool:
    """Send a minimal chat completion to test if a model is working."""
    import json as _json
    import urllib.request

    payload = _json.dumps({
        "model": model_id,
        "messages": [{"role": "user", "content": "Respond with: ok"}],
        "max_tokens": 5,
        "temperature": 0.0,
        "stream": False,
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            f"{base_url}/chat/completions",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = _json.loads(resp.read())
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            return len(text.strip()) > 0
    except Exception:
        return False


def _persist_model(model_id: str) -> None:
    """v3.1: Persist the detected model to ~/.config/conscio/config.json.

    So the next boot skips auto-detection and starts instantly.
    """
    import os
    from pathlib import Path

    config_dir = Path(os.path.expanduser("~/.config/conscio"))
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.json"

    existing = {}
    if config_path.exists():
        try:
            import json as _json
            with open(config_path) as f:
                existing = _json.load(f)
        except Exception:
            existing = {}

    existing["model"] = model_id

    try:
        import json as _json
        with open(config_path, "w") as f:
            _json.dump(existing, f, indent=2)
        print(f"[conscio-mcp] auto-detect: persisted '{model_id}' to {config_path}",
              file=sys.stderr)
    except Exception as exc:
        print(f"[conscio-mcp] auto-detect: failed to persist config: {exc}",
              file=sys.stderr)


def _sync_structure_at_startup(engine, workspace) -> str:
    """Bring the engine's structure in line with consent for ``workspace``.

    The daemon does this each cycle; the MCP server (Claude Code) serves one
    workspace per process, so it syncs once at startup. Consent-gated and
    non-fatal — a missing/OFF consent or a bad graph never blocks startup.
    Returns sync_structure's status verb, or ``skip:<err>``.
    """
    from conscio.structural_consent import (
        StructuralConsent,
        consent_path,
        sync_structure,
    )
    try:
        consent = StructuralConsent(consent_path(engine.storage))
        return sync_structure(engine, workspace, consent)
    except Exception as exc:                       # never block startup
        return f"skip:{exc}"


def resolve_identity(storage, *, hermes_review: bool, relay_on: bool,
                     liaison_db_arg: str = "") -> tuple[str, Path | None]:
    """Identity for a server that will expose relay or review tools.

    Keyed on the RESOLVED capability, never on the CLI flag. v4.6.5 moved
    consent into the space and left this condition on ``args.enable_relay``,
    so the marketplace path -- which carries no flag -- exposed relay tools
    with an empty sender: ``mailbox.inbox(db, "")`` matches nothing and
    ``halls.create_hall(owner="")`` would own nothing.

    ``halls`` is deliberately absent from the condition: ``Bindings`` derives
    ``can_create_halls = can_create_halls and relay``, because a hall delivers
    through the relay mailbox. Halls without relay is already off, so adding it
    here would load an identity for a configuration that serves no tool.
    """
    if not (hermes_review or relay_on):
        return "", None
    from conscio.noosphere.identity import load_or_create
    self_id = load_or_create(storage).instance_id
    return self_id, mailbox.resolve_db(storage, liaison_db_arg,
                                       self_id=self_id)


def resolve_identity_env(*, model: str, familia: str, runtime: str,
                         papel: str) -> tuple[str, str, str, str]:
    """Fill absent identity flags from CONSCIO_IDENTITY_* env vars.

    Precedence: CLI flag > env var > "" (today's default). Hosts that cannot
    override MCP args (e.g. plugin-shipped configs) set the env instead —
    per-host identity without touching the shared asset (the Agnes/ZCode
    gap, relay #778: the server republishes with explicit "" and wipes a
    rich card when no flag and no env is present).
    """
    env = os.environ
    return (
        model or env.get("CONSCIO_IDENTITY_MODEL", ""),
        familia or env.get("CONSCIO_IDENTITY_FAMILIA", ""),
        runtime or env.get("CONSCIO_IDENTITY_RUNTIME", ""),
        papel or env.get("CONSCIO_IDENTITY_PAPEL", ""),
    )


def resolve_full_identity(*, model: str, familia: str, runtime: str,
                          papel: str, env: os._Environ | dict | None = None) -> tuple[str, str, str, str]:
    """Complete 4-tier identity precedence: flag > env > host derivation > "".

    Fills absent identity fields using resolve_identity_env(), then derives any
    remaining empty fields from the process environment via derive_host_identity().
    Familia is derived strictly from a known model name (never forced).
    """
    e = os.environ if env is None else env
    # Step 1: flag > CONSCIO_IDENTITY_* env
    m = model or e.get("CONSCIO_IDENTITY_MODEL", "")
    f = familia or e.get("CONSCIO_IDENTITY_FAMILIA", "")
    r = runtime or e.get("CONSCIO_IDENTITY_RUNTIME", "")
    p = papel or e.get("CONSCIO_IDENTITY_PAPEL", "")

    # Step 2: host derivation for any remaining empty fields
    if not (m and f and r and p):
        from .host_identity import derive_familia_from_model, derive_host_identity
        derived = derive_host_identity(e)
        m = m or derived.model
        f = f or derived.familia or (derive_familia_from_model(m) if m else "")
        r = r or derived.runtime
        p = p or derived.papel

    return (m, f, r, p)


def main(argv: list[str] | None = None) -> int:
    args = _arg_parser().parse_args(argv)
    from conscio.installer.binding import unexpanded_variable, validate_binding
    var = unexpanded_variable(args.storage)
    if var:                                        # v4.7.2: before any mkdir
        print(f"conscio-mcp: --storage {args.storage!r} still contains the "
              f"variable {var}, so the host that launched this server did not "
              "substitute it (Claude Code and zcode do; other hosts running "
              "the plugin asset may not). Refusing to start rather than "
              f"create a phantom space under {os.getcwd()}. Give this host an "
              "absolute --storage path in its own MCP config.",
              file=sys.stderr)
        return 2

    ident = resolve_full_identity(
        model=args.identity_model, familia=args.identity_familia,
        runtime=args.identity_runtime, papel=args.identity_papel)

    # S1 Durable Space resolution
    if args.storage:
        from conscio.installer.durable import (
            plugin_pointer_path,
            remove_refused_marker,
            resolve_space,
            write_pointer_atomic,
            write_refused_marker,
        )
        from conscio.installer.spaces import minting_lock, slugify

        storage_arg = Path(args.storage)
        res = resolve_space(storage_arg)
        if res.target is None:
            write_refused_marker(storage_arg, state=res.kind, reason=res.reason)
            print(f"conscio-mcp: {res.reason}", file=sys.stderr)
            return 2

        remove_refused_marker(storage_arg)
        if res.announcement:
            print(f"conscio-mcp: {res.announcement}", file=sys.stderr)
        args.storage = str(res.target)

        if res.repair_pointer:
            slug = res.slug or slugify(ident[2] or "default")
            runtime = res.runtime or ident[2] or "default"
            with minting_lock(slug):
                ptr_path = plugin_pointer_path(storage_arg)
                if ptr_path:
                    write_pointer_atomic(
                        ptr_path,
                        target=res.target,
                        runtime=runtime,
                        slug=slug,
                    )

    validate_binding(args.storage)                 # R6
    try:
        model_name = _resolve_model(args)
    except ValueError:
        print("Error: no model specified. Set CONSCIO_MODEL, configure 'model' "
              "in config.json, or pass --model.", file=sys.stderr)
        return 1
    engine = ConsciousnessEngine(model_name, storage_path=args.storage,
                                  base_url=args.base_url)
    from conscio.adapter_config import build_adapter_from_config, load_config
    adapter_name = None
    if args.adapter:                               # CLI wins (mock | ollama:..)
        engine.attach_adapter(_build_adapter(args.adapter))
        adapter_name = args.adapter
    else:
        adapter, atype = build_adapter_from_config(load_config(),
                                                   fallback_model=model_name)
        if adapter is not None:
            engine.attach_adapter(adapter)
            adapter_name = atype
    if args.awake:
        engine.wake()                              # reuse the existing R9 toggle
    # v3.1: if auto-detect found multiple models, use FallbackAdapter
    fallback_models = getattr(args, "_auto_fallback_models", None)
    if fallback_models and len(fallback_models) > 1 and not args.adapter:
        from ..agency.fallback_adapter import FallbackAdapter
        base_url = args.base_url or "http://localhost:1234/v1"
        fb_adapter = FallbackAdapter(
            base_url=base_url, models=fallback_models,
        )
        engine.attach_adapter(fb_adapter)
        adapter_name = "fallback"
        print(f"[conscio-mcp] fallback chain: {' -> '.join(fallback_models[:5])}"
              f"{'...' if len(fallback_models) > 5 else ''}",
              file=sys.stderr)
    elif args.adapter:                               # CLI wins (mock | ollama:..)
        engine.attach_adapter(_build_adapter(args.adapter))
        adapter_name = args.adapter
    else:
        adapter, atype = build_adapter_from_config(load_config(),
                                                   fallback_model=model_name)
        if adapter is not None:
            engine.attach_adapter(adapter)
            adapter_name = atype
    workspace = WorkspaceContext().current()
    structure_status = _sync_structure_at_startup(engine, workspace)
    seen = SeenStore(Path(engine.storage) / "mcp_seen.db")
    seen.prune(args.seen_max_rows, args.seen_max_age_days)
    # v4.6.6: a capacidade resolvida decide, nao a flag. O caminho do
    # marketplace nao carrega --enable-relay: o consentimento mora no espaco
    # desde a v4.6.5, e a identidade tinha ficado presa na flag.
    relay_on = capabilities.resolve_capability(engine.storage, "relay",
                                               args.enable_relay)
    halls_on = capabilities.resolve_capability(engine.storage, "halls",
                                               args.can_create_halls)
    self_instance_id, liaison_db = resolve_identity(
        engine.storage, hermes_review=args.enable_hermes_review,
        relay_on=relay_on, liaison_db_arg=args.liaison_db)
    tool_mode = modes.resolve_mode(engine.storage, "lite" if args.lite else args.mode)
    bindings = Bindings(engine, seen, adapter_name=adapter_name,
                        workspace_id=workspace.id, act_flag=args.enable_act,
                        hermes_review=args.enable_hermes_review,
                        reviewers=tuple(args.reviewer),
                        self_instance_id=self_instance_id,
                        liaison_db=liaison_db,
                        relay=relay_on,
                        relay_peers=tuple(args.relay_peer),
                        auto_review=args.auto_review,
                        mode=tool_mode,
                        identity_model=ident[0],
                        identity_familia=ident[1],
                        identity_runtime=ident[2],
                        identity_papel=ident[3],
                        can_create_halls=halls_on)
    mode = "act" if args.enable_act else "propose-only"
    if args.enable_hermes_review:
        if args.reviewer:
            mode += f"+hermes-review(reviewers={len(args.reviewer)})"
        else:
            mode += "+hermes-review(reviewers=0; no publish targets)"
    if relay_on:            # v4.6.6: a capacidade resolvida, nao a flag --
        if args.relay_peer:  # quem concedeu pelo espaco via banner sem +relay
            # v4.5.4: an allowlist is now a restriction, not the peer list.
            mode += f"+relay(restricted to {len(args.relay_peer)} peers)"
        else:
            mode += "+relay(peers from directory)"
    if args.auto_review:
        mode += "+auto-review"
    if bindings.can_create_halls:
        mode += "+halls"
    elif bindings.halls_need_relay:
        # Asked for halls without relay: say so instead of serving seven tools
        # that answer "method not found".
        print("[conscio-mcp] --can-create-halls needs --enable-relay "
              "(a hall delivers through the relay); halls are off.",
              file=sys.stderr)
    print(f"conscio-mcp {__version__} ready "
          f"(workspace={workspace.id}, mode={mode}, "
          f"surface={tool_mode}, "        # v4.0: qual superfície venceu a precedência
          f"structure={structure_status})", file=sys.stderr)
    try:
        serve(bindings, sys.stdin, sys.stdout, max_bytes=args.max_frame_bytes)
    finally:
        seen.close()
        engine.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
