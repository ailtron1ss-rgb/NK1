"""
Goal Generator — Internal drives and intention generation.

The agent's ability to generate its own goals (not just respond to prompts).
Driven by three core drives:
- Curiosity: investigate anomalies and unknowns
- Maintenance: check system health and consistency
- Evolution: improve skills, memory, and processes
"""

from __future__ import annotations

import json
from datetime import datetime
from enum import Enum
from pathlib import Path


class Drive(Enum):
    CURIOSITY = "curiosity"       # Investigate anomalies, explore unknowns
    MAINTENANCE = "maintenance"   # Check health, verify consistency, clean up
    EVOLUTION = "evolution"       # Self-improve, optimize, learn


class GoalPriority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class GoalOrigin(str, Enum):
    """Provenance of a goal — decides whether the actor may auto-execute it (#7).

    The values ARE the existing free-form ``Goal.source`` strings, so the
    taxonomy maps onto stored goals with no migration. Executable origins are
    externally or environmentally grounded; diagnostic origins are
    self-referential / error / compaction-derived — visible to the host but
    never auto-run (the structural generalization of the v1.5.1 #6 slice).
    """

    USER = "user"               # explicit user request           -> executable
    INTERNAL = "internal"       # legacy/default drive goal        -> executable
    CURIOSITY = "curiosity"     # self-generated from a drive      -> executable
    ANOMALY = "anomaly"         # perceived world-model anomaly    -> executable
    MAINTENANCE = "maintenance"  # observed maintenance need       -> executable
    META_ERROR = "meta_error"   # meta-cognition / error-derived   -> diagnostic
    SELF_PROMPT = "self_prompt"  # goal proposing more goals       -> diagnostic
    COMPACTION = "compaction"   # context-compaction-derived       -> diagnostic

    @property
    def auto_executable(self) -> bool:
        return self in _EXECUTABLE_ORIGINS


_EXECUTABLE_ORIGINS = frozenset({
    GoalOrigin.USER, GoalOrigin.INTERNAL, GoalOrigin.CURIOSITY,
    GoalOrigin.ANOMALY, GoalOrigin.MAINTENANCE,
})


def origin_of(source: str) -> GoalOrigin:
    """Map a free-form source string to a GoalOrigin.

    Unrecognized (legacy) values fall back to INTERNAL (executable) so older
    goals.json files and any free-form source are never silently denied.
    """
    try:
        return GoalOrigin(source)
    except ValueError:
        return GoalOrigin.INTERNAL


class Goal:
    """A single goal with drive source, priority, and status."""

    # v4.8.1 (batch H): the maintenance description the engine regenerates.
    # Single source of truth: generate_from_maintenance builds its Goal with
    # this exact text, and the ledger key of that goal is
    # goal_fingerprint(MAINTENANCE_DAEMON_CHECK_DESCRIPTION). Calibration
    # derives the key from here (maintenance_goal_fingerprint) — a hand-copied
    # literal here or in calibration.py is how the cooldown went inert.
    MAINTENANCE_DAEMON_CHECK_DESCRIPTION = (
        "Maintenance: host health check — run diagnostics and record state")

    def __init__(
        self,
        description: str,
        drive: Drive,
        priority: GoalPriority = GoalPriority.MEDIUM,
        source: str = "internal",
        metadata: dict | None = None,
    ):
        self.id = f"{drive.value}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        self.description = description
        self.drive = drive
        self.priority = priority
        self.source = source  # "internal" or "user"
        self.status = "active"  # active | completed | cancelled | expired
        self.created_at = datetime.now().isoformat()
        self.cancelled_at: str | None = None  # when status became "cancelled"
        self.metadata = metadata or {}
        self.meta_score: float = 0.0  # MetaCognition-adjusted score (0-1)

    def compute_meta_score(self, confidence: float, calibration: float | None) -> float:
        """
        Adjust goal priority based on MetaCognition confidence and calibration.

        High confidence + high calibration = trust the goal (boost).
        Low confidence = be cautious (reduce).
        High confidence + low calibration = overconfident (penalize).
        When calibration is None (uncalibrated / cold start), neutral factor 1.0 (no penalty).

        Returns the computed score (0-1).
        """
        # Base: priority value normalized (1-4 → 0.25-1.0)
        base = self.priority.value / 4.0

        # Confidence factor: higher confidence → more trust in goal
        conf_factor = 0.5 + 0.5 * confidence  # range 0.5-1.0

        # Calibration penalty: overconfident → reduce
        if calibration is None:
            cal_penalty = 1.0
        else:
            cal_penalty = max(0.0, 1.0 - (1.0 - calibration) * 0.5)

        self.meta_score = min(1.0, base * conf_factor * cal_penalty)
        return self.meta_score

    @property
    def origin(self) -> GoalOrigin:
        """Provenance derived from ``source`` (#7). Legacy values -> INTERNAL."""
        return origin_of(self.source)

    @property
    def executable(self) -> bool:
        """Whether the actor may auto-execute this goal (#7 provenance gate)."""
        return self.origin.auto_executable

    @property
    def dedup_key(self) -> str:
        """What makes two goals *the same goal*, for deduplication.

        A maintenance goal keys on the check it runs, not on its description.
        The description embeds a live reading — "23 stale entities: a, b, c" —
        so one entity going stale renames the goal, and a rename is a new goal
        to anything comparing descriptions. The check being run is what is
        actually the same between cycles.
        """
        check = self.metadata.get("check_type")
        if self.drive == Drive.MAINTENANCE and check:
            return f"maintenance:{check}"
        return self.description

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "description": self.description,
            "drive": self.drive.value,
            "priority": self.priority.value,
            "source": self.source,
            "status": self.status,
            "created_at": self.created_at,
            "cancelled_at": self.cancelled_at,
            "metadata": self.metadata,
            "meta_score": self.meta_score,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Goal:
        goal = cls(
            description=data["description"],
            drive=Drive(data["drive"]),
            priority=GoalPriority(data.get("priority", 2)),
            source=data.get("source", "internal"),
            metadata=data.get("metadata", {}),
        )
        goal.id = data.get("id", goal.id)
        goal.status = data.get("status", "active")
        goal.created_at = data.get("created_at", goal.created_at)
        goal.cancelled_at = data.get("cancelled_at")
        goal.meta_score = data.get("meta_score", 0.0)
        return goal


class GoalGenerator:
    """
    Generates and manages internal goals based on drives.
    
    Goal lifecycle:
    1. Generated by a drive (curiosity, maintenance, evolution)
    2. Scored by: urgency × relevance × drive_strength
    3. Added to the active goals queue (max 10)
    4. Processed during inner monologue reflections
    5. Completed, cancelled, or expired (after 24h without progress)
    """

    MAX_ACTIVE_GOALS = 10

    # How long a cancellation silences the goal it killed. It expires because
    # `goal_update cancel` is a tool the agent can call on itself: a permanent
    # tombstone would let one bad call disable a maintenance check for the life
    # of the store, with no way back short of hand-editing goals.json.
    CANCEL_COOLDOWN_HOURS = 24

    def __init__(
        self,
        storage_path: Path,
        drive_strengths: dict[Drive, float] | None = None,
    ):
        self.path = storage_path / "goals.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

        # Drive strengths (0-1, how strongly each drive generates goals)
        self.drives = drive_strengths or {
            Drive.CURIOSITY: 0.7,
            Drive.MAINTENANCE: 0.8,
            Drive.EVOLUTION: 0.5,
        }

        self._goals: list[Goal] = self._load()

    def _load(self) -> list[Goal]:
        # B-013: a binary/non-UTF-8 file raises UnicodeDecodeError (a ValueError,
        # NOT a JSONDecodeError); a valid-but-non-list file would iterate wrong.
        # Broaden to ValueError + type guard so a corrupt/legacy goals.json
        # degrades to [] instead of crashing engine.__init__ (I-S4).
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                if isinstance(data, list):
                    return [Goal.from_dict(g) for g in data]
            except (OSError, ValueError, KeyError, TypeError, AttributeError):
                pass
        return []

    def _save(self) -> None:
        data = [g.to_dict() for g in self._goals]
        self.path.write_text(json.dumps(data, indent=2, ensure_ascii=False),
                             encoding="utf-8")

    # --- Goal Generation from Drives ---

    def generate_from_curiosity(self, anomaly: str, context: str = "", source: str = "internal") -> Goal | None:
        """
        Generate a curiosity-driven goal from an anomaly.
        
        Only creates the goal if the curiosity drive is strong enough
        and the anomaly seems worth investigating.
        """
        strength = self.drives.get(Drive.CURIOSITY, 0.5)
        if strength < 0.3:
            return None  # Drive too weak

        goal = Goal(
            description=f"Investigate: {anomaly}",
            drive=Drive.CURIOSITY,
            priority=GoalPriority.MEDIUM,
            source=source,
            metadata={"anomaly": anomaly, "context": context},
        )
        self._add_goal(goal)
        return goal

    def generate_from_maintenance(self, check_type: str, target: str, source: str = "internal") -> Goal | None:
        """
        Generate a maintenance-driven goal.

        `check_type` identifies the check for dedup (see Goal.dedup_key) and
        stays out of the description: it is an internal identifier, and an
        agent reading "Maintenance: prune_stale — 23 stale entities" gets a
        symbol and a reading where it needs an instruction. `target` carries
        the instruction.

        Examples: "check system health", "verify data consistency", "prune stale entries"

        v4.8.1 (batch H): the goal description is the SINGLE SOURCE the act
        ledger fingerprints (goal_fingerprint(description)). Calibration
        code that needs the ledger key of a maintenance goal derives it
        from the same construction below via
        ``maintenance_goal_fingerprint(check_type)`` — never a hand-copied
        string, which drifted from the real one and made the cooldown
        read a column that never matched (hostile review, lever 1).
        """
        strength = self.drives.get(Drive.MAINTENANCE, 0.5)
        if strength < 0.3:
            return None

        goal = Goal(
            description=f"Maintenance: {target}",
            drive=Drive.MAINTENANCE,
            priority=GoalPriority.HIGH,  # Maintenance is usually high priority
            source=source,
            metadata={"check_type": check_type, "target": target},
        )
        self._add_goal(goal)
        return goal

    def generate_from_evolution(self, improvement: str, target: str = "", source: str = "internal") -> Goal | None:
        """
        Generate an evolution-driven goal.
        
        Examples: "update skill X", "optimize process Y", "learn from failure Z"
        """
        strength = self.drives.get(Drive.EVOLUTION, 0.5)
        if strength < 0.3:
            return None

        goal = Goal(
            description=f"Evolve: {improvement}" + (f" — {target}" if target else ""),
            drive=Drive.EVOLUTION,
            priority=GoalPriority.LOW,  # Evolution is important but not urgent
            source=source,
            metadata={"improvement": improvement, "target": target},
        )
        self._add_goal(goal)
        return goal

    def add_user_goal(self, description: str,
                      priority: GoalPriority = GoalPriority.HIGH,
                      origin: GoalOrigin = GoalOrigin.USER) -> Goal:
        """Add a goal explicitly requested by the user.

        ``origin`` lets a host route provenance: the default USER is executable,
        but a host that knows the text is compaction-derived passes
        ``origin=GoalOrigin.COMPACTION`` so the actor never auto-runs it (#7).
        """
        goal = Goal(
            description=description,
            drive=Drive.CURIOSITY,  # User goals default to curiosity drive
            priority=priority,
            source=origin.value,
        )
        self._add_goal(goal, from_drive=False)
        return goal

    def _is_suppressed(self, key: str, *, tombstones: bool = True) -> bool:
        """Whether a goal with this dedup key is already queued or was just killed.

        A drive re-proposes its goals every cycle, so a proposal matching a goal
        the store already tracks is the same work coming back around. Cancelled
        counts as tracked for the cooldown above — otherwise cancelling is a
        no-op, which is how a broken maintenance goal became impossible to talk
        the daemon out of: cancel it, reflect, and it is back. "completed" and
        "expired" stay regenerable on purpose — a check that ran once should run
        again when its condition returns.
        """
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(hours=self.CANCEL_COOLDOWN_HOURS)
        for g in self._goals:
            if g.dedup_key != key:
                continue
            if g.status == "active":
                return True
            if g.status == "cancelled" and tombstones:
                try:
                    if datetime.fromisoformat(g.cancelled_at or "") >= cutoff:
                        return True
                except (ValueError, TypeError):
                    pass  # cancelled before this field existed: not suppressed
        return False

    def _add_goal(self, goal: Goal, *, from_drive: bool = True) -> None:
        """Add a goal to the queue, respecting the max limit.

        `from_drive` marks the proposals a drive makes on its own every cycle —
        the ones a cancellation is meant to silence. An explicit request is
        never silenced by an earlier cancel: asking for the thing again is how
        an operator undoes cancelling it.
        """
        if self._is_suppressed(goal.dedup_key, tombstones=from_drive):
            return

        self._goals.append(goal)

        # Enforce max active goals — expire lowest priority if over limit
        active = [g for g in self._goals if g.status == "active"]
        if len(active) > self.MAX_ACTIVE_GOALS:
            # Sort by (priority ascending, then oldest first)
            active.sort(key=lambda g: (g.priority.value, g.created_at))
            to_expire = len(active) - self.MAX_ACTIVE_GOALS
            for i in range(to_expire):
                active[i].status = "expired"

        self._save()

    # --- Goal Management ---

    def complete_goal(self, goal_id: str) -> bool:
        """Mark a goal as completed."""
        for g in self._goals:
            if g.id == goal_id:
                g.status = "completed"
                self._save()
                return True
        return False

    def cancel_goal(self, goal_id: str) -> bool:
        """Cancel a goal."""
        for g in self._goals:
            if g.id == goal_id:
                g.status = "cancelled"
                g.cancelled_at = datetime.now().isoformat()
                self._save()
                return True
        return False

    def active_goals(self, max_count: int = 5, sort_by_meta: bool = False) -> list[Goal]:
        """Get active goals sorted by priority (or meta_score if sort_by_meta)."""
        active = [g for g in self._goals if g.status == "active"]
        if sort_by_meta and any(g.meta_score > 0 for g in active):
            active.sort(key=lambda g: g.meta_score, reverse=True)
        else:
            active.sort(key=lambda g: g.priority.value, reverse=True)
        return active[:max_count]

    def is_executable(self, description: str) -> bool:
        """Provenance gate (#7): may the actor auto-execute the active goal with
        this description?

        Returns the goal's ``executable`` flag. An untracked description (a raw
        string from bench/tests, or any goal the generator never made) defaults
        to True — the gate only denies a *known diagnostic* goal, so back-compat
        is preserved.
        """
        for g in self._goals:
            if g.status == "active" and g.description == description:
                return g.executable
        return True

    def score_all_goals(self, confidence: float, calibration: float | None) -> None:
        """
        Apply MetaCognition confidence/calibration to all active goals.
        Updates each goal's meta_score in place.
        """
        for g in self._goals:
            if g.status == "active":
                g.compute_meta_score(confidence, calibration)
        self._save()

    def expire_stale(self, max_age_hours: int = 24) -> int:
        """Expire goals that haven't progressed in a while."""
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(hours=max_age_hours)
        expired = 0
        for g in self._goals:
            if g.status != "active":
                continue
            try:
                created = datetime.fromisoformat(g.created_at)
                if created < cutoff:
                    g.status = "expired"
                    expired += 1
            except (ValueError, TypeError):
                pass
        if expired > 0:
            self._save()
        return expired

    # --- Summary ---

    def summary(self, max_count: int = 3) -> str:
        """Compact summary for context injection."""
        active = self.active_goals(max_count)
        if not active:
            return "No active internal goals."

        parts = []
        for g in active:
            emoji = {"curiosity": "🔮", "maintenance": "🔧", "evolution": "🧬"}.get(g.drive.value, "→")
            parts.append(f"{emoji} {g.description}")

        return " | ".join(parts)

    def to_dict(self) -> list[dict]:
        return [g.to_dict() for g in self._goals]

    def status(self) -> dict:
        active = [g for g in self._goals if g.status == "active"]
        return {
            "total_goals": len(self._goals),
            "active_goals": len(active),
            "drive_strengths": {d.value: s for d, s in self.drives.items()},
            "path": str(self.path),
        }
