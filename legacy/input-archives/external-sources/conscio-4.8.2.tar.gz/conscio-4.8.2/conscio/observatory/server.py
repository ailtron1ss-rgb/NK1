# conscio/observatory/server.py
"""Conscio Observatory localhost HTTP server (stdlib only).

`route()` is a pure dispatch function (unit-tested without a socket). Read-only:
serves GET only — every mutation verb returns 405. Binds 127.0.0.1 by default;
never 0.0.0.0. Self-contained: does NOT import the Hub (kept decoupled), but
mirrors its proven loopback + constant-time-token idioms."""
from __future__ import annotations

import argparse
import hmac
import ipaddress
import json
import os
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .. import __version__
from ..noosphere.paths import conscio_home
from .halls_view import HallsProjection
from .knowledge_view import KnowledgeProjection
from .liaison_view import LiaisonProjection
from .projection import Projection
from .society import SocietyProjection
from .structural_view import StructuralProjection

_STATIC = Path(__file__).parent / "static"
_STATIC_WHITELIST = {"index.html", "app.js", "style.css", "d3.min.js", "graphview.js"}
_CONTENT_TYPES = {".html": "text/html", ".js": "application/javascript",
                  ".css": "text/css"}


def _workspace_id(root: Path) -> str:
    """Derive a stable workspace ID (sha256 of path, first 16 chars)."""
    import hashlib
    return hashlib.sha256(str(root).encode("utf-8")).hexdigest()[:16]
# Reference: conscio/noosphere/paths.py:conscio_home — keep in sync.
_HOME = conscio_home()
_DEFAULT_NOOSPHERE = _HOME / "noosphere.db"


@dataclass
class Resp:
    status: int
    payload: Any = None
    body: bytes | None = None
    content_type: str = "application/json"
    headers: dict = field(default_factory=dict)


def _err(status: int, error: str, detail: Any = None) -> Resp:
    return Resp(status, {"error": error, "detail": detail})


def _int(query: dict, key: str, default: int) -> int:
    try:
        return int(query.get(key, default))
    except (TypeError, ValueError):
        return default


def _bool(query: dict, key: str, default: bool = False) -> bool:
    v = query.get(key)
    if v is None:
        return default
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on")
    return bool(v)


def route(method: str, path: str, query: dict, *, projection: Projection,
          society: SocietyProjection, liaison: LiaisonProjection,
          halls: HallsProjection,
          structural: StructuralProjection,
          knowledge: KnowledgeProjection,
          token: str | None, auth: str | None,
          workspace_root: str | None = None) -> Resp:
    # read-only: no mutation verb is ever served
    if method not in ("GET", "HEAD"):
        return _err(405, "method not allowed", method)

    if path.startswith("/api/") and token:
        expected = f"Bearer {token}"
        if not (auth and hmac.compare_digest(auth, expected)):
            return _err(401, "unauthorized")

    if path == "/api/health":
        return Resp(200, {"ok": True, "version": __version__,
                          "storage": str(projection.storage),
                          "noosphere": str(society.db),
                          "liaison": str(liaison.db),
                          "token_required": bool(token)})
    if path == "/api/events":
        return Resp(200, projection.events(
            type=query.get("type") or None, category=query.get("category") or None,
            since=query.get("since") or None, limit=_int(query, "limit", 50)))
    if path == "/api/actions":
        return Resp(200, projection.actions(
            status=query.get("status") or None, limit=_int(query, "limit", 50)))
    if path == "/api/skills":
        return Resp(200, projection.skills(limit=_int(query, "limit", 100)))
    if path == "/api/goals":
        return Resp(200, projection.goals())
    if path == "/api/state":
        return Resp(200, projection.state())
    if path == "/api/society/members":
        return Resp(200, society.members())
    if path == "/api/society/skills":
        return Resp(200, society.skills(limit=_int(query, "limit", 100)))
    if path == "/api/society/records":
        return Resp(200, society.records(limit=_int(query, "limit", 100)))
    if path == "/api/daemon":
        return Resp(200, projection.daemon())
    if path == "/api/identity":
        return Resp(200, projection.identity())
    if path == "/api/relay/inbox":
        # relay-self = CONSCIO_SELF_ID (mesmo contrato do watcher/reactor),
        # fallback o instance_id do storage. As mensagens do relay são
        # endereçadas ao self do relay, NÃO ao id do storage (que é outro).
        self_id = (os.environ.get("CONSCIO_SELF_ID", "").strip()
                   or str(projection.identity().get("instance_id") or ""))
        return Resp(200, liaison.relay_inbox(self_id, limit=_int(query, "limit", 200)))

    # ── v4.5: agents + halls + mailboxes (read-only, tempo real) ─────
    if path == "/api/agents":
        return Resp(200, halls.agents(
            include_stale=_bool(query, "stale"),
            limit=_int(query, "limit", 200)))
    if path == "/api/halls":
        return Resp(200, halls.halls(
            owner=query.get("owner") or None))
    if path == "/api/hall_members":
        return Resp(200, halls.hall_members(
            str(query.get("hall_id") or ""),
            alive_only=not _bool(query, "stale"),
            limit=_int(query, "limit", 100)))
    if path == "/api/mailboxes":
        self_id = str(projection.identity().get("instance_id") or "")
        return Resp(200, halls.mailboxes(self_id,
                                         limit=_int(query, "limit", 200)))

    # ── structural + knowledge (v3.4) ──────────────────────────
    if path == "/api/structural/drift":
        return Resp(200, structural.drift_timeline(
            limit=_int(query, "limit", 20)))
    if path == "/api/structural/freshness":
        return Resp(200, structural.freshness(
            root=query.get("root")))
    if path == "/api/structural/graph":
        return Resp(200, structural.graph(
            root=query.get("root")))
    if path == "/api/knowledge/entities":
        return Resp(200, knowledge.entities(
            limit=_int(query, "limit", 100)))
    if path == "/api/knowledge/relationships":
        return Resp(200, knowledge.relationships(
            entity=query.get("entity"),
            limit=_int(query, "limit", 100)))
    if path == "/api/knowledge/timeline":
        entity = query.get("entity", "")
        return Resp(200, knowledge.timeline(
            entity=entity, limit=_int(query, "limit", 20)))

    if path == "/graph":
        root = query.get("root") or workspace_root or "."
        gpath = Path(root) / "graphify-out" / "graph.html"
        if not gpath.exists():
            return _err(404, "not found",
                        "graph.html not found — run `graphify update <root>` first")
        try:
            data = gpath.read_bytes()
        except OSError:
            return _err(404, "not found", "cannot read graph.html")
        return Resp(200, body=data, content_type="text/html")

    # v3.4.2: project discovery + per-project graph serving
    if path == "/api/consent":
        # v3.4.2: interactive consent status for all known workspaces
        from ..structural_consent import StructuralConsent, consent_path
        cp = consent_path(projection.storage)
        consent = StructuralConsent(cp)
        # Return all consent entries
        entries = [
            {"workspace_id": wid, "scope": s.value,
             "granted": s.value != "off"}
            for wid, s in consent._map.items()
        ]
        return Resp(200, entries)

    if path == "/api/projects":
        root = query.get("root") or workspace_root
        if not root or not Path(root).is_dir():
            return Resp(200, [])
        projects = []
        try:
            root_p = Path(root)
            # Check if the root itself has a graph
            gj = root_p / "graphify-out" / "graph.json"
            if gj.exists():
                try:
                    raw = json.loads(gj.read_text())
                    nodes = len(raw.get("nodes", []))
                    links = len(raw.get("links", []))
                except Exception:
                    nodes, links = 0, 0
                projects.append({
                    "id": root_p.name,
                    "name": root_p.name,
                    "path": str(root_p),
                    "ws_id": _workspace_id(root_p),
                    "has_graph": True,
                    "node_count": nodes,
                    "link_count": links,
                })
            # Check subdirectories
            for entry in sorted(root_p.iterdir()):
                if not entry.is_dir():
                    continue
                gj = entry / "graphify-out" / "graph.json"
                if not gj.exists():
                    continue
                try:
                    raw = json.loads(gj.read_text())
                    nodes = len(raw.get("nodes", []))
                    links = len(raw.get("links", []))
                except Exception:
                    nodes, links = 0, 0
                projects.append({
                    "id": entry.name,
                    "name": entry.name,
                    "path": str(entry),
                    "ws_id": _workspace_id(entry),
                    "has_graph": True,
                    "node_count": nodes,
                    "link_count": links,
                })
        except (OSError, PermissionError):
            pass
        return Resp(200, projects)

    import re as _re
    m = _re.match(r"^/api/projects/([^/]+)/graph$", path)
    if m:
        pid = m.group(1)
        root = workspace_root or "."
        root_p = Path(root)
        # If the pid matches the root dir name, graph is at root/graphify-out/
        if pid == root_p.name:
            gj = root_p / "graphify-out" / "graph.json"
        else:
            gj = root_p / pid / "graphify-out" / "graph.json"
        if not gj.exists():
            return _err(404, "not found", f"project '{pid}' has no graph.json")
        try:
            raw = json.loads(gj.read_text())
        except Exception as exc:
            return _err(500, "parse error", type(exc).__name__)
        return Resp(200, raw)

    if path == "/" or path.startswith("/static/"):
        name = "index.html" if path == "/" else path.rsplit("/", 1)[-1]
        if name not in _STATIC_WHITELIST:
            return _err(404, "not found", path)
        try:
            data = (_STATIC / name).read_bytes()
        except OSError:
            return _err(404, "not found", name)
        ct = _CONTENT_TYPES.get(Path(name).suffix, "application/octet-stream")
        return Resp(200, body=data, content_type=ct)

    return _err(404, "not found", path)


def _check_host(host: str) -> None:
    """Refuse any non-loopback bind — the Observatory binds loopback only.
    Reference: conscio/hub/server.py:_check_host — keep in sync on security changes."""
    if host == "localhost":
        return
    try:
        if ipaddress.ip_address(host).is_loopback:
            return
    except ValueError:
        pass
    raise ValueError(
        f"refusing non-loopback host {host!r}: Observatory binds loopback only")


def make_server(host: str, port: int, token: str | None,
                storage: Path, noosphere: Path,
                liaison: Path, *,
                workspace_root: str | None = None) -> ThreadingHTTPServer:
    _check_host(host)
    projection = Projection(storage)
    society = SocietyProjection(noosphere)
    liaison_proj = LiaisonProjection(liaison)
    halls_proj = HallsProjection(liaison)   # v4.5: agents + halls (mesmo db)
    structural = StructuralProjection(storage)
    knowledge = KnowledgeProjection(storage)

    class _H(Handler):
        _token = token
        _projection = projection
        _society = society
        _liaison = liaison_proj
        _halls = halls_proj
        _structural = structural
        _knowledge = knowledge
        _workspace_root = workspace_root or str(Path.cwd())

    return ThreadingHTTPServer((host, port), _H)


class Handler(BaseHTTPRequestHandler):
    _token: str | None = None
    _projection: Projection | None = None
    _society: SocietyProjection | None = None
    _liaison: LiaisonProjection | None = None
    _structural: StructuralProjection | None = None
    _knowledge: KnowledgeProjection | None = None
    _halls: HallsProjection | None = None
    _workspace_root: str = "."

    # Signature mirrors BaseHTTPRequestHandler's exactly, keyword name included:
    # a caller may pass format= and would otherwise hit a silent TypeError here.
    def log_message(self, format: str, *args: Any) -> None:
        """Never log — request URLs may carry tokens."""

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        proj = self._projection
        soc = self._society
        liai = self._liaison
        struct = self._structural
        know = self._knowledge
        halls = self._halls
        if proj is None or soc is None or liai is None or struct is None \
                or know is None or halls is None:
            return self._send(_err(500, "internal error", "no projection"))
        # v3.5: inject workspace_root fallback for /graph
        if parsed.path == "/graph" and "root" not in query:
            query["root"] = self._workspace_root
        try:
            resp = route(method, parsed.path, query, projection=proj,
                         society=soc, liaison=liai, halls=halls,
                         structural=struct, knowledge=know, token=self._token,
                         auth=self.headers.get("Authorization"),
                         workspace_root=self._workspace_root)
        except Exception as exc:               # no traceback leak
            resp = _err(500, "internal error", type(exc).__name__)
        self._send(resp, body=(method != "HEAD"))   # HEAD: headers only

    def _send(self, resp: Resp, *, body: bool = True) -> None:
        payload = resp.body if resp.body is not None else \
            json.dumps(resp.payload).encode("utf-8")
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        if body:                               # HEAD returns headers only, no body
            self.wfile.write(payload)

    def do_GET(self):
        self._dispatch("GET")

    def do_HEAD(self):
        self._dispatch("HEAD")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")


def _arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="conscio-observatory",
        description="Conscio Observatory — read-only localhost state viewer")
    p.add_argument("--storage", default="",
                   help="instance storage dir (default: the live space)")
    p.add_argument("--noosphere", default=str(_DEFAULT_NOOSPHERE),
                   help="host-shared noosphere.db (default: $CONSCIO_HOME/noosphere.db)")
    p.add_argument("--liaison-db", default="",
                   help="agent liaison.db (default: <storage>/liaison.db)")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8788)
    p.add_argument("--token",
                   default=os.environ.get("CONSCIO_OBSERVATORY_TOKEN") or None)
    return p


def main(argv: list[str] | None = None) -> int:
    args = _arg_parser().parse_args(argv)
    # v4.5.4 C1: mesmo resolvedor do servidor MCP e do daemon — o Observatory
    # nunca deve olhar um db que ninguém escreve.
    # v4.6.7: this standalone entrypoint had its own default — a third
    # divergent resolver, and one that did not even honour CONSCIO_HOME.
    from ..liaison.mailbox import resolve_db
    from ..space import resolve_live_space
    storage = resolve_live_space(args.storage).path
    liaison_db = resolve_db(storage, args.liaison_db)
    try:
        server = make_server(args.host, args.port, args.token,
                             storage, Path(args.noosphere),
                             liaison_db)
    except ValueError as exc:
        print(f"conscio-observatory: {exc}")
        return 2
    print(f"conscio-observatory on http://{args.host}:{args.port} "
          f"(storage={args.storage}, read-only)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0
