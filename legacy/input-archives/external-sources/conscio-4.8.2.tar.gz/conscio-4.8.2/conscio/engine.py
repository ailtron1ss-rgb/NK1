"""
ConsciousnessEngine — Orchestrates all consciousness modules.

The central coordinator that:
1. Detects the current model and context mode
2. Initializes all modules (Inner Monologue, World Model, Meta-Cognition, Goals, Evolution)
3. Runs the perception-reflection-generation loop
4. Manages state persistence and context injection
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .auto_evolution import AutoEvolution
from .auto_index import AutoIndexer
from .coherence import COHERENCE_EVENT_THRESHOLD, CoherenceEngine, CoherenceReport
from .content_layer import (
    ContentLayerManager,
)
from .content_store import ContentStore, VectorBackendType
from .context_manager import ContextManager
from .dreaming import DreamRecommendation
from .embedding_pipeline import EmbeddingPipeline
from .event_bus import EventBus
from .goal_generator import Drive, GoalGenerator
from .hybrid_retriever import HybridRetriever
from .inner_monologue import InnerMonologue
from .kg_builder import KGBuilder
from .meta_cognition import MetaCognition
from .metabolic import MetabolicContext
from .obsstore import agent_label as _obs_agent_label
from .obsstore import connect as _obs_connect
from .obsstore import put_observation as _obs_put
from .obsstore import search as _obs_search
from .output_filter import build_pipeline_from_dict
from .reflection_gate import MAX_ENTITIES_FOR_CONTRADICTION, GateContext, ReflectionGate
from .self_prompt import generate_self_prompts

# observe() retry: with --awake the daemon and agent write the same obs.db;
# a write landing inside the daemon's txn window can hit "database is locked"
# transiently. Retry with a short backoff before giving up (fire-and-forget).
_OBS_WRITE_RETRIES = 3
_OBS_RETRY_BACKOFF_S = 0.05
from .semantic import ContradictionDetector, SemanticEngine
from .session_lifecycle import SessionLifecycle
from .session_rag_factory import create_session_rag
from .shard_engine import ShardEngine
from .structural import (
    DEFAULT_MAX_BYTES,
    DEFAULT_MAX_NODES,
    StructuralDistiller,
    StructuralSignal,
    render_structural,
    structural_budget,
)
from .structural_drift import (
    StructuralDelta,
    StructuralDigest,
    StructuralDriftStore,
    StructuralFreshness,
    compute_delta,
    compute_freshness,
    drift_path,
)
from .timeutil import naive_utc_from_epoch, naive_utcnow
from .token_tracker import TokenTracker
from .vector_backend import VectorBackend, module_installed
from .voice_preset import resolve_voice_preset
from .world_extract import extract_entities, extract_relations
from .world_model import WorldModel

if TYPE_CHECKING:
    from .dreaming import DreamReport
    from .session_lifecycle import SessionSummary

logger = logging.getLogger(__name__)

# Output-filter pipeline limits (engine instance defaults).
_OUTPUT_MAX_LINES = 200
_OUTPUT_MAX_WIDTH = 8000

# Reflection-query cap used by the trust matrix reflect_count_fn.
_REFLECT_COUNT_LIMIT = 100_000

# DeepMiner recall/handoff shaping. A recall answers "where did I see this?",
# so it returns an FTS5 snippet window around the hit, not the 1KB row that
# happens to contain it. 32 tokens each side still reads as a full sentence.
_SNIPPET_TOKENS = 32
# Rows scanned when building a handoff: a hard ceiling well above what
# HO_MAX_CHARS can spend, so the char budget (not this) decides the cut.
_HANDOFF_SCAN_LIMIT = 200
# Chars pulled per field before _obs_line() collapses whitespace and cuts to 70.
# Generous enough that a whitespace-heavy prefix still leaves visible text, and
# strictly more than the 1024-char cap this store used to impose.
_HANDOFF_FIELD_SCAN = 2000
# Chars reserved for the header/section lines format_handoff() adds itself.
_HANDOFF_HEADER_RESERVE = 250
# Per-chunk chrome the formatter wraps around a payload: " 🤖 [obs] " + "\n".
_HANDOFF_CHUNK_OVERHEAD = 11


def _obs_line(text: str | None, limit: int) -> str:
    """One-line, length-capped view of an observation field. Raw tool I/O is
    multi-line and the handoff format is line-oriented, so a stray newline
    would silently forge a new entry."""
    return " ".join((text or "").split())[:limit]


def _quarantine_if_corrupt(db_path: Path) -> Path | None:
    """If ``db_path`` exists but is not a usable sqlite DB, move it aside so a fresh
    one is created — power-loss-mid-write or a garbage file must never crash
    construction (I-S4). The corrupt file (and any ``-wal``/``-shm``) is PRESERVED
    as ``<name>.corrupt-<ts>`` for forensics; only the newest few are kept (R-02
    prune — they no longer accumulate unbounded). Returns the quarantine path, or
    None when the DB is healthy / absent.
    """
    if not db_path.exists():
        return None
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            row = conn.execute("PRAGMA quick_check").fetchone()
        finally:
            conn.close()
        if row and row[0] == "ok":
            return None                              # healthy
    except sqlite3.DatabaseError:
        pass                                         # not a database / malformed
    stamp = naive_utcnow().strftime("%Y%m%d%H%M%S%f")
    dest = db_path.with_name(f"{db_path.name}.corrupt-{stamp}")
    db_path.rename(dest)                             # writable dir is a precondition
    for sidecar in ("-wal", "-shm"):
        side = db_path.with_name(db_path.name + sidecar)
        if side.exists():
            try:
                side.rename(dest.with_name(dest.name + sidecar))
            except OSError:
                pass                                 # best-effort sidecar move
    _prune_quarantine(db_path)                       # R-02: keep only newest few
    return dest


def _prune_quarantine(db_path: Path, keep: int = 3) -> None:
    """Keep only the newest ``keep`` quarantined ``<name>.corrupt-<ts>`` copies
    (R-02 — they used to accumulate forever). The ``-<ts>`` stamp is lexically
    sortable; each pruned main file's ``-wal``/``-shm`` sidecars go with it."""
    mains = sorted(
        (p for p in db_path.parent.glob(f"{db_path.name}.corrupt-*")
         if not p.name.endswith(("-wal", "-shm"))),
        key=lambda p: p.name, reverse=True)
    for stale in mains[keep:]:
        for path in (stale, stale.with_name(stale.name + "-wal"),
                     stale.with_name(stale.name + "-shm")):
            try:
                path.unlink()
            except OSError:
                pass

# v3.6: extension -> ContentStore content_type mapping for ingest_directory().
# "prose" (the default every other caller relies on) is permanently paragraph-
# only chunking (content_store._chunk_content) — markdown files must map to
# the distinct "markdown" content_type to reach heading-based chunking rather
# than being routed through "prose".
_INGEST_CONTENT_TYPE_BY_EXT = {
    ".yaml": "yaml", ".yml": "yaml",
    ".md": "markdown", ".markdown": "markdown",
}


def _detect_ingest_content_type(file_path: Path) -> str:
    """Map a file extension to a ContentStore content_type for ingestion."""
    return _INGEST_CONTENT_TYPE_BY_EXT.get(file_path.suffix.lower(), "prose")


_INGEST_BINARY_SNIFF_BYTES = 8192


def _looks_binary(file_path: Path, sniff_bytes: int = _INGEST_BINARY_SNIFF_BYTES) -> bool:
    """Best-effort binary-content sniff for ingest_directory().

    Reads the first `sniff_bytes` of the file and treats the presence of a
    NUL byte as proof of non-text content. This is deliberately content-based
    rather than an extension allowlist: reference corpora meant for ingestion
    (e.g. pentest-technique collections) mix markdown/text with PNGs, JPEGs,
    PDFs, ZIPs and other binaries whose extensions can't be exhaustively
    enumerated, whereas a real text/markdown/yaml/source file essentially
    never contains a NUL byte in its first few KB. Any read failure here is
    treated as "not binary" — the caller's own read attempt (which already
    handles OSError) is the source of truth for whether the file is actually
    readable.
    """
    try:
        with file_path.open("rb") as fh:
            chunk = fh.read(sniff_bytes)
    except OSError:
        return False
    return b"\x00" in chunk


def _iter_ingest_files(root: Path):
    """Walk `root` recursively, skipping hidden directories.

    Any directory component starting with "." (`.git`, `.svn`, `.venv`, ...)
    is pruned before os.walk descends into it, so pointing ingest_directory()
    at a git checkout never pulls .git's pack/object internals into the
    knowledge store.
    """
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for name in filenames:
            yield Path(dirpath) / name


def _report_ingest_progress(callback, processed: int, total: int) -> None:
    """Best-effort progress callback invocation — must never interrupt ingest."""
    if callback is None:
        return
    try:
        callback(processed, total)
    except Exception:
        logger.warning("ingest_directory: progress_callback raised", exc_info=True)


# RAG-disable sentinel is OWNED by content_layer and re-exported via the import
# below, so `from conscio.engine import _RAG_DISABLED` yields the SAME object the
# ContentLayerManager gate compares against (one sentinel, not two).
from .content_layer import _RAG_DISABLED  # noqa: F401 — re-exported for tests


class ConsciousnessEngine:
    """
    The main orchestrator for the consciousness framework.
    
    Usage:
        engine = ConsciousnessEngine(model_name=os.environ.get("CONSCIO_MODEL", ""))

        # Run a reflection cycle
        result = engine.reflect(
            world_state="Trading bot operational, 3 active positions",
            recent_events=["BTC spiked 2%", "New anomaly detected in order book"],
        )
        
        # Get the state for context injection
        state = engine.get_state_for_injection()
        
        # Check pending evolution proposals
        proposals = engine.evolution.pending_proposals()
    """

    DEFAULT_STORAGE = Path.home() / ".conscio" / "consciousness"

    # v4.8.1 (batch H): maintenance-goal cooldown, in minutes. Derived from
    # H1 — host_health runs every heartbeat burn ~300 LLM calls/day to
    # re-confirm "all normal"; 60 min halves the burn with no observable
    # loss of coverage (the reflect cycle still runs every heartbeat).
    MAINTENANCE_COOLDOWN_MIN = 60

    # v4.8.1 (batch H): rolling 24h ceiling of awake-loop ACT ATTEMPTS
    # (every actions row with tier != 'host', whatever its outcome or
    # token count — a failed attempt in a 429 storm still burned quota).
    # 120 covers the legitimate ceiling (96 heartbeats/day × 1
    # maintenance cycle) with headroom for real goals; when it trips,
    # awake degrades to perceive+reflect and reports the trip. Counts
    # ATTEMPTS, not raw LLM requests (one attempt may bundle
    # proposal+fallback+skeptic calls).
    DAILY_LLM_CEILING = 120

    def __init__(
        self,
        model_name: str,
        context_window: int | None = None,
        storage_path: str | Path | None = None,
        drive_strengths: dict[str, float] | None = None,
        voice_preset: str | None = None,
        base_url: str | None = None,
        autodetect: bool = True,
        adaptive_reflection: bool = False,
        max_reflection_cycles: int = 3,
        delivery_check: bool = True,
    ):
        """Initialise the consciousness engine.

        Note: relay/liaison configuration is handled at the MCP Bindings
        level (``conscio.mcp.server.Bindings``), not here.  Pass
        ``relay=True`` / ``relay_peers=...`` to ``Bindings``, not to the
        Engine.
        """
        # expanduser: a "~/…" string is a path the caller means, not a directory
        # literally named "~" in the working directory.
        self.storage = (Path(storage_path).expanduser() if storage_path
                        else self.DEFAULT_STORAGE)
        self.storage.mkdir(parents=True, exist_ok=True)
        # Recency floor for status readings that must not report another
        # process's outcome as current (see _last_brake_message).
        self._started_at = naive_utcnow().isoformat()
        self._run_started_at: str | None = None

        # Detect model and set up context management
        self.ctx = ContextManager(model_name, context_window, self.storage,
                                    base_url=base_url, autodetect=autodetect)
        self.model_info = self.ctx.model_info
        self.mode = self.ctx.mode
        self._closed = False
        self._delivery_check_enabled = delivery_check

        # Initialize modules
        self.monologue = InnerMonologue(self.ctx)
        self.world = WorldModel(self.storage)
        self.meta = MetaCognition(self.storage)
        # v4.7 P1: decision outcome store — council (and later evaluate/
        # squads/coherence) capture decisions here; verdicts arrive via
        # resolve() when the real outcome is known.
        from .outcomes import OutcomeStore
        self.outcome_store = OutcomeStore(self.storage / "outcomes.db")

        # Convert drive strengths from string keys
        drives = None
        if drive_strengths:
            drives = {Drive(k): v for k, v in drive_strengths.items()}
        self.goals = GoalGenerator(self.storage, drives)

        self.evolution = AutoEvolution(self.storage)

        # v3.3.1: Auto-Indexer + KG Builder (lazy, installed on demand)
        self._auto_indexer: AutoIndexer | None = None
        self._kg_builder: KGBuilder | None = None

        # v3.8: DeepMiner — fire-and-forget tool-observation store (obs.db, lazy,
        # isolated from conscio.db). Guarded by a lock for thread-safe capture.
        self._obs_lock = threading.Lock()
        self._obs_db: sqlite3.Connection | None = None
        self._obs_session = uuid.uuid4().hex

        # --- v0.2: SQLite-backed modules (shared DB) ---
        db_path = self.storage / "conscio.db"
        # I-S4: a corrupt store (power-loss-mid-write, garbage file) must not crash
        # construction. Quarantine it (preserved on disk) and recreate fresh.
        quarantined = _quarantine_if_corrupt(db_path)
        self.event_bus = EventBus(db_path=db_path)
        if quarantined is not None:
            logger.warning(
                "conscio.db was corrupt; quarantined to %s and recreated fresh",
                quarantined)
            try:
                self.event_bus.emit(
                    type="system", category="system",
                    data={"event": "storage_recovered",
                          "quarantined": str(quarantined)})
            except Exception:                        # telemetry must never crash init
                pass
        self.shard_engine = ShardEngine(self.event_bus)
        self.coherence = CoherenceEngine(self.meta, self.world)
        # v0.8: shared semantic engine (lazy embedder) + contradiction detector.
        # Built once; reused by dream Reconcile and the opt-in output stage.
        self._semantic = SemanticEngine()
        self._contradiction_detector = ContradictionDetector(self._semantic)
        self.last_coherence: CoherenceReport | None = None
        self.dream_recommended = DreamRecommendation(False, None, None)
        # #147: Mitosis advisory — True at FATIGUE/CRITICAL context pressure.
        self.handoff_recommended = False
        self.last_self_prompts: list = []

        # Voice preset (v0.6) — static marker. Precedence: param > env > default.
        effective_voice = (
            voice_preset if voice_preset is not None
            else os.getenv("CONSCIO_VOICE_PRESET", "coherence-style")
        )
        self.voice_preset = resolve_voice_preset(effective_voice)

        # v3.6.1: vector-search auto-detect.
        # CONSCIO_VECTORS env var: "0" = force disable, "1" = force enable,
        # absent = auto-detect (try import sentence_transformers).
        # When enabled: construction never touches the network — EmbeddingProvider
        # probes lazily on first embed() call and falls back to None (no-op)
        # when no embedder is actually available, so this degrades gracefully.
        # Kept as a sibling file under the same storage root as conscio.db.
        self.vector_backend: VectorBackendType | None = None
        self.embedding_pipeline: EmbeddingPipeline | None = None
        self._init_vectors()
        # ContentStore uses a separate DB file (content_store.db) to avoid
        # bloating the EventBus DB (conscio.db). If content_store.db doesn't
        # exist but content exists in conscio.db (legacy), the ContentStore
        # will use conscio.db automatically (0 migration needed).
        cs_db_path = self.storage / "content_store.db"
        self.content_store = ContentStore(
            db_path=cs_db_path,
            vector_backend=self.vector_backend,
            embeddings=self.embedding_pipeline,
        )
        self._hybrid_retriever = HybridRetriever(
            content_store=self.content_store,
            vector_backend=self.vector_backend,
            embedding_pipeline=self.embedding_pipeline,
        )
        self.token_tracker = TokenTracker(db_path=db_path)
        self.output_filter = build_pipeline_from_dict({
            "stages": [
                {"strip_ansi": None},
                {"secret_mask": None},
                {"dedup_blocks": {"min_run": 3}},
                {"max_lines": {"max_lines": _OUTPUT_MAX_LINES}},
                {"truncate_lines": {"max_width": _OUTPUT_MAX_WIDTH}},
            ]
        })

        # v0.8: opt-in semantic output dedup (annotate near-dups, never merge).
        # NOT in the default pipeline — the hot path must stay network-free.
        if os.getenv("CONSCIO_SEMANTIC_DEDUP", "").strip().lower() in ("1", "true", "yes", "on"):
            from .output_filter import SemanticDedup
            self.output_filter.add_stage(SemanticDedup(semantic=self._semantic))

        # v0.9: ContentLayerManager — unified content operations (recall, perceive)
        self.content_layer = ContentLayerManager(
            content_store=self.content_store,
            world_model=self.world,
            session_rag_provider=create_session_rag,
            hybrid_retriever=self._hybrid_retriever,
            )

        # v0.9: SessionLifecycle — unified session persistence hooks
        self.session_lifecycle = SessionLifecycle(engine=self)

        self._state = self.ctx.load_state()

        # v0.9+: External token usage tracking — set by the adapter/gateway
        # to report real session token consumption. Falls back to injection
        # size when unset (see context_manager.total_tokens_approx docstring).
        self.session_tokens_used: int | None = None

        # v2.13: Adaptive reflection gate (opt-in)
        self.adaptive_reflection = adaptive_reflection
        self.reflection_gate: ReflectionGate | None = None
        if adaptive_reflection:
            self.reflection_gate = ReflectionGate(
                max_cycles=max_reflection_cycles,
            )

        # v1.7: structural cognition — optional, opt-in. No graph is loaded by
        # default, so injection/lookup/advisory stay inert until the host calls
        # load_structure(). Keeps cognition (reflect()) entirely untouched.
        self._distiller: StructuralDistiller | None = None
        self._structural_signal: StructuralSignal | None = None
        # v1.8: structural drift — temporal awareness over the ingested snapshot.
        # Tracked only when load_structure() is given a workspace_id; the store is
        # built lazily and keyed per Workspace.id (the engine owns the watermark).
        self._structural_delta: StructuralDelta | None = None
        self._structural_freshness: StructuralFreshness | None = None
        self._drift_store: StructuralDriftStore | None = None

    # --- Meta-Cognition → Goal Generator Feed ---

    def feed_meta_to_goals(self, meta: MetaCognition, goals: GoalGenerator) -> None:
        """
        Feed meta-cognition insights (blind spots, error patterns, confidence)
        into the goal generator to create improvement goals.
        """
        # Get existing active goal descriptions for deduplication
        active_descriptions = {g.description for g in goals.active_goals()}

        # Generate EVOLUTION goals from blind spots
        # GoalGenerator prefixes with "Evolve:" — match that for dedup
        for blind_spot in meta.blind_spots():
            expected_desc = f"Evolve: {blind_spot} \u2014 low confidence area"
            if expected_desc not in active_descriptions:
                # v1.6 (#7): blind-spot goals are meta-derived -> diagnostic-only.
                # Vague self-improvement ("Evolve: low confidence area") is not
                # actor-actionable; it stays visible (advisory/injection) but the
                # arbiter never auto-executes it. Generalizes the #6 slice.
                goals.generate_from_evolution(blind_spot,
                                              target="low confidence area",
                                              source="meta_error")
                active_descriptions.add(expected_desc)

        # v1.5.1 (#6): error patterns do NOT mint actor-executable goals.
        # Turning a recurring error (e.g. "act:tool:skeptic_fail") into a
        # "Maintenance: fix_recurring_error" goal made the actor execute it
        # literally (fs_read path="skeptic_fail") -> more errors -> lockdown loop.
        # Errors already flow to the diagnostic channels -- meta_cognition
        # storage, reflection, and AutoEvolution.observe_errors() (a reviewed
        # PATTERN_LEARN proposal queue, never the act pipeline) -- so the signal
        # is preserved without an executable goal. The full origin/provenance
        # gate (self_prompt, evolution, etc.) lands in v1.6.

        # Modulate drive strengths based on average confidence (capped at 1.0)
        avg_conf = meta.average_confidence()
        if avg_conf < 0.5:
            goals.drives[Drive.EVOLUTION] = min(1.0, goals.drives.get(Drive.EVOLUTION, 0.5) + 0.2)
        elif avg_conf > 0.8:
            goals.drives[Drive.CURIOSITY] = min(1.0, goals.drives.get(Drive.CURIOSITY, 0.7) + 0.2)

    # --- Main Loop ---

    def reflect(
        self,
        world_state: str = "",
        recent_events: list[str] | None = None,
        confidence: float = 0.5,
        anomalies: list[str] | None = None,
    ) -> dict:
        """
        Run a complete reflection cycle.

        If adaptive_reflection is enabled, runs 1-N cycles based on the
        ReflectionGate. Otherwise, runs exactly 1 cycle (legacy behavior).
        """
        if not self.adaptive_reflection or self.reflection_gate is None:
            return self._reflect_once(
                world_state, recent_events, confidence, anomalies,
            )

        # Adaptive mode: gate decides depth
        result = self._reflect_once(
            world_state, recent_events, confidence, anomalies,
        )
        cycle = 1
        while cycle < self.reflection_gate.max_cycles:
            ctx = self._build_gate_context(cycle)
            decision = self.reflection_gate.decide(ctx)
            self.event_bus.emit(
                type="reflection_gate",
                category="consciousness",
                data={
                    "cycle": cycle,
                    "need_score": decision.need_score,
                    "continue": decision.continue_reflection,
                    "breakdown": decision.breakdown,
                    "reason": decision.reason,
                },
            )
            if not decision.continue_reflection:
                break
            result = self._reflect_once(
                world_state, recent_events, confidence, anomalies,
            )
            cycle += 1
        return result

    def _build_gate_context(self, cycle: int) -> GateContext:
        """Build GateContext from current engine state."""
        confidence = self.meta.average_confidence()
        coherence = self.last_coherence.score if self.last_coherence else 0.5
        entities = self.world.list_entities(limit=MAX_ENTITIES_FOR_CONTRADICTION)
        contradiction_count = self._count_contradictions(entities)
        novelty_count = len(entities)
        metabolic = getattr(self._state, "metabolic", "")
        return GateContext(
            confidence=confidence,
            coherence=coherence,
            contradiction_count=contradiction_count,
            novelty_count=novelty_count,
            metabolic=metabolic,
            cycle=cycle,
        )

    def _count_contradictions(self, entities: list[dict]) -> int:
        """Count contradicting entity pairs using ContradictionDetector.

        Checks entity STATES (not names) for contradictions. Two entities
        with different names whose states contradict each other count.
        Also counts entities with multiple distinct states in their
        state_log (temporal contradictions).
        """
        if len(entities) < 2:
            count = 0
        else:
            count = 0
            # Cross-entity: compare states between different entities
            for i, a in enumerate(entities):
                for b in entities[i + 1:]:
                    try:
                        sa = a.get("state", "")
                        sb = b.get("state", "")
                        if sa and sb and self._contradiction_detector.states_contradict(sa, sb):
                            count += 1
                    except Exception:
                        pass
        # Temporal: entities with multiple distinct states in state_log
        for e in entities:
            state_log = e.get("state_log", [])
            if len(state_log) >= 2:
                states = {entry.get("state", "") for entry in state_log if entry.get("state")}
                if len(states) >= 2:
                    count += 1
        return count

    def _reflect_once(
        self,
        world_state: str = "",
        recent_events: list[str] | None = None,
        confidence: float = 0.5,
        anomalies: list[str] | None = None,
    ) -> dict:
        """
        Run a single reflection cycle (original reflect() logic).

        1. PERCEIVE — read world state
        2. REFLECT — compare with predictions, assess confidence
        3. GENERATE — create/update goals based on drives
        4. PREDICT — update world model predictions
        5. SUMMARIZE — compress into state_summary

        Returns the reflection result dict.
        """
        anomalies = anomalies or []

        # Infer active cognitive shard from events at reflect-entry — BEFORE this
        # cycle emits its own reflection/anomaly events, so they don't pollute the
        # signal (advisory; never feeds drives/goals).
        recent = [e.to_dict() for e in self.event_bus.query(limit=20)]
        active_shard = self.shard_engine.update(recent)
        shard_value = active_shard.value if active_shard else ""

        # v0.6: coherence snapshot over the SAME pre-update window (advisory, pure).
        # Reuses `recent` so it never counts the shard transition it just caused.
        coherence_report = self.coherence.assess(recent)
        self.last_coherence = coherence_report
        if coherence_report.score < COHERENCE_EVENT_THRESHOLD:
            self.event_bus.emit(
                type="coherence:dissonance",
                category="consciousness",
                data={
                    "score": coherence_report.score,
                    "dominant": (
                        coherence_report.dominant.dimension
                        if coherence_report.dominant else None
                    ),
                    "dimensions": coherence_report.dimensions,
                },
                priority=7,
            )

        # v0.7: dream-recommended advisory flag (hot path: one assignment).
        if coherence_report.score < COHERENCE_EVENT_THRESHOLD:
            self.dream_recommended = DreamRecommendation(
                recommended=True,
                dominant=(coherence_report.dominant.dimension
                          if coherence_report.dominant else None),
                score=coherence_report.score,
            )
        else:
            self.dream_recommended = DreamRecommendation(False, None, None)

        # v0.7: self-prompting — pure introspection, then ONE bounded goal.
        self.last_self_prompts = generate_self_prompts(
            self.meta, self.world, coherence_report, recent
        )
        spawned = self._spawn_self_prompt_goal(self.last_self_prompts)

        # Generate goals from anomalies (curiosity drive)
        for anomaly in anomalies:
            self.goals.generate_from_curiosity(anomaly, context=world_state)

        # Generate maintenance goals for stale world model entities
        stale = self.world.stale_entities()
        if stale:
            # Phrased as an instruction that names the tool which satisfies it.
            # A goal reading "prune_stale — 23 stale entities: a, b, c" states a
            # measurement, not a task: the actor still picked world_prune, but
            # the auditor compared the two names, found no match and refused
            # every attempt ("the stated goal does not match").
            self.goals.generate_from_maintenance(
                "prune_stale",
                f"release the {len(stale)} entities the world model has let go"
                f" stale ({', '.join(stale[:3])}) — the world_prune tool"
                " does exactly this",
            )

        # v3.4.2: if awake and no executable goals exist, spawn a periodic
        # maintenance goal so the daemon's act() can actually run and
        # produce artifacts (skills via distill, noosphere publications).
        # Without this, the daemon wakes, finds only diagnostic goals,
        # fails every cycle, and trips the failure-rate brake.
        # v4.8.1 (batch H): the maintenance goal now respects a cooldown —
        # regenerating "everything is normal" every heartbeat burned
        # ~300 LLM proposals/day against the shared provider quota. The
        # world state rarely changes between heartbeats; the cooldown
        # gates regeneration on the last daemon_check execution.
        if self._state.awake:
            # v3.9.8: also check the breaker — a goal may be executable by
            # origin but quarantined by the circuit breaker, leaving the
            # daemon with zero actable goals and no daemon_check spawned.
            _breaker = getattr(getattr(self, "_act_pipeline", None),
                               "breaker", None)
            def _is_actable(g) -> bool:
                if g.status != "active" or not g.executable:
                    return False
                if _breaker is not None:
                    from .agency.fingerprint import goal_fingerprint
                    if _breaker.is_quarantined(goal_fingerprint(g.description)):
                        return False
                return True
            has_executable = any(_is_actable(g) for g in self.goals._goals)
            if not has_executable:
                # v3.9.9: expire quarantined goals so that the new
                # daemon_check goal is not suppressed by _is_suppressed.
                # Without this, a quarantined daemon_check with status
                # "active" blocks the regeneration, leaving the daemon
                # stuck with zero actable goals forever.
                if _breaker is not None:
                    from .agency.fingerprint import goal_fingerprint
                    for g in list(self.goals._goals):
                        if (g.status == "active"
                                and _breaker.is_quarantined(
                                    goal_fingerprint(g.description))):
                            g.status = "expired"
                from .awake.calibration import MaintenanceCooldown
                cooldown = getattr(self, "_maintenance_cooldown", None)
                if cooldown is None:
                    cooldown = self._maintenance_cooldown = \
                        MaintenanceCooldown(minutes=self.MAINTENANCE_COOLDOWN_MIN)
                if cooldown.should_generate(
                        last_attempt_ts=self._last_daemon_check_ts()):
                    # v4.8.1 (batch H): description from the Goal constant —
                    # the same text the calibration fingerprints, so the
                    # ledger key always matches (hostile review, lever 1).
                    from .goal_generator import Goal as _Goal
                    target = _Goal.MAINTENANCE_DAEMON_CHECK_DESCRIPTION[
                        len("Maintenance: "):]
                    self.goals.generate_from_maintenance(
                        "daemon_check",
                        target,
                        source="daemon",
                    )

        # 4. PREDICT — forward if-then persistence predictions for recently
        # changed entities (v0.9 wiring: the docstring promised this stage but
        # nothing implemented it). The next perceive() settles them via
        # validate_predictions_against().
        self.world.generate_persistence_predictions()

        # Feed meta-cognition insights into goals BEFORE reflection
        self.feed_meta_to_goals(self.meta, self.goals)

        # Auto-observe errors and propose evolution fixes
        self.evolution.observe_errors(self.meta)

        # Score all goals with current MetaCognition state
        self.goals.score_all_goals(
            confidence=confidence,
            calibration=self.meta.calibration_score(),
        )

        # Cross-session recall: surface relevant past context (gap #3).
        recall_query = " ".join([world_state, *anomalies]).strip()
        past_context = self.recall(recall_query, k=3) if recall_query else []
        recent_events = list(recent_events or [])
        recent_events.extend(f"[recall] {s}" for s in past_context)

        # Run the inner monologue reflection
        result = self.monologue.reflect(
            world_state=world_state,
            recent_events=recent_events,
            confidence=confidence,
            anomalies=anomalies,
            goals_update=[g.description for g in self.goals.active_goals()],
        )

        # --- v0.4: Meta-reflect — advisory quality signal on this reflection ---
        error_rate = self.world.recent_prediction_error_rate(window_hours=24)
        anomaly_pen = min(0.1 * len(anomalies), 0.5)
        meta_confidence = max(
            0.0, min(1.0, confidence * (1.0 - error_rate) * (1.0 - anomaly_pen))
        )
        reflection_quality = (
            "HIGH" if meta_confidence >= 0.66
            else "MEDIUM" if meta_confidence >= 0.33
            else "LOW"
        )
        result["meta_confidence"] = round(meta_confidence, 3)
        result["reflection_quality"] = reflection_quality
        result["shard"] = shard_value
        result["coherence"] = coherence_report.score
        result["coherence_dimensions"] = coherence_report.dimensions
        result["dominant_dissonance"] = (
            coherence_report.dominant.dimension if coherence_report.dominant else None
        )
        result["self_prompts"] = [p.question for p in self.last_self_prompts]
        result["self_prompt_goal"] = spawned.id if spawned else None
        result["dream_recommended"] = self.dream_recommended.recommended

        # --- v0.2: Post-reflection pipeline ---
        raw_summary = result["summary"]
        filtered_summary = self.output_filter.apply(raw_summary)
        self.token_tracker.record(
            source="reflection",
            raw=raw_summary,
            filtered=filtered_summary,
        )

        # Index reflection into ContentStore for future search
        self.content_store.index(
            label=f"reflection_{naive_utcnow().strftime('%Y%m%d_%H%M')}",
            content=filtered_summary,
            category="reflection",
        )

        # Emit reflection event
        self.event_bus.emit(
            type="reflection",
            category="consciousness",
            data={
                "confidence": confidence,
                "anomalies": anomalies,
                "meta_confidence": round(meta_confidence, 3),
            },
        )

        # Emit anomaly events
        for anomaly in anomalies:
            self.event_bus.emit(
                type="anomaly",
                category="system",
                data={"description": anomaly},
                priority=8,
            )

        # --- #148: close the confidence loop ---
        # Resolve the previous pending "general" record against realized
        # prediction evidence (add_entity re-perception is the sole producer;
        # error_rate was computed above from the same window). No evidence →
        # stays pending; a resolved failure records a self-critique.
        pred_errors, pred_total = self.world.recent_prediction_outcomes(
            window_hours=24
        )
        if pred_total:
            outcome = "success" if error_rate <= 0.5 else "failure"
            resolved = self.meta.update_outcome("general", outcome)
            if resolved and outcome == "failure":
                self.meta.add_critique(
                    task="prediction",
                    what_i_did=(
                        f"held beliefs that produced {pred_errors}/{pred_total}"
                        " failed re-perception predictions in the last 24h"
                    ),
                    what_i_should_do=(
                        "re-perceive volatile entities before predicting; "
                        "lower persistence confidence for flappy states"
                    ),
                )

        # Record confidence in meta-cognition
        self.meta.record_confidence("general", confidence)

        # Build the new consciousness state
        self._state = self.ctx.build_state(
            state_summary=filtered_summary,
            last_reflection=filtered_summary[:200],  # Compact version
            active_goals=[g.description for g in self.goals.active_goals()],
            world_model_snippet=self.world.query(world_state)[:100] if world_state else "",
            meta_cognition=self.meta.summary(),
            reflection_quality=reflection_quality,
            shard=shard_value,
            coherence=coherence_report.score,
            coherence_note=(
                coherence_report.dominant.dimension
                if coherence_report.dominant else ""
            ),
            voice=self.voice_preset,
            self_prompt=(self.last_self_prompts[0].question
                         if self.last_self_prompts else ""),
            dream_recommended=self.dream_recommended.marker(),
        )

        # v0.9: Metabolic wiring — assess context health and inject tier_action
        used_tokens = (self.session_tokens_used
                       if self.session_tokens_used is not None
                       else self._state.total_tokens_approx())
        total_window = self.model_info.context_window
        metabolic_state = MetabolicContext.assess(used_tokens, total_window)
        metabolic_note = f"{metabolic_state.value} {MetabolicContext.usage_pct(used_tokens, total_window):.0f}%"
        tier_action = MetabolicContext.tier_action(metabolic_state)
        self._state.metabolic = f"{metabolic_note} — {tier_action}"

        # #147: machine-consumable metabolic gates. Dream may already be
        # recommended by the coherence path (v0.7); metabolic CRITICAL is the
        # second, independent trigger for the same advisory.
        if (MetabolicContext.should_dream(metabolic_state)
                and not self.dream_recommended.recommended):
            self.dream_recommended = DreamRecommendation(
                recommended=True,
                dominant="metabolic",
                score=MetabolicContext.usage_pct(used_tokens, total_window) / 100.0,
            )
            result["dream_recommended"] = True
        self.handoff_recommended = MetabolicContext.should_mitosis(metabolic_state)
        result["handoff_recommended"] = self.handoff_recommended

        # Persist state
        self.ctx.save_state(self._state)

        return result

    def _spawn_self_prompt_goal(self, prompts):
        """Spawn ONE bounded goal from the highest-severity self-prompt, tagged
        source="self_prompt", returning the goal actually tracked in the store
        (or None when no prompt exists / the drive is too weak to spawn).

        GoalGenerator dedups on `Goal.dedup_key` and caps active goals, so a
        repeated self-prompt is a no-op in the store. The generators, however,
        always return a freshly-built Goal even on a dedup no-op — and that object
        is NOT the persisted one (its id is never in `_goals`). So after generating
        we resolve the canonical active goal by that same key, ensuring
        result["self_prompt_goal"] carries a real stored id rather than a phantom
        from a discarded duplicate."""
        if not prompts:
            return None
        p = prompts[0]
        if p.drive == "maintenance":
            # The question, not the target: `target` is an entity name or a
            # dimension label, and a goal reading "Maintenance: botX" asks for
            # nothing. The question says what to settle about it.
            goal = self.goals.generate_from_maintenance(
                "self_prompt", f"{p.question} (target: {p.target})",
                source="self_prompt",
            )
        elif p.drive == "evolution":
            goal = self.goals.generate_from_evolution(
                p.question, target=p.target, source="self_prompt"
            )
        else:
            goal = self.goals.generate_from_curiosity(
                p.question, context=p.target, source="self_prompt"
            )
        if goal is None:
            return None
        # Resolve the canonical tracked goal — generators hand back a fresh
        # (possibly non-persisted) Goal even on a dedup no-op. Match on
        # dedup_key rather than description: a maintenance goal's description
        # carries a live reading ("23 stale entities: a, b, c") that changes
        # between cycles while the goal itself stays the same one.
        for g in self.goals._goals:
            if g.status == "active" and g.dedup_key == goal.dedup_key:
                return g
        # Nothing active answers to this key: the proposal was dropped against a
        # cancelled twin, or the cap expired it on arrival. Either way no goal is
        # tracked, and reporting the phantom's id would invent one.
        return None

    @property
    def state(self):
        """Public read-only view of the current ConsciousnessState
        (the volition layer reads this; reflect() owns the writes)."""
        return self._state

    # ── v1.5 Awake Mode (R9): master gate for autonomous operation ──────
    @property
    def awake(self) -> bool:
        """Awake Mode (R9). True ⇒ self-initiated autonomy (the run()/daemon
        heartbeat) is allowed; False (default) ⇒ perceive + reflect() only.
        A direct human act() call is never gated by this — R9 governs the loop."""
        return bool(self._state.awake)

    def wake(self) -> None:
        """Enter Awake Mode (R9). Persists + emits awake:changed. Idempotent."""
        self._set_awake(True)

    def sleep(self) -> None:
        """Leave Awake Mode (R9). Persists + emits awake:changed. Idempotent."""
        self._set_awake(False)

    def _set_awake(self, value: bool) -> None:
        changed = bool(self._state.awake) != value
        self._state.awake = value
        self.ctx.save_state(self._state)        # rides the existing state store
        if changed:                             # auditable, no duplicate events
            self.event_bus.emit(
                type="awake:changed",
                category="consciousness",
                data={"awake": value},
            )

    def enable_auto_index(self, run_kg_builder: bool = True) -> dict:
        """Install the auto-indexer and optional KG builder.

        Patches _reflect_once to index cognitive output into ContentStore
        automatically after each reflection cycle.

        Args:
            run_kg_builder: If True, also run KG entity extraction every 10 cycles

        Returns:
            dict with status info
        """
        from .content_store import ContentStore
        from .kg import KnowledgeGraph
        from .kg_builder import KGBuilder

        self.content_store = ContentStore(db_path=self.storage / "content_store.db")
        kg = KnowledgeGraph(db_path=self.storage / "kg.db")

        if run_kg_builder:
            self._kg_builder = KGBuilder(self.content_store, kg)
            # Run initial batch
            initial_result = self._kg_builder.run(limit=500)
        else:
            initial_result = {"entities_added": 0, "triples_added": 0, "sources_scanned": 0}

        self._auto_indexer = AutoIndexer(self, kg_builder=self._kg_builder)
        self._auto_indexer.install()

        return {
            "auto_index": True,
            "kg_builder": run_kg_builder,
            "initial_entities": initial_result["entities_added"],
            "initial_triples": initial_result["triples_added"],
            "initial_sources_scanned": initial_result["sources_scanned"],
        }

    def get_state_for_injection(self) -> str:
        """
        Get the consciousness state formatted for LLM context injection.
        
        This is what gets inserted into the system prompt or context
        to give the agent self-awareness.

        When a structural graph is loaded (v1.7), a budget-adaptive structure
        block is appended ADDITIVELY — the consciousness-state block is byte-for-
        byte unchanged (cognition stays untouched); structure is layered after.
        """
        base = self._state.to_injection()
        if self._structural_signal is not None:
            block = render_structural(
                self._structural_signal,
                structural_budget(self._state.context_window))
            if block:
                return base + "\n" + block
        return base

    # --- Structural Cognition pull surfaces (v1.7) ---

    def load_structure(
        self,
        path: str | Path,
        *,
        max_bytes: int = DEFAULT_MAX_BYTES,
        max_nodes: int = DEFAULT_MAX_NODES,
        workspace_id: str | None = None,
        root: str | Path | None = None,
    ) -> StructuralSignal:
        """Load + distill a Graphify ``graph.json`` (data, never code; R10).

        Caches the distiller (for ``structural_lookup``) and the distilled
        ``StructuralSignal`` (for injection / ``structural_signal``). Raises
        ``StructuralError`` (a ``ValueError``) on malformed or non-graph input.

        When ``workspace_id`` is given (v1.8), drift is tracked: the fresh signal
        is compared against the persisted baseline for that workspace, the
        baseline is advanced, and ``structure:changed`` is emitted on real drift.
        ``root`` (the workspace root) additionally enables freshness-vs-HEAD. With
        no ``workspace_id`` the behaviour is identical to v1.7 (no drift state).
        """
        self._distiller = StructuralDistiller.from_path(
            path, max_bytes=max_bytes, max_nodes=max_nodes)
        self._structural_signal = self._distiller.distill()
        if workspace_id is not None:
            self._track_drift(workspace_id, root, self._structural_signal)
        else:
            self._structural_delta = None
            self._structural_freshness = None
        return self._structural_signal

    def _track_drift(
        self, workspace_id: str, root: str | Path | None, sig: StructuralSignal
    ) -> None:
        store = self._drift_store or StructuralDriftStore(drift_path(self.storage))
        self._drift_store = store
        prev = store.get(workspace_id)
        self._structural_delta = compute_delta(prev, sig)
        self._structural_freshness = (
            compute_freshness(root, sig.built_at_commit) if root is not None else None)
        store.put(workspace_id, StructuralDigest.from_signal(sig))  # advance baseline
        if self._structural_delta.changed:
            self._emit_structure_changed(self._structural_delta)

    def _emit_structure_changed(self, delta: StructuralDelta) -> None:
        try:
            self.event_bus.emit(
                type="structure:changed", category="system",
                data={"from": delta.commit_from, "to": delta.commit_to,
                      "hyperedges_added": len(delta.hyperedges_added),
                      "hyperedges_removed": len(delta.hyperedges_removed),
                      "summary": delta.summary})
        except Exception as exc:                       # passive signal — never fatal
            logger.debug("structure:changed emit failed: %s", exc)

    def structural_signal(self) -> StructuralSignal | None:
        """The distilled signal of the loaded graph, or None if none loaded."""
        return self._structural_signal

    def structural_delta(self) -> StructuralDelta | None:
        """Drift of the last loaded graph vs its prior baseline (v1.8).

        None unless the graph was loaded with a ``workspace_id``. Read-only,
        no-LLM — an ``advisory()`` sibling."""
        return self._structural_delta

    def structural_freshness(self) -> StructuralFreshness | None:
        """Freshness of the last loaded graph vs the repo HEAD (v1.8).

        None unless the graph was loaded with both a ``workspace_id`` and a
        ``root``. Read-only, no-LLM."""
        return self._structural_freshness

    def unload_structure(self) -> None:
        """Drop any loaded structural graph (and its drift state).

        Used on a workspace switch into a workspace without consent (v1.7.2), so
        one project's structure never leaks into another's context."""
        self._distiller = None
        self._structural_signal = None
        self._structural_delta = None
        self._structural_freshness = None

    def structural_lookup(self, key: str) -> dict[str, Any] | None:
        """On-demand drill-down: resolve a node / hyperedge / community id to
        detail (read-only, no-LLM, no-mutation — an ``advisory()`` sibling).
        Returns None when no graph is loaded or the id is unknown."""
        return self._distiller.lookup(key) if self._distiller is not None else None

    def _structural_advisory(self) -> dict[str, Any] | None:
        sig = self._structural_signal
        if sig is None:
            return None
        return {
            "loaded": True,
            "commit": sig.built_at_commit,
            "hash": sig.content_hash,
            "nodes": sig.node_count,
            "hyperedges": len(sig.hyperedges),
            "communities": len(sig.communities),
            "drift": (self._structural_delta.to_advisory()
                      if self._structural_delta is not None else None),
            "freshness": (self._structural_freshness.to_advisory()
                          if self._structural_freshness is not None else None),
        }

    def advisory(self) -> dict:
        """Structured, read-only snapshot for the host to PULL each turn (#5/#9).

        Where `get_state_for_injection()` returns prose for the LLM context,
        `advisory()` returns machine-readable signal a host consumes directly:
        cognitive state, active goals tagged by provenance (executable vs
        diagnostic, #7), and operational status (action lockdown / last
        failure-rate brake, #8). It MUST stay cheap — no inference call, no state
        mutation — so it is safe to call on every host turn (and with no adapter
        attached).
        """
        s = self._state
        goals = [
            {"description": g.description, "origin": g.origin.value,
             "executable": g.executable}
            for g in self.goals.active_goals()
        ]
        diagnostic = [g for g in goals if not g["executable"]]
        recommendations: list[str] = []
        if s.dream_recommended:
            recommendations.append("dream recommended")
        if diagnostic:
            recommendations.append(
                f"{len(diagnostic)} diagnostic goal(s) pending review "
                f"(visible, not auto-run)")
        return {
            "awake": self.awake,
            "reflection": s.last_reflection,
            "meta": s.meta_cognition,
            "goals": goals,
            "coherence": {"score": s.coherence, "dominant": s.coherence_note},
            "status": {
                "action_lockdown": s.action_lockdown,
                "dream_recommended": bool(s.dream_recommended),
                "handoff_recommended": self.handoff_recommended,
                "brake": self._last_brake_message(),
            },
            "structural": self._structural_advisory(),
            "recommendations": recommendations,
        }

    def _last_brake_message(self) -> str | None:
        """Aggregate failure-rate brake message from the latest heartbeat (#8).

        The brake is a per-run outcome, not a persistent condition: the next
        run() starts with a fresh failure count. Scanning the whole event log
        therefore reported a brake from a previous process — or a previous
        heartbeat — as current status forever (BUG-37b). The window starts at
        the most recent run(), falling back to this engine's construction.

        Read-only scan of recent system events; returns None when no brake has
        tripped in that window. Never raises (a strict bus must not break the
        advisory)."""
        try:
            events = self.event_bus.query(
                type="system", category="system",
                since=self._run_started_at or self._started_at, limit=20)
        except Exception:
            return None
        for e in events:                      # newest first
            data = getattr(e, "data", {}) or {}
            msg = data.get("message", "") if isinstance(data, dict) else ""
            if "failure-rate brake" in msg:
                return msg
        return None

    def recall(
        self,
        query: str,
        k: int = 3,
        categories: list[str] | None = None,
    ) -> list[str]:
        """
        Retrieve relevant past context across sessions.
        
        Delegates to ContentLayerManager which unifies ContentStore FTS5 (with
        layer-prioritized reorder) and SessionRAG semantic search.
        
        Args:
            query: Free-text query (e.g., current world_state + anomalies).
            k: Max snippets to return.
            categories: Optional ContentStore category filter(s).
            
        Returns:
            List of short context snippets (<= ~300 chars each), best first.
        """
        return self.content_layer.recall(query, k, categories)

    def ingest_directory(
        self,
        path: str | Path,
        category: str = "reference",
        chunk_size: int = 2000,
        overlap: float = 0.2,
        progress_callback: Callable[[int, int], None] | None = None,
        max_file_size_mb: float = 5.0,
    ) -> dict:
        """
        Ingest all files under `path` into ContentStore (and, as a side
        effect of index()'s existing vector_backend/embeddings wiring, into
        VectorBackend — see __init__).

        `path` may be a single file or a directory (walked recursively).
        content_type is detected from extension: .yaml/.yml -> "yaml",
        .md/.markdown -> "markdown", else "prose". Dedup is ContentStore's
        own content_hash check — re-running ingest_directory() on unchanged
        files does not duplicate chunks.

        Directory walks skip hidden directories (any path component starting
        with ".", e.g. `.git`, `.svn`) and, per file, skip anything above
        `max_file_size_mb` or that sniffs as binary (NUL byte in the first
        few KB — see `_looks_binary`). This matters because ingest_directory
        is meant to run over arbitrary reference corpora (docs, code,
        pentest-technique collections, ...) that mix text with images, PDFs,
        archives and VCS internals; without these guards every binary byte
        stream gets decoded as text (`errors="ignore"`) and indexed as
        garbage chunks/vectors, bloating the store with noise that also
        pollutes recall() results.

        Args:
            path: File or directory to ingest.
            category: ContentStore category for every ingested file.
            chunk_size: Max chars per chunk (passed to ContentStore.index()).
            overlap: Fraction of chunk_size to overlap between chunks.
            progress_callback: Optional callable(processed, total) invoked
                after each file. Exceptions from it are logged, never raised.
            max_file_size_mb: Files larger than this are skipped without
                being read. Default 5.0 MB is generous for text/markdown/code
                reference material while still rejecting large binaries.

        Returns:
            {"total": N, "ingested": N, "duplicate": N, "skipped": N,
             "failed": N, "duration_s": float}

            `ingested` counts files that actually produced chunks; files whose
            content_hash was already indexed are counted in `duplicate`, NOT
            in `ingested`. This distinction is load-bearing: a second run over
            an unchanged corpus must report ingested=0/duplicate=N, otherwise
            a no-op re-run looks identical to a real ingest and cannot be used
            as evidence that ingestion works.

            `skipped` also counts files skipped for being oversized, binary,
            or empty — these are not read/indexing failures, so they are
            never counted in `failed`, but they must still show up somewhere
            in the totals rather than silently vanishing from `total`.
        """
        start = time.monotonic()
        root = Path(path)
        max_file_size_bytes = max_file_size_mb * 1024 * 1024

        if root.is_file():
            files = [root]
        elif root.is_dir():
            files = sorted(_iter_ingest_files(root))
        else:
            logger.warning("ingest_directory: path does not exist: %s", root)
            return {"total": 0, "ingested": 0, "duplicate": 0, "skipped": 0,
                    "failed": 0,
                    "duration_s": round(time.monotonic() - start, 4)}

        total = len(files)
        ingested = duplicate = skipped = failed = 0

        for i, file_path in enumerate(files, start=1):
            try:
                size_bytes = file_path.stat().st_size
            except OSError as e:
                logger.warning("ingest_directory: could not stat %s: %s", file_path, e)
                failed += 1
                _report_ingest_progress(progress_callback, i, total)
                continue

            if size_bytes > max_file_size_bytes:
                logger.info(
                    "ingest_directory: skipping %s (%.1f MB > %.1f MB cap)",
                    file_path, size_bytes / (1024 * 1024), max_file_size_mb,
                )
                skipped += 1
                _report_ingest_progress(progress_callback, i, total)
                continue

            if _looks_binary(file_path):
                skipped += 1
                _report_ingest_progress(progress_callback, i, total)
                continue

            try:
                text = file_path.read_text(encoding="utf-8", errors="ignore")
            except OSError as e:
                logger.warning("ingest_directory: could not read %s: %s", file_path, e)
                failed += 1
                _report_ingest_progress(progress_callback, i, total)
                continue

            if not text.strip():
                skipped += 1
                _report_ingest_progress(progress_callback, i, total)
                continue

            try:
                result = self.content_store.index_ex(
                    label=str(file_path),
                    content=text,
                    category=category,
                    content_type=_detect_ingest_content_type(file_path),
                    chunk_size=chunk_size,
                    overlap=overlap,
                )
                if result.is_new_content:
                    ingested += 1
                else:
                    duplicate += 1
            except Exception as e:
                logger.warning("ingest_directory: failed to index %s: %s", file_path, e)
                failed += 1

            if i % 500 == 0:
                logger.info("ingest_directory: %d/%d files processed", i, total)
            _report_ingest_progress(progress_callback, i, total)

        return {
            "total": total,
            "ingested": ingested,
            "duplicate": duplicate,
            "skipped": skipped,
            "failed": failed,
            "duration_s": round(time.monotonic() - start, 4),
        }

    # --- World Model Interactions ---

    def feed(self, event: dict) -> dict:
        """Emit a host Event on the EventBus and return the current advisory.

        This is a thin Python-API convenience for embedders, **not** the
        ``conscio_feed`` MCP tool. The MCP path (``Bindings._feed``) also
        normalizes and validates the event envelope, dedups it by ``event_id``
        against the seen-store, charges the metabolic tier with
        ``session_tokens``, and runs ``perceive()``/``reflect()``. This method
        does none of that: it emits and reads the advisory back, so the
        returned advisory reflects state as of the *previous* cycle. Call
        ``perceive()``/``reflect()`` yourself, or go through the MCP tool, if
        you need the full cycle.

        Args:
            event: Event dict with keys ``type``, ``category``, ``data``
                   (``id`` and ``source`` are accepted by the MCP tool but
                   ignored here). Missing keys default to
                   ``host:event``/``system``/``{}``.

        Returns:
            The current advisory dict.

        Raises:
            ValueError: propagated from ``EventBus.emit`` when ``type`` or
                ``category`` is outside the known vocabulary. Embedders get
                this raw, not the MCP ``InvalidParams``.
        """
        evt_type = event.get("type", "host:event")
        evt_category = event.get("category", "system")
        evt_data = event.get("data", {})
        self.event_bus.emit(type=evt_type, category=evt_category, data=evt_data)
        return self.advisory()

    def perceive(self, world_state: str, entities: dict | None = None,
                 relations: list | None = None) -> None:
        """
        Update the world model with perceived state.

        Delegates to ContentLayerManager which manages the WorldModel.

        When `entities`/`relations` is None (the production path — the MCP
        server passes only `world_state`), they are derived deterministically
        from the world_state string via `extract_entities` /
        `extract_relations`. An explicit value — including an explicit empty
        `{}`/`[]` — always wins over extraction, so callers can suppress
        extraction or supply richer facts of their own.

        Args:
            world_state: Text description of current world state
            entities: Dict of {entity_name: {type, state, attributes}} to update
            relations: List of (from_entity, relation, to_entity) triples
        """
        if entities is None:
            entities = extract_entities(world_state)
        if relations is None:
            relations = extract_relations(world_state)
        self.content_layer.perceive(world_state, entities, relations)

    # --- Evolution Interactions ---

    def propose_evolution(self, evolution_type: str, **kwargs) -> dict:
        """
        Create an evolution proposal.
        
        All proposals are PENDING until a human approves them.
        Returns the proposal dict for review.
        """
        type_map: dict[str, Callable[..., Any]] = {
            "skill_patch": self.evolution.propose_skill_patch,
            "skill_create": self.evolution.propose_skill_create,
            "memory_update": self.evolution.propose_memory_update,
            "pattern_learn": self.evolution.propose_pattern_learn,
        }

        handler = type_map.get(evolution_type)
        if not handler:
            return {"error": f"Unknown evolution type: {evolution_type}"}

        proposal = handler(**kwargs)
        return proposal.to_dict()

    def record_session_lifecycle(
        self,
        event_type: str,
        context: dict,
    ) -> SessionSummary | None:
        """
        Record a session lifecycle event through Conscio.

        Uses the engine's SessionLifecycle instance (callbacks wired, etc.).

        Args:
            event_type: "session:end" or "session:reset"
            context: Hook context dict (platform, user_id, session_key, session_id)

        Returns:
            SessionSummary if successful, None if no data.
        """
        return self.session_lifecycle.record_session(event_type, context)

    def dream(self, dry_run: bool = False) -> DreamReport:
        """
        Run a consolidation cycle (Noosphere "Dreaming").

        Release (purge duplicate/trivial events) → Prune (remove stale world
        entities) → Crystallize (compress old reflections). Safe to call
        on-demand, on session handoff, or from cron. Not run per-reflect.
        """
        from .dreaming import DreamCycle
        return DreamCycle().run(self, dry_run=dry_run)

    # --- Status & Monitoring ---

    def status(self) -> dict:
        """Full status of all consciousness modules."""
        return {
            "model": self.model_info.name,
            "context_window": self.model_info.context_window,
            "mode": self.mode.value,
            "budget": self.ctx.budget,
            "monologue": self.monologue.status(),
            "world_model": self.world.status(),
            "meta_cognition": self.meta.summary(),
            "goals": self.goals.status(),
            "evolution": self.evolution.status(),
            "content_store": self.content_store.stats(),
            "event_bus": self.event_bus.stats(),
            "token_tracker": self.token_tracker.gain(),
            "state_tokens_approx": self._state.total_tokens_approx(),
            "storage_path": str(self.storage),
        }

    def health_check(self) -> dict:
        """Quick health check — are all modules operational?"""
        return {
            "healthy": True,
            "mode": self.mode.value,
            "model": self.model_info.name,
            "pending_proposals": len(self.evolution.pending_proposals()),
            "active_goals": len(self.goals.active_goals()),
            "stale_entities": len(self.world.stale_entities()),
        }

    def evaluate(
        self,
        task_description: str = "",
        output: str | None = None,
    ):
        """Produce a 5-axis self-evaluation scorecard (v2.15).

        Axes: accuracy, completeness, clarity, actionability, conciseness.
        Scores 1-5 with concrete evidence. Pure read-only — no state mutation.

        Args:
            task_description: what the agent was trying to do.
            output: optional output text being evaluated (used for
                    conciseness and clarity heuristics).

        Returns:
            EvaluationReport with 5 AxisScores + overall + improvements.

        Raises:
            RuntimeError: if engine has been closed.
        """
        if getattr(self, "_closed", False):
            raise RuntimeError("evaluate() called on a closed engine")
        from .evaluation import evaluate as _evaluate
        return _evaluate(self, task_description, output)

    # --- Gate Tools (v3.0) ---

    def decide(self, *, title: str = "", context: str = "",
               alternatives: list[str] | None = None,
               adr_id: str | None = None, status: str = "proposed",
               deciders: list[str] | None = None) -> dict:
        """Create or update an Architecture Decision Record (ADR)."""
        from .gates import decide as _decide
        return _decide(self, title=title, context=context,
                       alternatives=alternatives, adr_id=adr_id,
                       status=status, deciders=deciders)

    def council(self, question: str = "", context: str = "",
                options: list[str] | None = None) -> dict:
        """Convene a 4-voice decision council."""
        from .gates import council as _council
        return _council(self, question=question, context=context, options=options)

    def squad_experts(self, *, question: str = "", context: str = "",
                      voices: list[str] | None = None,
                      use_llm: bool = False) -> dict:
        """Convene the Experts squad (Optimizer, Auditor, QA, Promptor).

        The Promptor is the squad's prompt refiner: its entry carries
        ``refined_prompt`` and ``changes`` instead of a vote, and it is
        excluded from ``recommendation``/``votes_summary``.
        """
        from .squads.convene import convene_squad
        return convene_squad(
            self, squad="experts", question=question, context=context,
            voices=voices, use_llm=use_llm,
        )

    def squad_opositors(self, *, question: str = "", context: str = "",
                        voices: list[str] | None = None,
                        use_llm: bool = False) -> dict:
        """Convene the Opositors squad (Caustic, Devil's Advocate, etc.)."""
        from .squads.convene import convene_squad
        return convene_squad(
            self, squad="opositors", question=question, context=context,
            voices=voices, use_llm=use_llm,
        )

    def loop_gate(self, *, task: str = "", frequency: str = "",
                  verifiable: bool = True, budget_ok: bool = True,
                  has_tools: bool = True) -> dict:
        """Vet an autonomous loop against 4 conditions."""
        from .gates import loop_gate as _loop_gate
        return _loop_gate(self, task=task, frequency=frequency,
                          verifiable=verifiable, budget_ok=budget_ok,
                          has_tools=has_tools)

    def delivery_check(self) -> dict:
        """Pre-close quality gate: rationalization, stale libs, disk."""
        from .gates import delivery_check as _delivery_check
        return _delivery_check(self)

    def investigate(self, *, target: str = "", action_type: str = "") -> dict:
        """Verify that the target was read before acting."""
        from .gates import investigate as _investigate
        return _investigate(self, target=target, action_type=action_type)

    # --- Pipeline Tools (v3.0) ---

    def acceptance_criteria(self, *, goal: str = "", depth: str = "",
                            risk_domains: list[str] | None = None) -> dict:
        """Generate acceptance criteria for a goal or task."""
        from .pipelines import acceptance_criteria as _ac
        return _ac(self, goal=goal, depth=depth, risk_domains=risk_domains)

    def verify(self, *, criteria: list[dict] | None = None,
               criteria_source: str = "") -> dict:
        """Verify that acceptance criteria have been met."""
        from .pipelines import verify as _v
        return _v(self, criteria=criteria, criteria_source=criteria_source)

    def continuous_loop(self, *, task: str = "", pattern: str = "",
                        frequency: str = "", verifiable: bool = True,
                        budget_ok: bool = True, has_tools: bool = True) -> dict:
        """Select and gate an autonomous loop pattern."""
        from .pipelines import continuous_loop as _cl
        return _cl(self, task=task, pattern=pattern, frequency=frequency,
                   verifiable=verifiable, budget_ok=budget_ok, has_tools=has_tools)

    def strategic_compact(self, *, phase: str = "", context_tokens: int = 0,
                          context_window: int = 0) -> dict:
        """Advise on strategic context compaction timing."""
        from .pipelines import strategic_compact as _sc
        return _sc(self, phase=phase, context_tokens=context_tokens,
                   context_window=context_window)

    def ledger(self, *, action: str = "record", rollout_id: str | None = None,
               candidates: list[dict] | None = None, fresh_info: str = "",
               search_space_size: int = 0, marks: dict | None = None,
               prior_winner: str = "", coherence_mark: dict | None = None) -> dict:
        """Record, query, or promote entries in the recursive decision ledger."""
        from .pipelines import ledger as _l
        return _l(self, action=action, rollout_id=rollout_id,
                   candidates=candidates, fresh_info=fresh_info,
                   search_space_size=search_space_size, marks=marks,
                   prior_winner=prior_winner, coherence_mark=coherence_mark)

    # --- Diagnostic Tools (v3.0) ---

    def context_budget(self, *, context_tokens: int = 0,
                        context_window: int = 0,
                        detail: str = "summary") -> dict:
        """Audit context window consumption and surface optimizations."""
        from .diagnostics import context_budget as _cb
        return _cb(self, context_tokens=context_tokens,
                    context_window=context_window, detail=detail)

    # --- Harness Efficiency (v3.1) ---

    def token_summary(self) -> dict:
        """v3.1: Aggregate token usage summary from the session ledger."""
        from .token_account import TokenLedger
        ledger = TokenLedger(self.storage / "token_ledger.db")
        return ledger.summary()

    def cpm(self, quality: float = 1.0) -> float:
        """v3.1: Completions Per Million effective Tokens."""
        from .token_account import TokenLedger
        ledger = TokenLedger(self.storage / "token_ledger.db")
        return ledger.cpm(quality=quality)

    def eval_harness(self, *, action: str = "define",
                      eval_id: str | None = None,
                      eval_type: str = "capability",
                      task: str = "",
                      criteria: list[str] | None = None,
                      results: list[bool] | None = None,
                      k_values: list[int] | None = None) -> dict:
        """Formal evaluation framework with pass@k metrics."""
        from .diagnostics import eval_harness as _eh
        return _eh(self, action=action, eval_id=eval_id, eval_type=eval_type,
                    task=task, criteria=criteria, results=results,
                    k_values=k_values)

    def rules_distill(self, *, action: str = "scan",
                       source_types: list[str] | None = None,
                       min_occurrences: int = 2,
                       rule_text: str = "",
                       rule_id: str | None = None) -> dict:
        """Extract cross-cutting principles from skills and events."""
        from .diagnostics import rules_distill as _rd
        return _rd(self, action=action, source_types=source_types,
                    min_occurrences=min_occurrences, rule_text=rule_text,
                    rule_id=rule_id)

    # --- v3.6.1: Vector auto-detect ---

    def _init_vectors(self) -> None:
        """
        Configure VectorBackend + EmbeddingPipeline based on CONSCIO_VECTORS env var:
        - "0" → force disable (FTS5-only even if dep available)
        - "1"/"true"/"yes"/"on" → force enable (construct VectorBackend regardless)
        - absent → auto-detect: enable when sentence_transformers is installed

        Vector backend engine is selected by CONSCIO_VEC_BACKEND env var:
        - "sqlite_vec" → SqliteVecBackend (C-native cosine, 10x faster search)
        - "hnsw" → HNSWBackend (O(log n) approximate, requires hnswlib)
        - unset/"numpy" → VectorBackend (original numpy O(n) scan)

        Auto-detect only asks whether the dependency exists, so it asks the
        cheap way: importing sentence_transformers drags torch along, costing
        ~5s and ~390MB of RSS on every construction, to compute a boolean. The
        model itself is still imported at first embed (``embedding.py``), where
        the cost buys something. A dependency that is present but broken now
        surfaces there instead of here, and degrades the same way: the embedder
        chain catches it and retrieval falls back to FTS5.
        """
        env = os.getenv("CONSCIO_VECTORS", "").strip().lower()
        if env in ("0", "false", "no", "off"):
            logger.info("CONSCIO_VECTORS=%s — vectors disabled by env", env)
            return
        if env in ("1", "true", "yes", "on"):
            self._enable_vectors()
            logger.info("CONSCIO_VECTORS=%s — vectors force-enabled (backend=%s)",
                        env, type(self.vector_backend).__name__)
            return
        if not module_installed("sentence_transformers"):
            logger.info("sentence_transformers not available — FTS5 only")
            return
        self._enable_vectors()
        logger.info("Vectors auto-enabled (sentence_transformers available, backend=%s)",
                    type(self.vector_backend).__name__)

    def _enable_vectors(self) -> None:
        """Build the vector backend and the pipeline that feeds it."""
        self.vector_backend = VectorBackend.with_engine(
            db_path=self.storage / "vectors.db", dimension=384
        )
        self.embedding_pipeline = EmbeddingPipeline(
            vector_backend=self.vector_backend, dimension=384
        )

    # --- Lifecycle / Resource Cleanup ---

    # ── v3.8: DeepMiner — agnostic tool-observation store ──────────────────

    def _obs_conn(self) -> sqlite3.Connection:
        """Lazy per-engine obs.db connection. Isolated from conscio.db.

        Never locks — callers hold self._obs_lock. Schema, migration and
        retention all live in conscio.obsstore, which the v3.9 hook also loads
        standalone: one owner, so the two can never drift.
        """
        if self._obs_db is None:
            self._obs_db = _obs_connect(self.storage / "obs.db")
        return self._obs_db

    def set_session(self, session_id: str) -> None:
        """Wire the platform session id so observe()/compress share it (avoids
        the 'unknown' sid mismatch)."""
        if session_id:
            self._obs_session = session_id
            self._session_explicitly_set = True

    def observe(
        self,
        tool: str,
        input_text: str = "",
        output_text: str = "",
        project: str = "",
        agent: str = "",
        session_id: str = "",
    ) -> int:
        """Fire-and-forget tool observation. 0 LLM tokens. Never raises.

        Records a raw tool call into the isolated obs.db for later full-text
        recall (recall_observations) and handoff compression
        (compress_observations). Returns the observation id, or -1 if the write
        failed — telemetry must never break the calling agent.

        Payloads are stored whole: reversibility is the whole point of the
        store, and a capture clipped at 1024 characters cannot restore anything.
        """
        sid = session_id or self._obs_session
        row = -1
        try:
            # With --awake the daemon and this agent write the same obs.db.
            # If the daemon holds the write lock, the first commit can hit a
            # transient 'database is locked'; retry (with rollback) so the
            # caller does not have to observe twice. observe() is
            # fire-and-forget, so on persistent failure we swallow and return
            # -1 as before.
            for attempt in range(_OBS_WRITE_RETRIES):
                try:
                    with self._obs_lock:
                        row = _obs_put(
                            self._obs_conn(),
                            tool=tool,
                            input_text=input_text,
                            output_text=output_text,
                            project=project,
                            agent=agent or _obs_agent_label(self.storage),
                            session_id=sid,
                            ts=naive_utcnow().isoformat(),
                        )
                    break
                except sqlite3.OperationalError as exc:
                    msg = str(exc).lower()
                    transient = ("locked" in msg or "busy" in msg
                                 or "in use" in msg)
                    if not transient or attempt == _OBS_WRITE_RETRIES - 1:
                        raise
                    try:
                        self._obs_conn().rollback()   # clear a partial txn
                    except sqlite3.OperationalError:
                        pass
                    time.sleep(_OBS_RETRY_BACKOFF_S)
        except Exception as exc:  # fire-and-forget: never break the agent
            logger.debug("observe() swallowed write error: %s", exc)
            return -1
        try:  # emit is best-effort telemetry (may fail cross-thread; ok to skip)
            self.event_bus.emit(
                type="tool:observed",
                category="session",
                data={"tool": tool[:256], "project": project[:256], "obs_id": row},
                project_dir=project[:256],
                # The caller handed us this project; nothing here inferred it.
                # An event that names no project keeps 0.0 — that is not a
                # missing value, it is the honest one.
                attribution_confidence=1.0 if project else 0.0,
            )
        except Exception as exc:
            logger.debug("observe() emit skipped: %s", exc)
        return row

    def recall_observations(
        self,
        query: str,
        k: int = 5,
        full: bool = False,
        scope: str = "session",
        project: str = "",
        session_id: str | None = None,
    ) -> list[dict]:
        """Full-text (FTS5) search over raw tool observations.

        Distinct from recall(), which searches the content store. Returns the
        matching raw tool calls, most relevant first. The query is bound as a
        literal FTS phrase (AND/OR/NOT and quotes defused) — never run as SQL.

        Scoped to the current session by default. Widening to "project" or "all"
        is a deliberate act: a caller reasoning over another session's
        observations is reasoning over content that was never in its context.
        ``scope="project"`` needs the same project string that was passed to
        observe(); it is not derivable from the storage path.

        ``session_id`` mirrors observe()'s: both default to the session wired by
        set_session(), and a caller that named a session on the way in must be
        able to name the same one on the way out.

        ``input``/``output`` carry the snippet window around the hit (elided
        with "…"), not the whole stored row: the caller asked where a term
        appears, and the padding around it is billed to their context. Pass
        ``full=True`` when the entire observation is the answer.
        """
        sid = self._obs_session if session_id is None else session_id
        try:
            with self._obs_lock:
                return _obs_search(
                    self._obs_conn(),
                    query,
                    k=k,
                    full=full,
                    scope=scope,
                    session_id=sid,
                    project=project,
                    snippet_tokens=_SNIPPET_TOKENS,
                )
        except ValueError:
            raise  # a bad scope is a caller bug, not a miss
        except Exception as exc:
            logger.debug("recall_observations swallowed: %s", exc)
            return []

    def latest_session_for_project(self, project: str) -> str:
        """Find the session_id of the most recent observation in the given project."""
        from .obsstore import latest_session_for_project as _obs_latest_session

        with self._obs_lock:
            return _obs_latest_session(self._obs_conn(), project)

    def compress_observations(self, session_id: str = "") -> dict:
        """Compress raw tool observations into a handoff via the EXISTING formatter.

        Bridges obs.db → SessionSummary → format_handoff(); costs 0 LLM tokens.
        Persists through content_store.index() under its own label — never
        touches _session_handoff.md (that path stays owned by the platform).
        Isolated per session_id, defaulting to the same sid as observe() (I5).

        Reads the session's TAIL: a handoff exists so work can resume, and the
        last calls are the state to carry over — ordering oldest-first
        described the opening moves of a long session and nothing since. Emits
        chunks rather than actions because the formatter caps actions at 5,
        which spent a fraction of HO_MAX_CHARS; chunks it renders in full, so
        the budget is enforced here.
        """
        # lazy import: avoids the engine/session_lifecycle import cycle
        from .session_lifecycle import (
            HO_MAX_CHARS,
            SemanticChunk,
            SessionSummary,
            format_handoff,
        )
        sid = session_id or self._obs_session
        with self._obs_lock:
            conn = self._obs_conn()
            total = int(conn.execute(
                "SELECT COUNT(*) FROM observations WHERE session_id=?", (sid,)
            ).fetchone()[0])
            # Text comes from obs_fts, which holds exactly what the blobs hold,
            # sliced in SQL: the handoff shows ~70 chars per field, and payloads
            # are now stored whole, so selecting them raw would drag up to
            # 200 x 1 MiB into memory to render a few kilobytes.
            rows = conn.execute(
                "SELECT f.tool, substr(f.input, 1, ?), substr(f.output, 1, ?) "
                "FROM observations o JOIN obs_fts f ON f.rowid = o.id "
                "WHERE o.session_id=? ORDER BY o.id DESC LIMIT ?",
                (_HANDOFF_FIELD_SCAN, _HANDOFF_FIELD_SCAN, sid, _HANDOFF_SCAN_LIMIT),
            ).fetchall()
        if not rows:
            return {"handoff": "", "count": 0, "session_id": sid}
        chunks: list[SemanticChunk] = []
        budget = HO_MAX_CHARS - _HANDOFF_HEADER_RESERVE
        for tool, inp, out in rows:  # newest first: they get the budget
            payload = f"{tool}: {_obs_line(inp, 70)}→{_obs_line(out, 50)}"
            budget -= len(payload) + _HANDOFF_CHUNK_OVERHEAD
            if budget < 0:
                break
            chunks.append(SemanticChunk(
                tag="obs",
                domain="observations",
                payload=payload,
                source_role="assistant",
            ))
        # one domain ⇒ rendered in list order, so restore chronology
        chunks.reverse()
        summary = SessionSummary(
            session_id=sid,
            model="deepminer",
            message_count=total,
            title=f"{total} tool observations",
            chunks=chunks,
        )
        handoff = format_handoff(summary)
        if hasattr(self, "content_store"):
            self.content_store.index(
                label=f"handoff_deepminer_{naive_utcnow().strftime('%Y%m%d_%H%M%S')}",
                content=handoff,
                category="session",
                session_id=sid,
            )
        return {"handoff": handoff, "count": total, "session_id": sid}

    def close(self) -> None:
        """Close all SQLite-backed modules and flush WAL."""
        # Run delivery_check before closing SQLite (so it can query EventBus)
        if getattr(self, "_delivery_check_enabled", False):
            try:
                from .gates import delivery_check as _delivery_check
                _delivery_check(self)
            except Exception:
                pass
        self._closed = True
        for mod in (self.content_store, self.event_bus, self.token_tracker, self.vector_backend):
            if mod is None:
                continue
            try:
                mod.close()
            except Exception:
                pass
        # v4.7: close the outcome store too
        try:
            if getattr(self, "outcome_store", None) is not None:
                self.outcome_store.close()
        except Exception:
            pass
        # v3.8: close DeepMiner obs.db (idempotent)
        obs_db = getattr(self, "_obs_db", None)
        if obs_db is not None:
            try:
                obs_db.close()
            except Exception:
                pass
            self._obs_db = None
        # Close ContentLayerManager (SessionRAG HTTP connections)
        try:
            self.content_layer.close()
        except Exception:
            pass
        pipeline = getattr(self, "_act_pipeline", None)
        if pipeline is not None:
            for closer in (pipeline.ledger,
                           getattr(pipeline, "trust", None),
                           getattr(pipeline, "breaker", None)):
                try:
                    if closer is not None:
                        closer.close()
                except Exception:
                    pass
        skills = getattr(self, "_skills", None)
        if skills is not None:
            try:
                skills.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── v1.0 volition layer (spec section 6) ────────────────────────────

    def attach_adapter(self, adapter, *, sandbox_root=None, registry=None,
                       skeptic_adapter=None, skeptic_mode=None,
                       autonomy_cap=2, intercept_enabled=False):
        """Wire the agentic pipeline. reflect() is unaffected.

        skeptic_adapter: optional second cortex for the audit
        (mixed-cortex); defaults to the actor adapter.
        skeptic_mode: "checklist"/"open"; None (default) starts as
        checklist and lets probe() pick it from the measured profile.
        autonomy_cap: operator ceiling for earned autonomy (1=PROPOSE,
        2=SUPERVISED, 3=AUTONOMOUS). Effective = min(cap, earned).
        """
        from pathlib import Path

        from .agency.act import ActPipeline
        from .agency.adapter import Meter, MeteredAdapter
        from .agency.breaker import CircuitBreaker
        from .agency.ledger import ActionLedger
        from .agency.skeptic import Skeptic
        from .agency.skills import SkillLibrary
        from .agency.tools import make_default_registry
        from .agency.trust import TrustMatrix

        sandbox = Path(sandbox_root or Path.home() / ".conscio" / "sandbox")
        registry = registry or make_default_registry(
            sandbox_root=sandbox, content_store=self.content_store,
            event_bus=self.event_bus, goal_generator=self.goals,
            world_model=self.world)
        db = self.storage / "conscio.db"                    # shared DB
        meter = Meter()
        metered = MeteredAdapter(adapter, meter)
        metered_skeptic = (MeteredAdapter(skeptic_adapter, meter)
                           if skeptic_adapter is not None else metered)
        ledger = ActionLedger(db)
        trust = TrustMatrix(
            self.meta, ledger, db,
            reflect_count_fn=lambda: len(self.event_bus.query(
                type="reflection", limit=_REFLECT_COUNT_LIMIT)),
            trips_since_fn=self._trips_since)
        skeptic = Skeptic(metered_skeptic, mode=skeptic_mode or "checklist",
                          facts_fn=self.world.query)
        self._skeptic_mode_explicit = skeptic_mode is not None
        self._act_meter = meter
        self._model_profile = None
        self._act_pipeline = ActPipeline(
            adapter=metered, registry=registry, ledger=ledger,
            breaker=CircuitBreaker(ledger, self.event_bus,
                                   trust=trust, db_path=db),
            skeptic=skeptic, trust=trust, meta=self.meta,
            autonomy_cap=autonomy_cap,
            recall_fn=lambda q: self.recall(q, k=3),
            emit_fn=self.event_bus.emit,
            executable_fn=self.goals.is_executable,   # #7 provenance gate
            intercept_enabled=intercept_enabled)
        # v2.7: wire Intercepter into the gateway if enabled
        if intercept_enabled:
            from .agency.intercepter import Intercepter, InterceptionLoop
            gw = self._act_pipeline.gateway
            gw._loop = InterceptionLoop(
                gw.adapter, Intercepter(),
                max_iterations=3,
                emit_fn=self.event_bus.emit,
            )
        # v1.1: procedural memory — distilled by the dream, served to the
        # actor as few-shot rendered for the gateway's effective tier.
        skills = SkillLibrary(db)
        self._skills = skills
        pipeline = self._act_pipeline
        pipeline.few_shot_provider = lambda goal: skills.few_shot(
            goal, tier=pipeline.gateway.effective_tier())
        # The breaker that owns the lockdown condition only exists from here on;
        # a latch loaded from disk can finally be checked against it (BUG-37).
        self._reconcile_lockdown()
        return self._act_pipeline

    def _trips_since(self, ts: float) -> int:
        """Breaker trips since `ts` — feeds L3 earned autonomy (5.7)."""
        since = naive_utc_from_epoch(ts).isoformat() if ts else None
        events = self.event_bus.query(type="error", category="system",
                                      since=since, limit=1000)
        return sum(1 for e in (events or [])
                   if "Intractable dissonance" in str(
                       e.to_dict() if hasattr(e, "to_dict") else e))

    def _reconcile_lockdown(self, state=None) -> bool:
        """Re-derive the persisted global lockdown latch from the breaker (R5).

        The latch is written to disk so a lockdown survives a restart, but the
        condition behind it does not: CircuitBreaker.quarantined_count()
        deliberately ignores rows whose cooldown has lapsed, so expiry holds
        "whether or not anything sweeps the table". Nothing reconciled the two,
        and ActPipeline.act() short-circuits on the flag *before* consulting the
        breaker — so an agent that once hit quorum stayed paralysed for good
        (BUG-37). Safety is not weakened: the latch is released only by the same
        component that raises it, and only once it says no lockdown is due.

        Fails closed — with no breaker to ask, the latch stands.

        Returns the reconciled value."""
        state = self._state if state is None else state
        if not state.action_lockdown:
            return False
        breaker = getattr(getattr(self, "_act_pipeline", None), "breaker", None)
        if breaker is None or breaker.global_lockdown_due():
            return True

        # Persist through the engine's own state only. A caller-supplied state
        # may be older than what is on disk; writing it back would clobber the
        # rest of the summary to clear one flag. Read the engine's flag before
        # the mutation below — `state` is usually the same object.
        persist = self._state.action_lockdown
        state.action_lockdown = False
        if persist:
            self._state.action_lockdown = False
            self.ctx.save_state(self._state)
            try:                              # a strict bus must not re-paralyse
                self.event_bus.emit(
                    type="system", category="system",
                    data={"message": ("global lockdown released: no goal is "
                                      "still quarantined"),
                          "quarantined": breaker.quarantined_count()},
                    priority=5)
            except Exception:
                pass
        return False

    def act(self, state=None):
        """Run one L1 PROPOSE cycle downstream of reflect().

        Two entry paths, deliberately different (R9 / I-R9):
          1. Direct call (this method) = the human escape hatch. NOT awake-gated by
             design, but still fully governed by the ActPipeline — skeptic, breaker,
             trust, and the R6 approval queue (R7 / R9 / I-A4). It cannot run an
             action the pipeline would refuse.
          2. Daemon / autonomy path = routed via run(), which IS awake-gated: asleep
             => reflect-only, zero arbiter/act/dream. The daemon never calls act()
             directly (see tests/test_daemon.py).
        """
        from .agency.act import ActReport, ActStatus

        if getattr(self, "_act_pipeline", None) is None:
            return ActReport(status=ActStatus.FAILED,
                             reason="no adapter attached")
        state = state or self._state          # current state held by engine
        # A long-lived daemon never re-attaches, so cooldowns lapse mid-process:
        # reconcile here too, before the pipeline short-circutes on the latch.
        self._reconcile_lockdown(state)
        report = self._act_pipeline.act(state)
        # v4.8.1 (batch H, round 2): expire the daemon_check goal AFTER the
        # act() attempt on it, whatever the status. Nothing else retires it
        # (complete_goal is a tool the model must call; act never changes
        # goal status), so it stayed active forever and the arbiter
        # re-selected it every heartbeat — the cooldown gate on CREATION
        # never fired because the goal was never re-created. Expiring AFTER
        # the act is what makes the ledger's last_attempt_ts (the attempt
        # that just burned quota) the cooldown's clock: the same call that
        # spent the proposal retires the goal, so the next reflect()
        # regenerates only when the cooldown window allows it.
        from .awake.calibration import MaintenanceCooldown, maintenance_goal_fingerprint
        _ledger = getattr(getattr(self, "_act_pipeline", None), "ledger", None)
        if _ledger is not None:
            _maint_fp = maintenance_goal_fingerprint()
            _last = _ledger.last_attempt_ts(_maint_fp)
            cooldown = getattr(self, "_maintenance_cooldown", None)
            if cooldown is None:
                cooldown = self._maintenance_cooldown = \
                    MaintenanceCooldown(minutes=self.MAINTENANCE_COOLDOWN_MIN)
            if _last is not None:
                for g in list(getattr(self.goals, "_goals", [])):
                    if (g.status == "active"
                            and g.drive is not None
                            and g.drive.value == "maintenance"
                            and g.metadata.get("check_type") == "daemon_check"):
                        if not cooldown.should_generate(
                                last_attempt_ts=_last):
                            # Inside the cooldown window: the just-attempted
                            # goal must not be re-selected next heartbeat.
                            g.status = "expired"
                        break
        skills = getattr(self, "_skills", None)
        if skills is not None:                # v1.1: outcome -> skill score
            skills.settle(report)
        if report.lockdown:
            state.action_lockdown = True
            # awake (R9) is engine-scoped, not a property of a transient act
            # state — never let a passed-in state downgrade the persisted flag.
            state.awake = self._state.awake
            self.ctx.save_state(state)
        return report

    def approve(self, ledger_id: int):
        return self._act_pipeline.approve(ledger_id)

    def reject(self, ledger_id: int, reason: str = "") -> None:
        self._act_pipeline.reject(ledger_id, reason)

    def pending(self, limit: int = 20):
        """Approval queue (R6): proposals awaiting approve()/reject()."""
        if getattr(self, "_act_pipeline", None) is None:
            return []
        return self._act_pipeline.ledger.pending(limit)

    # --- v2.2.2 "Trial": sandboxed replay of a quarantined foreign skill ---

    def trial_quarantined(self, rowid: int, *, enable_trial: bool = False):
        """Replay a quarantined foreign skill in a throwaway fs-only sandbox
        and record a binary pass/fail on its quarantine row. Fully isolated —
        never writes the agent's ledger/skills/trust/breaker. Default off.

        Returns a trial.TrialOutcome (ran) or trial.TrialRefusal (refused)."""
        import json
        import shutil
        import tempfile
        import time
        from pathlib import Path

        from .agency import trial as trial_mod
        from .agency.tools import make_default_registry
        from .noosphere import artifact, quarantine
        from .noosphere.paths import quarantine_db_path

        if not enable_trial:
            return trial_mod.TrialRefusal("trial disabled; pass --enable-trial")
        pipe = getattr(self, "_act_pipeline", None)
        if pipe is None or getattr(pipe, "skeptic", None) is None:
            return trial_mod.TrialRefusal("trial requires an adapter")

        qdb = quarantine_db_path(self.storage)
        row = quarantine.get(qdb, rowid)
        if row is None:
            return trial_mod.TrialRefusal(f"no quarantine row #{rowid}")
        if row.import_status != "quarantined":
            return trial_mod.TrialRefusal(
                f"row #{rowid} is not quarantined (status={row.import_status})")
        if artifact.content_hash(row.artifact_json) != row.content_sha256:
            quarantine.note_trial(qdb, rowid, result="tampered",
                                  error="content_sha256 mismatch",
                                  ts=time.time())
            return trial_mod.TrialRefusal(
                f"row #{rowid} tampered (content_sha256 mismatch)")
        try:
            steps = json.loads(row.plan_template)
            if not isinstance(steps, list):
                raise ValueError("plan_template is not a list")
        except (ValueError, TypeError) as exc:
            quarantine.note_trial(qdb, rowid, result="corrupt_plan",
                                  error=str(exc), ts=time.time())
            return trial_mod.TrialRefusal(f"row #{rowid} has a corrupt plan")

        tmp = tempfile.mkdtemp(prefix="conscio-trial-")
        try:
            reg = make_default_registry(
                sandbox_root=Path(tmp), content_store=None, event_bus=None,
                goal_generator=None)
            outcome = trial_mod.run_trial(
                steps, goal_text=row.goal_text, skeptic=pipe.skeptic,
                registry=reg)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

        quarantine.record_trial(qdb, rowid, passed=outcome.passed,
                                result=outcome.result, error=outcome.error,
                                ts=time.time())
        return outcome

    # --- v2.3 "Promotion": graduate a quarantined skill into the library ---

    def promote_quarantined(self, rowid: int, *, enable_promote: bool = False):
        """Graduate a quarantined foreign skill that has earned >= 3 clean
        local trials into the live SkillLibrary, seeded with its trial
        counters. No adapter, no sandbox, no execution: a data gate that reads
        the trial evidence and writes one row. Default off.

        Unlike trial (which records a tamper via note_trial), promotion refuses
        a tampered/already-promoted/gate-failed row WITHOUT writing anything —
        it only ever writes on a successful graft (the skills row + the
        promoted-stamp). A refusal leaves the quarantine row untouched.

        Returns a promote.PromoteResult (promoted) or promote.PromoteRefusal."""
        import time

        from .agency import promote as promote_mod
        from .agency.skills import SkillLibrary
        from .agency.tools import make_default_registry
        from .noosphere import artifact, quarantine
        from .noosphere.paths import quarantine_db_path

        if not enable_promote:
            return promote_mod.PromoteRefusal(
                "promotion disabled; pass --enable-promote")

        qdb = quarantine_db_path(self.storage)
        row = quarantine.get(qdb, rowid)
        if row is None:
            return promote_mod.PromoteRefusal(f"no quarantine row #{rowid}")
        if row.import_status != "quarantined":
            return promote_mod.PromoteRefusal(
                f"row #{rowid} is not quarantined "
                f"(status={row.import_status})")
        if row.promoted_ts > 0:
            return promote_mod.PromoteRefusal(
                f"row #{rowid} already promoted "
                f"(skill #{row.promoted_skill_id})")
        if artifact.content_hash(row.artifact_json) != row.content_sha256:
            return promote_mod.PromoteRefusal(
                f"row #{rowid} tampered (content_sha256 mismatch)")

        # Live tool registry, real backends. Used ONLY for registry.get(tool)
        # existence checks — nothing is dispatched, so no tmpdir is needed (the
        # one structural difference from trial). make_default_registry mkdirs
        # sandbox_root, so it points inside the instance storage (never real
        # home), keeping promotion and its tests side-effect-clean.
        reg = make_default_registry(
            sandbox_root=self.storage / "sandbox",
            content_store=self.content_store, event_bus=self.event_bus,
            goal_generator=self.goals, world_model=self.world)
        decision = promote_mod.evaluate_promotion(
            trial_successes=row.trial_successes,
            trial_failures=row.trial_failures,
            tool_seq=row.tool_seq, registry=reg)
        if not decision.ok:
            return promote_mod.PromoteRefusal(decision.reason)

        lib = SkillLibrary(self.storage / "conscio.db")
        try:
            sid = lib.graft(row.goal_fp, row.goal_text, row.tool_seq,
                            row.plan_template, successes=row.trial_successes,
                            failures=row.trial_failures)
        finally:
            lib.close()
        if sid is None:
            return promote_mod.PromoteRefusal(
                "skill already present (goal_fp, tool_seq collision)")

        quarantine.mark_promoted(qdb, rowid, ts=time.time(), skill_id=sid)
        return promote_mod.PromoteResult(sid, row.trial_successes,
                                         row.trial_failures)

    # --- v2.0 "Connect": propose-only cognition (never executes) ---

    def propose_action(self, intent: dict) -> dict:
        """Audit an explicit host intent with the Skeptic. Never executes."""
        from .agency.contracts import PROPOSAL_SCHEMA, proposal_from_dict, validate
        pipe = getattr(self, "_act_pipeline", None)
        if pipe is None or pipe.skeptic is None:
            return self._no_adapter_result()
        errors = validate(intent, PROPOSAL_SCHEMA)
        if errors:
            return {"verdict": "FAIL", "reasons": errors, "risk_flags": [],
                    "confidence": 0.0, "proposal": None}
        goal = str(intent.get("goal", ""))
        proposal = proposal_from_dict(intent, goal_id=goal)
        verdict = pipe.skeptic.audit(proposal, goal_text=goal)
        self._emit_proposal(proposal, verdict)
        return self._proposal_result(proposal, verdict)

    def propose_plan(self, goal: str,
                     tools: list[dict] | None = None) -> dict:
        """Generate ONE audited action from a goal (Actor), constrained to the
        host's declared tool vocabulary. Never executes; not free-form."""
        from .agency import goal_fingerprint
        from .agency.actor import build_actor_prompt
        from .agency.contracts import PROPOSAL_SCHEMA
        from .agency.gateway import GatewayError
        pipe = getattr(self, "_act_pipeline", None)
        if pipe is None or pipe.skeptic is None:
            return self._no_adapter_result()
        if not tools:
            return {"verdict": "FAIL",
                    "reasons": [("propose_plan requires a declared tool "
                                "vocabulary")],
                    "risk_flags": [], "confidence": 0.0, "proposal": None}
        catalog = "\n".join(f"- {t['name']}: {t.get('description', '')}"
                            for t in tools)
        prompt = build_actor_prompt(
            state=self._state, goal_text=goal, catalog_text=catalog,
            recall_snippets=self.recall(goal), few_shot=[])
        try:
            proposal = pipe.gateway.request_action(
                prompt, PROPOSAL_SCHEMA, goal_id=goal_fingerprint(goal),
                tool_names=[t["name"] for t in tools])
        except GatewayError as exc:
            return {"verdict": "FAIL", "reasons": [f"decode failed: {exc}"],
                    "risk_flags": [], "confidence": 0.0, "proposal": None}
        from .agency.tools import tool_doc
        # The host declared this vocabulary in this call, so a name drawn from
        # it is verified by construction — the auditor must not refuse it for
        # being unfamiliar. A name outside the declaration gets no doc, which
        # is exactly the case the auditor should be suspicious of.
        declared = {t["name"]: t.get("description", "") for t in tools}
        verdict = pipe.skeptic.audit(
            proposal, goal_text=goal,
            tool_doc=(tool_doc(proposal.tool, declared[proposal.tool])
                      if proposal.tool in declared else ""))
        self._emit_proposal(proposal, verdict)
        return self._proposal_result(proposal, verdict)

    @staticmethod
    def _no_adapter_result() -> dict:
        return {"verdict": "FAIL", "reasons": ["no adapter attached"],
                "risk_flags": [], "confidence": 0.0, "proposal": None}

    def _emit_proposal(self, proposal, verdict) -> None:
        self.event_bus.emit(
            type="proposal:audited", category="consciousness",
            data={"tool": proposal.tool, "args": proposal.args,
                  "rationale": proposal.rationale,
                  "expected_outcome": proposal.expected_outcome,
                  "verdict": verdict.verdict, "reasons": verdict.reasons,
                  "confidence": verdict.confidence})

    @staticmethod
    def _proposal_result(proposal, verdict) -> dict:
        return {"verdict": verdict.verdict, "reasons": verdict.reasons,
                "risk_flags": verdict.risk_flags,
                "confidence": verdict.confidence,
                "proposal": {"tool": proposal.tool, "args": proposal.args,
                             "rationale": proposal.rationale,
                             "expected_outcome": proposal.expected_outcome,
                             "action_id": proposal.action_id}}

    # --- v2.0.1 "Connect": host-executed audited act (opt-in) ---

    @staticmethod
    def _manifest_hash(manifest: list) -> str:
        import hashlib
        import json
        return hashlib.sha256(
            json.dumps(manifest, sort_keys=True, default=str).encode()
        ).hexdigest()

    def enable_host_act(self, manifest: list) -> bool:
        """Build/replace the HostActChannel from a host-declared manifest.

        same manifest                       -> idempotent no-op
        different + in-flight ledger rows    -> reject (keep current)
        different + clean                    -> replace
        invalid manifest / no adapter        -> reject atomically (no half-enable)
        """
        from .agency.host_act import HostActChannel
        from .agency.tools import registry_from_manifest

        self._host_act_error = ""
        pipe = getattr(self, "_act_pipeline", None)
        if pipe is None or pipe.skeptic is None:
            self._host_act_error = "act requires an adapter"
            return False
        try:
            new_hash = self._manifest_hash(manifest)
        except (TypeError, ValueError) as exc:
            self._host_act_error = f"invalid manifest: {exc}"
            return False
        existing = getattr(self, "_host_act", None)
        if existing is not None and new_hash == getattr(self, "_host_act_hash",
                                                        ""):
            return True                                  # idempotent
        if existing is not None and pipe.ledger.has_in_flight():
            self._host_act_error = "cannot change manifest with in-flight actions"
            return False
        try:
            registry = registry_from_manifest(manifest)
        except ValueError as exc:
            self._host_act_error = f"invalid manifest: {exc}"
            return False                                 # atomic: state unchanged
        self._host_act = HostActChannel(
            ledger=pipe.ledger, skeptic=pipe.skeptic, breaker=pipe.breaker,
            trust=pipe.trust, registry=registry, emit_fn=self.event_bus.emit,
            awake_fn=lambda: self.awake)
        self._host_act_hash = new_hash
        return True

    @property
    def host_act(self):
        return getattr(self, "_host_act", None)

    @property
    def host_act_error(self) -> str:
        return getattr(self, "_host_act_error", "")

    def probe(self, *, force: bool = False):
        """Run/refresh the ProbeSuite for the attached adapter (spec 5.10).

        Lazy: called by run() before the first cycle, or manually. Never
        called by reflect() (P6) nor by act(). A valid profile re-tiers
        the gateway, picks the skeptic mode (unless one was set
        explicitly at attach) and caps the actor's tool catalog. An
        invalid profile (backend gave no signal) changes nothing.
        """
        if getattr(self, "_act_pipeline", None) is None:
            return None
        if self._model_profile is not None and not force:
            return self._model_profile
        from .agency.profiles import (
            ProbeSuite,
            choose_tier,
            max_visible_tools,
            prompt_complexity,
            skeptic_mode,
        )
        suite = ProbeSuite(self._act_pipeline.adapter,
                           self.storage / "conscio.db")
        try:
            profile = suite.get(force=force)
        finally:
            suite.close()
        self._model_profile = profile
        if profile.valid:
            self._act_pipeline.gateway.tier = choose_tier(profile)
            self._act_pipeline.max_visible_tools = max_visible_tools(profile)
            self._act_pipeline.prompt_complexity = prompt_complexity(profile)
            # v3.6: allow daemon_control to override prompt complexity to 'full'
            if self.storage:
                ctrl = Path(self.storage) / "daemon_control.json"
                if ctrl.exists():
                    try:
                        overrides = json.loads(ctrl.read_text())
                        if overrides.get("prompt_complexity") == "full":
                            self._act_pipeline.prompt_complexity = "full"
                    except (json.JSONDecodeError, OSError):
                        pass
            if (not getattr(self, "_skeptic_mode_explicit", False)
                    and self._act_pipeline.skeptic is not None):
                self._act_pipeline.skeptic.mode = skeptic_mode(profile)
        return profile

    def _last_daemon_check_ts(self) -> float | None:
        """v4.8.1 (batch H): when the last daemon_check ATTEMPT hit the
        ledger — any status (executed/failed/rejected all burned quota).
        None when it never did. Uses the PUBLIC ledger API and the
        fingerprint DERIVED from the same description constant the engine
        regenerates (hostile review, lever 1)."""
        ledger = getattr(getattr(self, "_act_pipeline", None), "ledger", None)
        if ledger is None:
            return None
        from .awake.calibration import maintenance_goal_fingerprint
        return ledger.last_attempt_ts(maintenance_goal_fingerprint())

    def run(self, budget=None, *, world_state=""):
        """L3 heartbeat: reflect -> arbiter/act -> (dream), repeated
        under a binding ActBudget (P3). Probes the cortex once, lazily.

        R9 (Awake Mode): self-initiated autonomy is gated here. Asleep (the
        default) ⇒ perceive + reflect() once and return, with ZERO
        arbiter/act/dream — observation stays always-on, autonomy does not.
        A direct human engine.act() call is deliberately NOT gated."""
        from .agency.loop import ActBudget, AutonomyLoop, RunReport

        # The failure-rate brake belongs to one heartbeat; opening the window
        # here is what stops the previous one's brake being read as current.
        self._run_started_at = naive_utcnow().isoformat()
        if not self.awake:
            self.reflect(world_state=world_state)
            return RunReport(stopped="asleep")

        if getattr(self, "_act_pipeline", None) is None:
            # Awake but no inference backend: autonomy is impossible, yet
            # observation stays always-on — perceive + reflect, then report.
            # v3.9.4: and housekeeping is not autonomy. Every reflection here
            # writes to the ledgers the dream prunes, and DreamCycle makes no
            # model call, so gating it on an adapter only makes them grow.
            self.reflect(world_state=world_state)
            if self.dream_recommended.recommended:
                self.dream()
            return RunReport(stopped="no adapter attached")
        # v4.8.1 (batch H): rolling 24h cost ceiling for the awake loop,
        # counted from the action ledger (survives restarts). Checked
        # BEFORE probe(): the ProbeSuite runs real model calls when no
        # cached profile exists, so an over-budget loop must not pay for
        # a probe it cannot use. When the ceiling trips: perceive +
        # reflect continue, act() is skipped, and the trip is REPORTED on
        # the event bus — never silent. The daemon already persists
        # RunReport.stopped in its heartbeat file (daemon.py), so the
        # 'daily_cost_ceiling' stop reason reaches operators with no new
        # channel.
        from .awake.calibration import DailyAttemptCeiling
        ceiling = getattr(self, "_daily_attempt_ceiling", None)
        if ceiling is None:
            ceiling = self._daily_attempt_ceiling = DailyAttemptCeiling(
                max_attempts_per_day=self.DAILY_LLM_CEILING,
                ledger=self._act_pipeline.ledger)
        if not ceiling.allows_more():
            self.reflect(world_state=world_state)
            report_line = ceiling.report()
            bus = getattr(self, "event_bus", None)
            if bus is not None:
                try:
                    bus.emit(type="system", category="system",
                             data={"message": report_line},
                             priority=7)
                except Exception:          # a strict bus must not crash run()
                    pass
            return RunReport(stopped="daily_cost_ceiling")
        self.probe()
        loop = AutonomyLoop(self, self._act_pipeline, self._act_meter)
        if budget is None and self.awake:
            from .awake.budget import AwakeBudget
            budget = AwakeBudget()
        return loop.run(budget or ActBudget(), world_state=world_state)

    # --- v2.14: the cognitive cycle (an explicit, useful reflect loop) ---

    def _synthesize(self) -> dict:
        """Offline consolidation of the just-run reflection into a focus insight.

        Pure heuristic (no LLM): reads the coherence snapshot, average
        confidence, and the top active goals the reflection produced, and
        distills a one-line insight the host can act on. Advisory — reads
        state, never mutates it.
        """
        coh = self.last_coherence
        score = coh.score if coh else None
        tension = coh.dominant.dimension if (coh and coh.dominant) else None
        try:
            confidence = self.meta.average_confidence()
        except Exception:
            confidence = 0.5
        focus = [g.description for g in self.goals.active_goals()][:3]
        parts = []
        if score is not None:
            parts.append(f"coherence {score:.2f}")
        parts.append(f"confidence {confidence:.2f}")
        if tension:
            parts.append(f"tension:{tension}")
        parts.append(f"focus:{focus[0]}" if focus else "focus:none")
        return {"coherence": score, "tension": tension,
                "confidence": confidence, "focus_goals": focus,
                "insight": "; ".join(parts)}

    def cognitive_cycle(self, world_state: str = "",
                        recent_events: list[str] | None = None,
                        confidence: float = 0.5,
                        anomalies: list[str] | None = None,
                        *, act: bool = True) -> dict:
        """One explicit, useful cognitive pass — the reflect loop, surfaced.

        Runs and reports the stages the agent actually goes through:

          1. Reflect      — reflect() (perceive/coherence/goals/self-improve;
                            all offline-heuristic)
          2. Synthesize   — consolidate into a focus insight (offline)
          3. Propose+Act  — act(): an audited proposal, fully gated. Skipped
                            when no adapter is attached or act=False. NOT
                            awake-gated — the host drives this loop, and act()
                            cannot run anything the ActPipeline would refuse.
          4. Learn        — the act stage's outcome (skills settle inside act())
          5. Self-improve — auto-evolution proposals from observed error
                            patterns (human-gated; dedup makes it idempotent)

        Returns a JSON-serializable report. Advisory + safe by construction.
        """
        reflection = self.reflect(world_state=world_state,
                                  recent_events=recent_events,
                                  confidence=confidence, anomalies=anomalies)
        synthesis = self._synthesize()

        action = None
        learning: dict = {"from_action": None}
        if act and getattr(self, "_act_pipeline", None) is not None:
            report = self.act()
            status = getattr(getattr(report, "status", None), "value", None)
            action = {"status": status,
                      "reason": getattr(report, "reason", None),
                      "ledger_id": getattr(report, "ledger_id", None),
                      "lockdown": getattr(report, "lockdown", False)}
            learning = {"from_action": status}   # skills.settle ran inside act()

        try:
            new_props = self.evolution.observe_errors(self.meta)
        except Exception:
            new_props = []
        self_improvement = {
            "new_proposals": [getattr(p, "description", str(p)) for p in new_props],
            "pending": len(self.evolution.pending_proposals()),
        }

        return {"reflection": reflection, "synthesis": synthesis,
                "action": action, "learning": learning,
                "self_improvement": self_improvement}


# --- CLI Entry Point ---


