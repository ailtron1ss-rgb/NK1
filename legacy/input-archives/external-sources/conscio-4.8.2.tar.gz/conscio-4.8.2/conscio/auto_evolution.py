"""
Auto-Evolution — Self-modification with safety gates.

The agent's ability to improve itself:
- Propose skill modifications based on error patterns
- Suggest prompt adjustments based on meta-cognition
- Detect opportunities for new skills
- ALL changes require human approval before being applied
"""

from __future__ import annotations

import json
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

from .guards import atomic_write_text

if TYPE_CHECKING:
    from .meta_cognition import MetaCognition


class EvolutionType(Enum):
    SKILL_PATCH = "skill_patch"           # Modify an existing skill
    SKILL_CREATE = "skill_create"         # Create a new skill
    MEMORY_UPDATE = "memory_update"       # Update memory with new facts
    PROMPT_ADJUST = "prompt_adjust"       # Suggest prompt changes
    CONFIG_CHANGE = "config_change"       # Suggest config changes
    PATTERN_LEARN = "pattern_learn"       # Learn from a recurring pattern


class ProposalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    APPLIED = "applied"
    ROLLED_BACK = "rolled_back"


class EvolutionProposal:
    """A proposed self-modification, awaiting human approval."""

    def __init__(
        self,
        evolution_type: EvolutionType,
        description: str,
        rationale: str,
        changes: dict,
        risk_level: str = "low",  # low | medium | high
    ):
        self.id = f"evo_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        self.evolution_type = evolution_type
        self.description = description
        self.rationale = rationale
        self.changes = changes
        self.risk_level = risk_level
        self.status = ProposalStatus.PENDING
        self.created_at = datetime.now().isoformat()
        self.reviewed_at: str | None = None
        self.applied_at: str | None = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.evolution_type.value,
            "description": self.description,
            "rationale": self.rationale,
            "changes": self.changes,
            "risk_level": self.risk_level,
            "status": self.status.value,
            "created_at": self.created_at,
            "reviewed_at": self.reviewed_at,
            "applied_at": self.applied_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> EvolutionProposal:
        p = cls(
            evolution_type=EvolutionType(data["type"]),
            description=data["description"],
            rationale=data["rationale"],
            changes=data["changes"],
            risk_level=data.get("risk_level", "low"),
        )
        p.id = data.get("id", p.id)
        p.status = ProposalStatus(data.get("status", "pending"))
        p.created_at = data.get("created_at", p.created_at)
        p.reviewed_at = data.get("reviewed_at")
        p.applied_at = data.get("applied_at")
        return p


class AutoEvolution:
    """
    Self-modification engine with mandatory human approval gates.
    
    SAFETY RULES (non-negotiable):
    1. No modification is ever applied automatically
    2. All proposals require explicit human approval
    3. High-risk proposals require additional confirmation
    4. All changes are logged and reversible
    5. The engine cannot modify its own safety rules
    """

    PROPOSAL_FILE = "evolution_proposals.json"

    def __init__(self, storage_path: Path):
        self.path = storage_path / self.PROPOSAL_FILE
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._proposals: list[EvolutionProposal] = self._load()

    def _load(self) -> list[EvolutionProposal]:
        # B-013: broaden to ValueError (covers UnicodeDecodeError on a binary
        # file) + type guard so a corrupt/legacy proposals file degrades to []
        # instead of crashing engine.__init__ (I-S4).
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                if isinstance(data, list):
                    return [EvolutionProposal.from_dict(p) for p in data]
            except (OSError, ValueError, KeyError, TypeError, AttributeError):
                pass
        return []

    def _save(self) -> None:
        # v3.9.4: atomic, because `write_text` truncates before it writes and
        # `_load` degrades a torn file to [] — a reader landing in that window
        # does not see a corrupt file, it sees a mind with no proposals at all.
        # Does NOT make concurrent writers safe: two processes still overwrite
        # each other's list wholesale (last writer wins).
        data = [p.to_dict() for p in self._proposals]
        atomic_write_text(self.path, json.dumps(data, indent=2, ensure_ascii=False))

    # --- Proposal Generation ---

    def propose_skill_patch(
        self,
        skill_name: str,
        issue: str,
        suggested_fix: str,
        rationale: str,
    ) -> EvolutionProposal:
        """Propose a modification to an existing skill."""
        proposal = EvolutionProposal(
            evolution_type=EvolutionType.SKILL_PATCH,
            description=f"Patch skill '{skill_name}': {issue}",
            rationale=rationale,
            changes={
                "skill_name": skill_name,
                "issue": issue,
                "suggested_fix": suggested_fix,
            },
            risk_level="low",
        )
        self._proposals.append(proposal)
        self._save()
        return proposal

    def propose_skill_create(
        self,
        skill_name: str,
        description: str,
        content_sketch: str,
        rationale: str,
    ) -> EvolutionProposal:
        """Propose creating a new skill."""
        proposal = EvolutionProposal(
            evolution_type=EvolutionType.SKILL_CREATE,
            description=f"Create skill '{skill_name}': {description}",
            rationale=rationale,
            changes={
                "skill_name": skill_name,
                "description": description,
                "content_sketch": content_sketch,
            },
            risk_level="medium",
        )
        self._proposals.append(proposal)
        self._save()
        return proposal

    def propose_memory_update(
        self,
        key: str,
        value: str,
        rationale: str,
    ) -> EvolutionProposal:
        """Propose updating a memory entry."""
        proposal = EvolutionProposal(
            evolution_type=EvolutionType.MEMORY_UPDATE,
            description=f"Update memory '{key}'",
            rationale=rationale,
            changes={"key": key, "value": value},
            risk_level="low",
        )
        self._proposals.append(proposal)
        self._save()
        return proposal

    def propose_pattern_learn(
        self,
        pattern: str,
        lesson: str,
        rationale: str,
    ) -> EvolutionProposal:
        """Propose learning from a recurring pattern."""
        proposal = EvolutionProposal(
            evolution_type=EvolutionType.PATTERN_LEARN,
            description=f"Learn pattern: {pattern}",
            rationale=rationale,
            changes={"pattern": pattern, "lesson": lesson},
            risk_level="low",
        )
        self._proposals.append(proposal)
        self._save()
        return proposal

    # --- Auto-observation from MetaCognition ---

    def observe_errors(self, meta_cognition: MetaCognition) -> list[EvolutionProposal]:
        """
        Observe error patterns from MetaCognition and auto-propose fixes.

        For each frequent error (count >= 2), generates a PATTERN_LEARN proposal
        with the pattern and a suggested lesson. Deduplicates against existing
        pending proposals to avoid spam.

        Returns list of newly created proposals (empty if nothing new).
        """

        frequent = meta_cognition.frequent_errors(min_count=2)
        if not frequent:
            return []

        # Dedup against every verdict that still stands (v3.9.4). Checking only
        # PENDING meant answering a proposal — rejecting it, or applying it —
        # took it out of the set that suppresses it, so the same one came back
        # on the next observation. ROLLED_BACK is excluded on purpose: the
        # change was undone, so proposing it again is a fresh question.
        existing_descs = {
            p.description for p in self._proposals
            if p.status is not ProposalStatus.ROLLED_BACK
        }

        new_proposals = []
        for error in frequent:
            pattern = error.get("pattern", "unknown")
            count = error.get("count", 0)
            # This must match what propose_pattern_learn generates as description
            expected_desc = f"Learn pattern: Recurring error: {pattern}"

            if expected_desc in existing_descs:
                continue

            # Infer a lesson from the error pattern
            lesson = f"Add guard/check for '{pattern}' — occurred {count}x without resolution"

            proposal = self.propose_pattern_learn(
                pattern=f"Recurring error: {pattern}",
                lesson=lesson,
                rationale=f"Auto-observed: error '{pattern}' occurred {count} times. "
                          f"Suggesting pattern capture to prevent recurrence.",
            )
            new_proposals.append(proposal)
            existing_descs.add(proposal.description)

        return new_proposals

    # --- Review & Approval ---

    @staticmethod
    def _id_of(ref: str | EvolutionProposal) -> str:
        """The id of a proposal or of its id — a caller holding one has both.

        These methods answer None for "no such pending proposal", so an
        argument that could never name one must not borrow that answer:
        `reject(proposal)` returned None and the rejection was silently
        dropped, indistinguishable from a stale id.
        """
        if isinstance(ref, EvolutionProposal):
            return ref.id
        if not isinstance(ref, str):
            raise TypeError(
                "proposal must be an EvolutionProposal or its id string,"
                f" got {type(ref).__name__}"
            )
        return ref

    def approve(self, proposal_id: str | EvolutionProposal) -> EvolutionProposal | None:
        """Approve a pending proposal. Returns None if not found or not pending."""
        wanted = self._id_of(proposal_id)
        for p in self._proposals:
            if p.id == wanted and p.status == ProposalStatus.PENDING:
                p.status = ProposalStatus.APPROVED
                p.reviewed_at = datetime.now().isoformat()
                self._save()
                return p
        return None

    def reject(
        self, proposal_id: str | EvolutionProposal, reason: str = ""
    ) -> EvolutionProposal | None:
        """Reject a pending proposal."""
        wanted = self._id_of(proposal_id)
        for p in self._proposals:
            if p.id == wanted and p.status == ProposalStatus.PENDING:
                p.status = ProposalStatus.REJECTED
                p.reviewed_at = datetime.now().isoformat()
                p.changes["rejection_reason"] = reason
                self._save()
                return p
        return None

    def mark_applied(
        self, proposal_id: str | EvolutionProposal
    ) -> EvolutionProposal | None:
        """Mark an approved proposal as successfully applied."""
        wanted = self._id_of(proposal_id)
        for p in self._proposals:
            if p.id == wanted and p.status == ProposalStatus.APPROVED:
                p.status = ProposalStatus.APPLIED
                p.applied_at = datetime.now().isoformat()
                self._save()
                return p
        return None

    def mark_rolled_back(
        self, proposal_id: str | EvolutionProposal
    ) -> EvolutionProposal | None:
        """Mark an applied proposal as rolled back (reverted)."""
        wanted = self._id_of(proposal_id)
        for p in self._proposals:
            if p.id == wanted and p.status == ProposalStatus.APPLIED:
                p.status = ProposalStatus.ROLLED_BACK
                self._save()
                return p
        return None

    # --- Queries ---

    def pending_proposals(self) -> list[EvolutionProposal]:
        """Get all pending proposals awaiting approval."""
        return [p for p in self._proposals if p.status == ProposalStatus.PENDING]

    def recent_proposals(self, n: int = 10) -> list[EvolutionProposal]:
        """Get the most recent proposals regardless of status."""
        return self._proposals[-n:]

    def applied_proposals(self) -> list[EvolutionProposal]:
        """Get all successfully applied proposals."""
        return [p for p in self._proposals if p.status == ProposalStatus.APPLIED]

    def unresolved_proposals(self) -> list[EvolutionProposal]:
        """Proposals nobody has finished with: PENDING (undecided) and APPROVED
        (decided but never applied — where a crash between approve() and
        mark_applied() leaves them, invisible to a PENDING-only query)."""
        return [p for p in self._proposals
                if p.status in (ProposalStatus.PENDING, ProposalStatus.APPROVED)]

    # --- Summary ---

    def summary(self) -> str:
        """Compact summary for context injection."""
        pending = len(self.pending_proposals())
        applied = len(self.applied_proposals())
        return f"Evolution: {pending} pending, {applied} applied"

    def to_dict(self) -> list[dict]:
        return [p.to_dict() for p in self._proposals]

    def status(self) -> dict:
        return {
            "total_proposals": len(self._proposals),
            "pending": len(self.pending_proposals()),
            "applied": len(self.applied_proposals()),
            "rejected": len([p for p in self._proposals if p.status == ProposalStatus.REJECTED]),
            "path": str(self.path),
        }
