"""
EventBus — Session event tracking with dedup.

Records everything that happens (perceptions, errors, decisions, trades,
reflections) with timestamp, type, priority, and dedup by content hash.

Shares the same SQLite database as ContentStore (conscio.db).

Inspired by context-mode/src/session/db.ts — reimplemented 100% in Python.
No MCP, no Node.js, no external deps.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path

from .constants import DEFAULT_DB_PATH
from .sqlite_tuning import tune
from .timeutil import naive_utcnow

# ─── Write-contention constants ───────────────────────────────────────
# With --awake the daemon and the agent write the same conscio.db. An emit()
# landing inside the daemon's transaction window can hit a transient
# "database is locked". Retry the write (with rollback + short backoff) a
# few times rather than fail on the first lock.
_WRITE_RETRIES = 3
_WRITE_RETRY_BACKOFF_S = 0.05


def _is_transient_lock(exc: sqlite3.OperationalError) -> bool:
    """True only for lock/busy — not for real schema/disk errors."""
    msg = str(exc).lower()
    return ("locked" in msg or "busy" in msg or "in use" in msg)

# ─── Data Classes ───────────────────────────────────────────────────────

@dataclass
class Event:
    """A single event in the EventBus."""
    id: int
    type: str
    category: str
    data: dict
    priority: int
    data_hash: str
    project_dir: str
    attribution_confidence: float
    timestamp: str
    is_duplicate: bool = False
    duplicates_suppressed: int = 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "category": self.category,
            "data": self.data,
            "priority": self.priority,
            "data_hash": self.data_hash,
            "project_dir": self.project_dir,
            "attribution_confidence": self.attribution_confidence,
            "timestamp": self.timestamp,
            "is_duplicate": self.is_duplicate,
            "duplicates_suppressed": self.duplicates_suppressed,
        }


# ─── Constants ──────────────────────────────────────────────────────────

# NOTE: The canonical event types are below.  Old plan documents may
# reference deprecated names (e.g. ``perceive`` → ``perception``,
# ``act`` → ``act:result``, ``learn`` → ``tool_call``, ``propose`` →
# ``proposal:audited``, ``ship`` / ``milestone`` → ``system``).
# Always use ``VALID_TYPES`` as the single source of truth.

VALID_TYPES = {
 "tool_call", "reflection", "trade", "error", "anomaly",
 "decision", "perception", "goal_created", "goal_expired",
 "evolution_proposed", "system", "consciousness", "session",
 "coherence:dissonance",  # v0.6: passive low-coherence signal (advisory)
 "awake:changed",         # v1.5: Awake Mode (R9) toggled — auditable autonomy gate
 "workspace:changed",     # v1.5: active workspace root changed (env awareness)
 "structure:changed",     # v1.8: ingested structure drifted (graph rebuilt/moved)
 "consent:request",        # v3.4.2: workspace requests structural consent (interactive)
 "consent:granted",        # v3.4.2: user granted consent for a workspace
 "consent:revoked",        # v3.4.2: user revoked consent for a workspace
 "proposal:audited",      # v2.0: MCP propose_* audited proposal (advisory)
 "host:event",            # v2.0: raw host event recorded via MCP note()
 "act:result",            # v2.0.1: host-executed action outcome (report_result)
 "reflection_gate",       # v2.13: adaptive reflection gate decision
 "adr:proposed",          # v3.0: ADR created with status proposed
 "adr:accepted",          # v3.0: ADR accepted
 "council:convened",      # v3.0: council session result
 "gate:vetoed",           # v3.0: gate blocked an action
 "pipeline:acceptance",   # v3.0: acceptance criteria defined
 "pipeline:verified",     # v3.0: verification loop completed
 "pipeline:compact",     # v3.0: strategic compact advisory
 "pipeline:ledger",       # v3.0: decision ledger entry
 "diagnostic:budget",     # v3.0: context budget audit
 "diagnostic:eval",       # v3.0: eval harness result
 "diagnostic:rule",       # v3.0: distilled rule
 "harness:cache",         # v3.1: prompt cache hit/miss stats
 "harness:zone",          # v3.1: prompt zone composition report
 "harness:checkpoint",    # v3.1: compaction checkpoint created
 "harness:failure",       # v3.1: classified failure event
 "harness:account",       # v3.1: token account recorded
 "tool:observed",         # v3.8: DeepMiner fire-and-forget tool-call observation
 "squad:experts:convened",   # v4.4: Experts squad session result
 "squad:opositors:convened", # v4.4: Opositors squad session result
 }

VALID_CATEGORIES = {"system", "trading", "consciousness", "external", "session"}

# Priority scale: 0 = critical (life-threatening/error), 10 = trivial
PRIORITY_CRITICAL = 0
PRIORITY_HIGH = 2
PRIORITY_NORMAL = 5
PRIORITY_LOW = 8
PRIORITY_TRIVIAL = 10

# Dedup window: don't emit the same event within N seconds
DEDUP_WINDOW_SECONDS = 60


# ─── EventBus ───────────────────────────────────────────────────────────

class EventBus:
    """
    Session event tracking with dedup by content hash.

    Events are recorded with timestamps, types, priorities, and
    JSON payloads. A duplicate (same type + data hash) within the dedup
    window is not stored at all; the surviving row counts it in
    `duplicates_suppressed`, so a suppressed event is still visible as a
    number even though its row was never written.
    """

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = Path(db_path) if db_path else DEFAULT_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        # BUG-47: SQLite objects are bound to the thread that created them.
        # allow cross-thread use and serialize writes with a lock so
        # concurrent emit() calls don't corrupt the WAL.
        self._lock = threading.Lock()
        self.db = sqlite3.connect(str(self.db_path),
                                   check_same_thread=False)
        tune(self.db, foreign_keys=True)
        self.db.row_factory = sqlite3.Row

        self._init_schema()

    # ─── Schema ──────────────────────────────────────────────────────

    def _init_schema(self) -> None:
        """Initialize events table and indexes."""
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                category TEXT NOT NULL,
                data TEXT NOT NULL DEFAULT '{}',
                priority INTEGER NOT NULL DEFAULT 5,
                data_hash TEXT NOT NULL,
                project_dir TEXT DEFAULT '',
                attribution_confidence REAL DEFAULT 0.0,
                timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                is_duplicate INTEGER NOT NULL DEFAULT 0,
                duplicates_suppressed INTEGER NOT NULL DEFAULT 0
            );

            CREATE INDEX IF NOT EXISTS idx_events_type ON events(type);
            CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
            CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
            CREATE INDEX IF NOT EXISTS idx_events_priority ON events(priority);
            CREATE INDEX IF NOT EXISTS idx_events_hash ON events(data_hash);
        """)
        try:                         # databases created before v3.9.4
            self.db.execute("ALTER TABLE events ADD COLUMN"
                            " duplicates_suppressed INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass                     # already present
        self.db.commit()

    # ─── Emit ────────────────────────────────────────────────────────

    def emit(
        self,
        type: str,
        category: str,
        data: dict,
        priority: int = PRIORITY_NORMAL,
        project_dir: str = "",
        attribution_confidence: float = 0.0,
    ) -> int:
        """
        Emit an event. Returns event ID.

        Dedup: if an event with the same type + data_hash exists within
        the dedup window (60s by default), nothing is inserted — the existing
        row's `duplicates_suppressed` goes up by one and its ID comes back.
        Nothing is flagged `is_duplicate`: that marks a row for compact() to
        delete, and the row here is the one being kept.

        Args:
            type: Event type (one of VALID_TYPES)
            category: Event category (one of VALID_CATEGORIES)
            data: JSON-serializable payload
            priority: 0=critical, 10=trivial
            project_dir: Project attribution path
            attribution_confidence: 0.0-1.0 confidence

        Returns:
            Event ID (new or existing if duplicate)
        """
        if type not in VALID_TYPES:
            raise ValueError(f"Invalid event type '{type}'. Must be one of: {VALID_TYPES}")
        if category not in VALID_CATEGORIES:
            raise ValueError(f"Invalid event category '{category}'. Must be one of: {VALID_CATEGORIES}")

        data_json = json.dumps(data, sort_keys=True, default=str)
        data_hash = hashlib.sha256(data_json.encode()).hexdigest()
        timestamp = naive_utcnow().isoformat()

        # BUG-47: serialize concurrent writes across threads.
        # Field report: with --awake the daemon and the agent write the same
        # conscio.db; if this emit lands inside the daemon's transaction
        # window it can hit "database is locked" transiently. Retry the write
        # (with rollback + short backoff) instead of propagating the first
        # transient lock, so the caller does not have to "tentar 2x".
        with self._lock:
            for attempt in range(_WRITE_RETRIES):
                try:
                    return self._emit_once(type, category, data_hash,
                                           data_json, timestamp, priority,
                                           project_dir, attribution_confidence)
                except sqlite3.OperationalError as exc:
                    if not _is_transient_lock(exc):
                        raise
                    if attempt == _WRITE_RETRIES - 1:
                        # Give the other writer a moment, then surface a clear
                        # error at the top of the stack.
                        time.sleep(_WRITE_RETRY_BACKOFF_S)
                        raise
                    try:
                        self.db.rollback()          # clear a partial txn
                    except sqlite3.OperationalError:
                        pass
                    time.sleep(_WRITE_RETRY_BACKOFF_S)
            # Unreachable: every iteration either returns or, on the last
            # attempt, re-raises. Kept so a static checker sees the `int`
            # return contract is satisfied.
            raise sqlite3.OperationalError("database is locked")

    def _emit_once(
        self, type: str, category: str, data_hash: str, data_json: str,
        timestamp: str, priority: int, project_dir: str,
        attribution_confidence: float,
    ) -> int:
        """Single non-retried emit body (mutates only on success)."""
        # Check for recent duplicate (same type + hash within dedup window)
        cutoff = (naive_utcnow() - timedelta(seconds=DEDUP_WINDOW_SECONDS)).isoformat()
        existing = self.db.execute(
            """
            SELECT id FROM events
            WHERE type = ? AND data_hash = ? AND timestamp >= ?
            LIMIT 1
            """,
            (type, data_hash, cutoff),
        ).fetchone()

        if existing:
            # Suppressed, not stored: there is no second row to flag, so the
            # count goes on the row that survived. (is_duplicate is a different
            # thing — a soft-delete mark that hides a row from query() and
            # feeds compact(); flagging the survivor would hide the original.)
            self.db.execute(
                "UPDATE events SET duplicates_suppressed ="
                " duplicates_suppressed + 1 WHERE id = ?",
                (existing["id"],),
            )
            self.db.commit()
            return int(existing["id"])

        cursor = self.db.execute(
            """
            INSERT INTO events (type, category, data, priority, data_hash, project_dir, attribution_confidence, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (type, category, data_json, priority, data_hash, project_dir, attribution_confidence, timestamp),
        )
        self.db.commit()

        return int(cursor.lastrowid or 0)

    def emit_batch(self, events: list[dict]) -> list[int]:
        """
        Emit multiple events in a single transaction.

        Each dict must have: type, category, data.
        Optional: priority, project_dir, attribution_confidence.

        Returns list of event IDs.
        """
        ids = []
        for evt in events:
            eid = self.emit(
                type=evt["type"],
                category=evt["category"],
                data=evt.get("data", {}),
                priority=evt.get("priority", PRIORITY_NORMAL),
                project_dir=evt.get("project_dir", ""),
                attribution_confidence=evt.get("attribution_confidence", 0.0),
            )
            ids.append(eid)
        return ids

    # ─── Query ───────────────────────────────────────────────────────

    def query(
        self,
        type: str | None = None,
        category: str | None = None,
        since: str | None = None,
        until: str | None = None,
        priority_max: int | None = None,
        project_dir: str | None = None,
        limit: int = 50,
        offset: int = 0,
        include_duplicates: bool = False,
    ) -> list[Event]:
        """
        Query events with flexible filters.

        Args:
            type: Filter by event type
            category: Filter by category
            since: ISO timestamp — events after this time
            until: ISO timestamp — events before this time
            priority_max: Max priority value (0=most critical)
            project_dir: Filter by project directory
            limit: Max results
            offset: Skip first N results
            include_duplicates: Include events marked as duplicates

        Returns:
            List of Event objects, newest first
        """
        # SQLite treats LIMIT -1 as UNBOUNDED; a negative limit must stay bounded
        # (I-E2). Clamp to 0 (returns nothing) rather than silently dumping the table.
        limit = max(0, limit)

        conditions = []
        params: list = []

        if type:
            conditions.append("type = ?")
            params.append(type)
        if category:
            conditions.append("category = ?")
            params.append(category)
        if since:
            conditions.append("timestamp >= ?")
            params.append(since)
        if until:
            conditions.append("timestamp <= ?")
            params.append(until)
        if priority_max is not None:
            conditions.append("priority <= ?")
            params.append(priority_max)
        if project_dir:
            conditions.append("project_dir = ?")
            params.append(project_dir)
        if not include_duplicates:
            conditions.append("is_duplicate = 0")

        where = " AND ".join(conditions) if conditions else "1=1"

        rows = self.db.execute(
            f"""
            SELECT id, type, category, data, priority, data_hash,
                   project_dir, attribution_confidence, timestamp,
                   is_duplicate, duplicates_suppressed
            FROM events
            WHERE {where}
            ORDER BY timestamp DESC
            LIMIT ? OFFSET ?
            """,
            params + [limit, offset],
        ).fetchall()

        return [self._row_to_event(r) for r in rows]

    def recent_errors(self, limit: int = 10) -> list[Event]:
        """Shortcut: recent error events — feeds MetaCognition."""
        return self.query(type="error", priority_max=PRIORITY_HIGH, limit=limit)

    def recent_anomalies(self, limit: int = 10) -> list[Event]:
        """Shortcut: recent anomaly events."""
        return self.query(type="anomaly", limit=limit)

    def get(self, event_id: int) -> Event | None:
        """Get a single event by ID."""
        row = self.db.execute(
            """
            SELECT id, type, category, data, priority, data_hash,
                   project_dir, attribution_confidence, timestamp,
                   is_duplicate, duplicates_suppressed
            FROM events WHERE id = ?
            """,
            (event_id,),
        ).fetchone()

        return self._row_to_event(row) if row else None

    # ─── Summary ─────────────────────────────────────────────────────

    def summary(self, hours: int = 24) -> dict:
        """
        Activity summary for the last N hours.

        Returns counts by type, category, priority distribution,
        and error/anomaly highlights.
        """
        cutoff = (naive_utcnow() - timedelta(hours=hours)).isoformat()

        # Total count
        total = self.db.execute(
            "SELECT COUNT(*) as c FROM events WHERE timestamp >= ?",
            (cutoff,),
        ).fetchone()["c"]

        # By type
        by_type_rows = self.db.execute(
            "SELECT type, COUNT(*) as c FROM events WHERE timestamp >= ? GROUP BY type",
            (cutoff,),
        ).fetchall()
        by_type = {r["type"]: r["c"] for r in by_type_rows}

        # By category
        by_cat_rows = self.db.execute(
            "SELECT category, COUNT(*) as c FROM events WHERE timestamp >= ? GROUP BY category",
            (cutoff,),
        ).fetchall()
        by_category = {r["category"]: r["c"] for r in by_cat_rows}

        # By priority bucket
        priority_buckets = {"critical": 0, "high": 0, "normal": 0, "low": 0, "trivial": 0}
        for r in self.db.execute(
            "SELECT priority, COUNT(*) as c FROM events WHERE timestamp >= ? GROUP BY priority",
            (cutoff,),
        ).fetchall():
            p = r["priority"]
            if p <= 1:
                priority_buckets["critical"] += r["c"]
            elif p <= 3:
                priority_buckets["high"] += r["c"]
            elif p <= 6:
                priority_buckets["normal"] += r["c"]
            elif p <= 8:
                priority_buckets["low"] += r["c"]
            else:
                priority_buckets["trivial"] += r["c"]

        # Duplicate count
        dup_count = self.db.execute(
            "SELECT COUNT(*) as c FROM events WHERE timestamp >= ? AND is_duplicate = 1",
            (cutoff,),
        ).fetchone()["c"]

        # Latest errors (up to 3)
        latest_errors = self.query(type="error", limit=3, include_duplicates=False)
        error_highlights = [e.data for e in latest_errors]

        return {
            "hours": hours,
            "total_events": total,
            "duplicates_suppressed": dup_count,
            "by_type": by_type,
            "by_category": by_category,
            "priority_distribution": priority_buckets,
            "error_highlights": error_highlights,
        }

    # ─── Maintenance ─────────────────────────────────────────────────

    def compact(self, before_days: int = 30) -> int:
        """
        Compact old events.

        Strategy:
        1. Remove trivial events (priority >= 8) older than before_days
        2. Remove duplicate events older than before_days
        3. Keep all critical/high priority events

        Returns number of events removed.
        """
        cutoff = (naive_utcnow() - timedelta(days=before_days)).isoformat()

        # Count before
        before_count = self.db.execute("SELECT COUNT(*) as c FROM events").fetchone()["c"]

        # Remove trivial old events
        self.db.execute(
            "DELETE FROM events WHERE timestamp < ? AND priority >= ?",
            (cutoff, PRIORITY_LOW),
        )

        # Remove old duplicates
        self.db.execute(
            "DELETE FROM events WHERE timestamp < ? AND is_duplicate = 1",
            (cutoff,),
        )

        self.db.commit()

        after_count = self.db.execute("SELECT COUNT(*) as c FROM events").fetchone()["c"]
        return before_count - after_count

    def purge_duplicates(self, dry_run: bool = False) -> int:
        """
        Collapse exact duplicate events across all time.

        Two events are exact duplicates when they share the same
        (type, data_hash). The newest row in each group is kept; older
        copies are hard-deleted. This addresses cross-window accumulation
        that emit()'s 60s dedup window cannot catch.

        Args:
            dry_run: If True, count what would be removed without deleting.

        Returns:
            Number of rows removed (or that would be removed if dry_run).
        """
        # Newest-first within each (type, data_hash) group.
        rows = self.db.execute(
            """
            SELECT id, type, data_hash
            FROM events
            ORDER BY type, data_hash, timestamp DESC, id DESC
            """
        ).fetchall()

        seen: set[tuple[str, str]] = set()
        to_delete: list[int] = []
        for r in rows:
            key = (r["type"], r["data_hash"])
            if key in seen:
                to_delete.append(r["id"])
            else:
                seen.add(key)

        if not dry_run and to_delete:
            self.db.executemany(
                "DELETE FROM events WHERE id = ?", [(i,) for i in to_delete]
            )
            self.db.commit()

        return len(to_delete)

    def mark_duplicate(self, event_id: int) -> bool:
        """Mark an event as duplicate (soft delete)."""
        cursor = self.db.execute(
            "UPDATE events SET is_duplicate = 1 WHERE id = ?",
            (event_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    # ─── Stats ───────────────────────────────────────────────────────

    def stats(self) -> dict:
        """Return event store statistics."""
        total = self.db.execute("SELECT COUNT(*) as c FROM events").fetchone()["c"]
        duplicates = self.db.execute(
            "SELECT COUNT(*) as c FROM events WHERE is_duplicate = 1"
        ).fetchone()["c"]
        suppressed = self.db.execute(
            "SELECT COALESCE(SUM(duplicates_suppressed), 0) as c FROM events"
        ).fetchone()["c"]

        types = self.db.execute(
            "SELECT type, COUNT(*) as c FROM events GROUP BY type"
        ).fetchall()

        return {
            "total_events": total,
            "duplicates": duplicates,          # soft-deleted, awaiting compact
            "duplicates_suppressed": suppressed,   # never stored in the first place
            "unique_events": total - duplicates,
            "by_type": {r["type"]: r["c"] for r in types},
        }

    # ─── Internal ────────────────────────────────────────────────────

    def _row_to_event(self, row: sqlite3.Row) -> Event:
        """Convert a database row to an Event object."""
        data: dict = {}
        try:
            data = json.loads(row["data"]) if row["data"] else {}
        except (json.JSONDecodeError, TypeError):
            data = {"raw": row["data"]}

        return Event(
            id=row["id"],
            type=row["type"],
            category=row["category"],
            data=data,
            priority=row["priority"],
            data_hash=row["data_hash"],
            project_dir=row["project_dir"],
            attribution_confidence=row["attribution_confidence"],
            timestamp=row["timestamp"],
            is_duplicate=bool(row["is_duplicate"]),
            duplicates_suppressed=row["duplicates_suppressed"],
        )

    # ─── Lifecycle ───────────────────────────────────────────────────

    def close(self) -> None:
        """Close the database connection."""
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
