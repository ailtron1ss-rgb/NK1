# conscio/agency/tools.py
"""
ToolRegistry — the local action surface (spec section 5.4).

Local Python callables only. No network tools in core (safety rule R7);
no shell execution in this repository at all (lives in the sibling
package conscio-shell). Filesystem tools are confined to a mandatory
sandbox root.
"""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..risk import Risk  # re-exported for backward compatibility (see conscio.risk)
from .contracts import ToolResult

MAX_WRITE_BYTES = 1_000_000
MAX_READ_BYTES = 1_000_000


@dataclass
class ToolSpec:
    name: str
    fn: Callable[..., str]
    params: dict[str, dict]
    risk: Risk
    description: str
    precheck: Callable[[dict], str | None] | None = None
    approval_policy: str = "require_approval"      # v2.0.1: host-act gate


def tool_doc(name: str, description: str) -> str:
    """One line naming a tool, for a reader that must not guess what it is.

    A description is optional in a manifest, and 'deploy — ' reads as a
    sentence that got cut off rather than as a tool nobody documented.
    """
    return f"{name} — {description}" if description else name


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}

    def register(self, name: str, fn: Callable[..., str], *,
                 params: dict[str, dict], risk: Risk,
                 description: str,
                 precheck: Callable[[dict], str | None] | None = None,
                 approval_policy: str = "require_approval") -> None:
        if name in self._tools:
            raise ValueError(f"tool '{name}' already registered")
        self._tools[name] = ToolSpec(name, fn, params, risk, description,
                                     precheck, approval_policy)

    def get(self, name: str) -> ToolSpec | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return sorted(self._tools)

    _RISK_ORDER = {Risk.LOW: 0, Risk.MEDIUM: 1, Risk.HIGH: 2}

    def catalog_text(self, max_tools: int | None = None) -> str:
        """Compact tool catalog for the actor prompt.

        max_tools (from the ModelProfile, F3) caps what a small model
        sees: safest risks first, then alphabetical. None = full catalog
        in registration order (F1 behavior).
        """
        specs = list(self._tools.values())
        if max_tools is not None and len(specs) > max_tools:
            specs = sorted(specs, key=lambda s: (self._RISK_ORDER[s.risk],
                                                 s.name))[:max_tools]
        lines = []
        for spec in specs:
            args = ", ".join(f"{k}:{v.get('type', 'str')}"
                             for k, v in spec.params.items())
            lines.append(f"- {spec.name}({args}) [{spec.risk.value}] "
                         f"— {spec.description}")
        return "\n".join(lines)

    def dispatch(self, name: str, args: dict[str, Any]) -> ToolResult:
        spec = self._tools.get(name)
        if spec is None:
            return ToolResult(ok=False, output="",
                              error=f"unknown tool '{name}'")
        start = time.monotonic()
        try:
            output = spec.fn(**args)
            ok, error = True, ""
        except Exception as exc:  # tool failures must never crash the engine
            output = ""
            ok = False
            error = f"{type(exc).__name__}: {exc}"
        duration = int((time.monotonic() - start) * 1000)
        return ToolResult(ok=ok, output=str(output), error=error,
                          duration_ms=duration)


# ── built-ins ───────────────────────────────────────────────────────────

def _resolve_sandboxed(root: Path, path: str) -> Path:
    candidate = (root / path).resolve()
    root = root.resolve()
    if not candidate.is_relative_to(root):
        raise PermissionError(f"path escapes sandbox root: {path}")
    return candidate


def host_health(**_kwargs: object) -> str:
    """Read system vitals (disk, memory, load, uptime) and return a
    compact diagnostic digest. Pure read, no side effects.

    Extracted to module level so it can be imported directly and
    tested in isolation::

        from conscio.agency.tools import host_health
    """
    import os as _os
    import platform as _platform
    import shutil as _shutil

    disk = _shutil.disk_usage("/")
    disk_pct = disk.used / disk.total * 100
    mem_info: dict[str, int] = {}
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    mem_info[parts[0].rstrip(":")] = int(parts[1])
        mem_total_mb = mem_info.get("MemTotal", 0) // 1024
        mem_avail_mb = mem_info.get("MemAvailable", 0) // 1024
        mem_used_mb = mem_total_mb - mem_avail_mb
        mem_pct = (mem_used_mb / mem_total_mb * 100) if mem_total_mb else 0
    except Exception:
        mem_total_mb = mem_avail_mb = mem_used_mb = 0
        mem_pct = 0
    try:
        load1, load5, load15 = _os.getloadavg()
    except Exception:
        load1 = load5 = load15 = 0.0
    try:
        with open("/proc/uptime", "r") as f:
            uptime_s = float(f.readline().split()[0])
        uptime_h = uptime_s / 3600
    except Exception:
        uptime_h = 0.0
    digest = (
        f"disk: {disk.used // (1024**3)}G/{disk.total // (1024**3)}G "
        f"({disk_pct:.0f}%) | "
        f"mem: {mem_used_mb}M/{mem_total_mb}M ({mem_pct:.0f}%) | "
        f"load: {load1:.1f}/{load5:.1f}/{load15:.1f} | "
        f"uptime: {uptime_h:.1f}h | "
        f"python: {_platform.python_version()}"
    )
    return digest


def make_default_registry(*, sandbox_root: Path,
                          content_store: Any = None,
                          event_bus: Any = None,
                          goal_generator: Any = None,
                          world_model: Any = None) -> ToolRegistry:
    sandbox_root = Path(sandbox_root)
    sandbox_root.mkdir(parents=True, exist_ok=True)
    reg = ToolRegistry()

    def _fs_precheck(args: dict) -> str | None:
        """Deterministic sandbox check — runs before the Skeptic (F2)."""
        try:
            _resolve_sandboxed(sandbox_root, str(args.get("path", "")))
        except (PermissionError, ValueError, OSError) as exc:
            return str(exc)
        return None

    def fs_read(path: str) -> str:
        target = _resolve_sandboxed(sandbox_root, path)
        if target.stat().st_size > MAX_READ_BYTES:
            raise ValueError(f"file exceeds read size cap ({MAX_READ_BYTES}B)")
        return target.read_text(encoding="utf-8")

    def fs_write(path: str, content: str) -> str:
        if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
            raise ValueError(f"content exceeds size cap ({MAX_WRITE_BYTES}B)")
        target = _resolve_sandboxed(sandbox_root, path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"wrote {len(content)} chars to {path}"

    reg.register("fs_read", fs_read,
                 params={"path": {"type": "str", "required": True}},
                 risk=Risk.LOW, description="read a file inside the sandbox",
                 precheck=_fs_precheck)
    reg.register("fs_write", fs_write,
                 params={"path": {"type": "str", "required": True},
                         "content": {"type": "str", "required": True}},
                 risk=Risk.MEDIUM,
                 description="write a file inside the sandbox",
                 precheck=_fs_precheck)

    if content_store is not None:
        def memory_note(text: str) -> str:
            content_store.index(label="agency_note", content=text,
                                category="external")
            return "noted"
        reg.register("memory_note", memory_note,
                     params={"text": {"type": "str", "required": True}},
                     risk=Risk.LOW,
                     description="store a note in long-term memory")

    if event_bus is not None:
        def emit_event(text: str) -> str:
            event_bus.emit(type="tool_call", category="external",
                           data={"action": "emit_event", "text": text})
            return "emitted"
        reg.register("emit_event", emit_event,
                     params={"text": {"type": "str", "required": True}},
                     risk=Risk.LOW,
                     description="broadcast an event on the internal bus")

    if goal_generator is not None:
        def goal_update(action: str, goal_id: str) -> str:
            if action == "complete":
                ok = goal_generator.complete_goal(goal_id)
            else:
                ok = goal_generator.cancel_goal(goal_id)
            if not ok:
                raise ValueError(f"goal '{goal_id}' not found or not active")
            return f"goal {goal_id}: {action} ok"
        reg.register(
            "goal_update", goal_update,
            params={"action": {"type": "str", "required": True,
                               "enum": ["complete", "cancel"]},
                    "goal_id": {"type": "str", "required": True}},
            risk=Risk.MEDIUM,
            description="complete or cancel one of the agent's goals")

    if world_model is not None:
        def world_prune() -> str:
            """Run the world model's own stale-entity sweep.

            The maintenance drive raises a `prune_stale` goal whenever entities
            go stale, and that goal is auto-executable — but nothing in this
            registry could ever satisfy it, so the actor had to invent a
            filesystem action for work that is entirely in-process. It invented
            paths that do not exist, failed three times, and collapsed the
            action thread. This is the remedy the goal was always asking for.
            """
            removed = world_model.prune_stale()
            if not removed:
                # Deliberate gap: the drive flags an entity as stale after 24h,
                # while prune_stale only removes after 7 days. Say so, or the
                # actor reads an empty result as a broken tool.
                return ("nothing pruned — no entity is older than 7 days or "
                        "below the relevance floor yet")
            shown = ", ".join(removed[:10])
            more = f" (+{len(removed) - 10} more)" if len(removed) > 10 else ""
            return f"pruned {len(removed)} stale entities: {shown}{more}"

        # MEDIUM, not HIGH: HIGH never auto-executes (R6), which would leave the
        # maintenance goal exactly as unsatisfiable as it was before this tool.
        reg.register(
            "world_prune", world_prune, params={}, risk=Risk.MEDIUM,
            description="prune entities the world model has let go stale "
                        "(no update in 7 days, or relevance below the floor)")

    # ── host_health: system diagnostics for the daemon's maintenance goal ──
    # The daemon spawns "host health check — run diagnostics and record state"
    # (source="daemon") every cycle when awake and no other executable goal
    # exists. Without this tool the actor could never satisfy that goal,
    # every act() failed, and the dream's distill phase had zero successful
    # executions to crystallize into skills — freezing the cognitive loop.
    # The function itself is defined at module level (above) so it can be
    # imported directly for testing.

    reg.register("host_health", host_health, params={}, risk=Risk.LOW,
                description="read system diagnostics (disk, memory, load, "
                            "uptime) and return a compact health digest",
                approval_policy="auto")

    return reg


# ── host manifest → registry (v2.0.1 Full Act) ───────────────────────────

_RISK_BY_NAME = {"low": Risk.LOW, "medium": Risk.MEDIUM, "high": Risk.HIGH}
_POLICIES = {"auto", "require_approval", "hermes_review"}


def _host_sentinel(**kwargs: object) -> str:
    raise RuntimeError("host tool — executed by the host, never by Conscio")


def registry_from_manifest(manifest: object) -> ToolRegistry:
    """Build a host-owned ToolRegistry from a declared manifest.

    Each tool's fn is a sentinel that raises if ever dispatched — Conscio never
    dispatches a host tool. Raises ValueError on the FIRST invalid entry so the
    caller can stay all-or-nothing (no partial registration).
    """
    if not isinstance(manifest, list):
        raise ValueError("manifest must be a list of tool objects")
    reg = ToolRegistry()
    for entry in manifest:
        if not isinstance(entry, dict):
            raise ValueError("each tool entry must be an object")
        name = entry.get("name")
        if not name or not isinstance(name, str):
            raise ValueError("tool entry requires a non-empty string 'name'")
        params = entry.get("params") or {}
        if not isinstance(params, dict):
            raise ValueError(f"'{name}': params must be an object")
        risk = _RISK_BY_NAME.get(str(entry.get("risk", "high")).lower())
        if risk is None:
            raise ValueError(f"'{name}': risk must be low|medium|high")
        policy = entry.get("approval_policy") or "require_approval"
        if policy not in _POLICIES:
            raise ValueError(f"'{name}': bad approval_policy '{policy}'")
        reg.register(name, _host_sentinel, params=params, risk=risk,
                     description=str(entry.get("description", "")),
                     approval_policy=policy)
    return reg
