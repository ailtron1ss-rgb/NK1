# conscio/agency/intercepter.py
"""Intercepter — safe AST evaluator for [INTERCEPT: ...] tags in LLM output.

Origin: Think-Vetor DSL concept (CromIA). Reimplemented from scratch.
License: AGPL-3.0 (pending — see docs/superpowers/specs/2026-07-06-intercepter-spec.md)
"""
from __future__ import annotations

import ast
import math
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .adapter import InferenceAdapter, InferenceResult


_TAG_PREFIX = "[INTERCEPT:"
_MAX_EXPR_LEN = 500
_MAX_DEPTH = 50


@dataclass(frozen=True)
class InterceptResult:
    text: str
    intercepted: bool
    count: int
    errors: list[str]


def _scan_tags(text: str) -> list[tuple[int, int, str]]:
    """Find all [INTERCEPT: ...] tags by bracket counting.

    Returns list of (start, end, expression) tuples.  Handles arbitrary
    nesting depth via a depth counter rather than a regex.
    """
    results: list[tuple[int, int, str]] = []
    i = 0
    while i < len(text):
        pos = text.find(_TAG_PREFIX, i)
        if pos == -1:
            break
        depth = 0
        j = pos + len(_TAG_PREFIX)
        while j < len(text):
            ch = text[j]
            if ch == "[":
                depth += 1
            elif ch == "]":
                if depth == 0:
                    expr = text[pos + len(_TAG_PREFIX) : j].strip()
                    # Include even empty expressions so process() can emit
                    # a proper [ERROR: empty expression] instead of silently
                    # passing the tag through as plain text.
                    results.append((pos, j + 1, expr))
                    break
                depth -= 1
            j += 1
        i = (j + 1) if j < len(text) else len(text)
    return results


class InterceptError(Exception):
    """Raised for any Intercepter evaluation failure."""


def _solve_linear(a: float, b: float, c: float, d: float) -> float:
    """Solve ax + b = cx + d for x. Returns x = (d - b) / (a - c)."""
    denom = a - c
    if denom == 0:
        raise ValueError("no unique solution: a == c")
    return (d - b) / (a - c)


# ── LaTeX pre-processing ──

# Patterns that indicate the expression is LaTeX, not plain Python.
# Matches \frac, \Big, etc. (with backslash) OR bare frac{ (models
# like Qwen 0.8B frequently drop the backslash).
_LATEX_MARKERS = re.compile(
    r'\\?(?:frac\s*\{|Big[l|r]?\b|big[l|r]?\b|Bigg[l|r]?\b|bigg[l|r]?\b'
    r'|left\b|right\b|cdot|times|div|sqrt\s*\{|sum|prod|int)',
    re.IGNORECASE,
)


def _latex_to_python(expr: str) -> str:
    """Convert a LaTeX math expression to a Python-evaluable string.

    Handles ``\\frac{a}{b}`` (with or without leading backslash), sizing
    commands (``\\Big``, ``\\big``, ``\\left``, ``\\right``), ``\\cdot``,
    ``\\times``, ``\\div``, implied multiplication (``9(2x-3)`` →
    ``9*(2*x-3)``), and equations (``LHS = RHS`` → ``LHS - (RHS)``).

    No external dependencies — pure regex + brace matching.
    """
    s = expr.strip()
    # Strip math delimiters
    s = s.replace('\\[', '').replace('\\]', '')
    s = s.replace('\\(', '').replace('\\)', '')
    s = s.strip('$').strip()

    # \frac{a}{b} → (a/b) — handle nested braces.
    # Accept \frac or bare frac (models often drop the backslash).
    while '\\frac' in s or re.search(r'(?<!\\)frac\s*\{', s):
        m = re.search(r'\\?frac\s*\{', s)
        if not m:
            break
        start = m.start()
        brace_start = s.index('{', m.end() - 1)
        # Find matching close brace for numerator
        depth = 0
        num_end = brace_start
        for j in range(brace_start, len(s)):
            if s[j] == '{':
                depth += 1
            elif s[j] == '}':
                depth -= 1
                if depth == 0:
                    num_end = j
                    break
        numerator = s[brace_start + 1:num_end]
        # Find denominator
        den_start = num_end + 1
        den_end = den_start
        if den_start < len(s) and s[den_start] == '{':
            depth = 0
            den_end = den_start
            for j in range(den_start, len(s)):
                if s[j] == '{':
                    depth += 1
                elif s[j] == '}':
                    depth -= 1
                    if depth == 0:
                        den_end = j
                        break
            denominator = s[den_start + 1:den_end]
        else:
            denominator = '1'
        replacement = f"(({numerator})/({denominator}))"
        s = s[:start] + replacement + s[den_end + 1:]

    # Remove sizing commands (with or without backslash)
    s = re.sub(r'\\?Big[l|r]?\b', '', s)
    s = re.sub(r'\\?big[l|r]?\b', '', s)
    s = re.sub(r'\\?Bigg[l|r]?\b', '', s)
    s = re.sub(r'\\?bigg[l|r]?\b', '', s)
    s = re.sub(r'\\?left\b', '', s)
    s = re.sub(r'\\?right\b', '', s)

    # Operators
    s = re.sub(r'\\?times\b', '*', s)
    s = re.sub(r'\\?cdot\b', '*', s)
    s = re.sub(r'\\?div\b', '/', s)

    # \sqrt{x} → sqrt(x) (with or without backslash)
    s = re.sub(r'\\?sqrt\s*\{([^{}]*)\}', r'sqrt(\1)', s)

    # Exponent: x^2 → x**2, x^{n} → x**(n)
    s = re.sub(r'([a-zA-Z0-9)])\s*\^\s*\{([^{}]*)\}', r'\1**(\2)', s)
    s = re.sub(r'([a-zA-Z0-9)])\s*\^\s*([a-zA-Z0-9])', r'\1**\2', s)

    # Implied multiplication — but NOT for multi-char function names
    s = re.sub(r'(\d)\s*\(', r'\1*(', s)        # 9( → 9*(
    s = re.sub(r'\)\s*\(', ')*(', s)             # )( → )*(
    s = re.sub(r'(\d)([a-zA-Z])', r'\1*\2', s)   # 2x → 2*x
    s = re.sub(r'(?<![a-zA-Z])([a-zA-Z])\s*\(', r'\1*(', s)  # x( → x*( not sqrt(

    # Equation: LHS = RHS → (LHS) - (RHS)
    if '=' in s and '==' not in s:
        parts = s.split('=', 1)
        s = f"({parts[0]}) - ({parts[1]})"

    # Convert remaining braces to parens
    s = s.replace('{', '(').replace('}', ')')

    return s


def _fix_implied_mult(expr: str) -> str:
    """Fix implied multiplication in plain (non-LaTeX) expressions.

    Applies only the multiplication rules (no \frac, no sizing commands)
    to rescue expressions like ``2x + 3`` that models send without
    LaTeX markers.
    """
    s = expr.strip()
    # Exponent: x^2 → x**2
    s = re.sub(r'([a-zA-Z0-9)])\s*\^\s*\{([^{}]*)\}', r'\1**(\2)', s)
    s = re.sub(r'([a-zA-Z0-9)])\s*\^\s*([a-zA-Z0-9])', r'\1**\2', s)
    # Implied multiplication — but NOT for multi-char function names like
    # sqrt(...). Only apply x( → x*( for single-letter variables.
    s = re.sub(r'(\d)\s*\(', r'\1*(', s)        # 9( → 9*(
    s = re.sub(r'\)\s*\(', ')*(', s)             # )( → )*(
    s = re.sub(r'(\d)([a-zA-Z])', r'\1*\2', s)   # 2x → 2*x
    # Only single-letter var before ( gets *: x( → x*(  but NOT sqrt(
    s = re.sub(r'(?<![a-zA-Z])([a-zA-Z])\s*\(', r'\1*(', s)  # x( → x*(
    # Equation: LHS = RHS → (LHS) - (RHS)
    if '=' in s and '==' not in s:
        parts = s.split('=', 1)
        s = f"({parts[0]}) - ({parts[1]})"
    return s


class Intercepter:
    """Safe AST evaluator for [INTERCEPT: expr] tags."""

    _ALLOWED_OPS: dict[type, Any] = {}  # populated after class body

    _ALLOWED_FUNCS: dict[str, Callable[..., Any]] = {
        "abs": abs,
        "round": round,
        "min": min,
        "max": max,
        "sum": sum,
        "pow": pow,
        "len": len,
    }

    _DANGEROUS_MODULES = frozenset({
        "os", "posix", "subprocess", "_posixsubprocess", "socket", "http",
        "urllib", "shutil", "sys", "importlib", "ctypes", "builtins",
    })
    _ALLOWED_PARAM_TYPES = frozenset({int, float, str, bool})
    _ALLOWED_RETURN_TYPES = frozenset({int, float, str, bool})

    def __init__(self) -> None:
        self._functions: dict[str, Callable[..., Any]] = {}
        self._variables: dict[str, int | float | str | bool] = {}
        self._register_defaults()

    def _register_defaults(self) -> None:
        defaults: dict[str, Callable[..., Any]] = {
            "sqrt": math.sqrt,
            "floor": math.floor,
            "ceil": math.ceil,
            "log": math.log,
            "sin": math.sin,
            "cos": math.cos,
            "tan": math.tan,
            "solve_linear": _solve_linear,
        }
        for name, fn in defaults.items():
            self._functions[name] = fn

    def register_function(self, name: str, fn: Callable[..., Any]) -> None:
        """Register a custom function for use in [INTERCEPT: ...] tags.

        SECURITY: Only register functions you trust. This grants the LLM
        the ability to call this function. The function must:

        - Not be from a dangerous module (os, subprocess, socket, etc.)
        - Have all parameters annotated as int, float, str, or bool
        - Return int, float, str, or bool
        - Not shadow a Python builtin or an existing registered function
        """
        import inspect

        # Layer 1: name collision
        if name in self._ALLOWED_FUNCS:
            raise ValueError(f"name '{name}' shadows a builtin")
        if name in self._functions:
            raise ValueError(f"name '{name}' already registered")

        # Layer 2: module blocklist (check BEFORE annotations — dangerous
        # modules must be rejected regardless of signature)
        mod = getattr(fn, "__module__", "") or ""
        if mod.split(".")[0] in self._DANGEROUS_MODULES:
            raise ValueError(
                f"Cannot register function from dangerous module '{mod}'."
            )

        # Layer 3: type annotation check
        sig = inspect.signature(fn)
        for param in sig.parameters.values():
            ann = param.annotation
            if ann is inspect.Parameter.empty:
                raise ValueError(
                    f"Parameter '{param.name}' has no type annotation. "
                    f"All parameters must be annotated as int, float, str, or bool."
                )
            if ann not in self._ALLOWED_PARAM_TYPES:
                raise ValueError(
                    f"Parameter '{param.name}' has type '{ann}', "
                    f"which is not allowed. Only int, float, str, bool."
                )

        # Layer 4: dry-run return type check
        try:
            dummy_args = {
                p.name: (0 if p.annotation in (int, float)
                         else False if p.annotation is bool else "")
                for p in sig.parameters.values()
            }
            result = fn(**dummy_args)
            if not isinstance(result, tuple(self._ALLOWED_RETURN_TYPES)):
                raise ValueError(
                    f"Function returned {type(result).__name__}, "
                    f"expected int, float, str, or bool."
                )
        except ValueError:
            raise  # re-raise our own
        except Exception:
            pass  # dry-run failure is OK (e.g. sqrt(-1) raises)

        self._functions[name] = fn

    def set_variable(self, name: str, value: float | str | bool) -> None:
        """Bind a variable for use in [INTERCEPT: ...] tags.

        Variables allow stateful expressions like [INTERCEPT: x * 2 + 1]
        where x was previously bound via set_variable('x', 42).

        Security: only primitive types (int, float, str, bool) are accepted.
        Variable names must not shadow registered functions or builtins.
        """
        if name in self._ALLOWED_FUNCS:
            raise ValueError(f"name '{name}' shadows a builtin")
        if name in self._functions:
            raise ValueError(f"name '{name}' shadows a registered function")
        if not isinstance(value, tuple(self._ALLOWED_PARAM_TYPES)):
            raise ValueError(
                f"variable value must be int, float, str, or bool, "
                f"got {type(value).__name__}"
            )
        self._variables[name] = value

    def get_variable(self, name: str) -> int | float | str | bool | None:
        """Return the value of a bound variable, or None if not bound."""
        return self._variables.get(name)

    def clear_variables(self) -> None:
        """Remove all bound variables."""
        self._variables.clear()

    # ── public API ──

    def process(self, text: str) -> InterceptResult:
        """Find all [INTERCEPT: ...] tags, evaluate, and inline results."""
        tags = _scan_tags(text)
        if not tags:
            return InterceptResult(
                text=text, intercepted=False, count=0, errors=[]
            )

        # Build the result by replacing tags from RIGHT to LEFT so that
        # earlier positions remain valid (avoid offset drift).
        result_text = text
        errors: list[str] = []
        count = 0

        for start, end, expr in reversed(tags):
            count += 1
            # original tag text, replaced positionally (right-to-left)
            try:
                value = self._eval(expr)
                replacement = f"[INTERCEPT: {expr}] -> [RESULT: {value}]"
                errors.append("")
            except InterceptError as exc:
                replacement = f"[INTERCEPT: {expr}] -> [ERROR: {exc}]"
                errors.append(str(exc))
            except Exception as exc:
                replacement = f"[INTERCEPT: {expr}] -> [ERROR: {exc}]"
                errors.append(str(exc))

            result_text = result_text[:start] + replacement + result_text[end:]

        # errors were collected in reverse order; un-reverse them
        errors.reverse()
        count = len(tags)

        return InterceptResult(
            text=result_text, intercepted=True, count=count, errors=errors
        )

    # ── AST evaluator ──

    def _eval(self, expr: str) -> Any:
        if len(expr) > _MAX_EXPR_LEN:
            raise InterceptError("expression too long")
        if not expr.strip():
            raise InterceptError("empty expression")
        self._current_expr = expr  # for richer error hints in _eval_node

        # LaTeX auto-detection: if the expression contains LaTeX markers,
        # convert to Python before parsing.
        if _LATEX_MARKERS.search(expr):
            expr = _latex_to_python(expr)

        # Pre-apply implied-mult and caret fix BEFORE ast.parse so that
        # expressions like ``2(3+4)`` (valid Python: Call) and ``2^10``
        # (valid Python: BitXor) get rewritten to ``2*(3+4)`` / ``2**10``
        # instead of being parsed as a function call / bitwise xor.
        fixed = _fix_implied_mult(expr)
        if fixed != expr:
            expr = fixed

        try:
            tree = ast.parse(expr, mode="eval")
        except SyntaxError as exc:
            raise InterceptError(f"syntax error: {exc.msg}")
        return self._eval_node(tree.body, depth=0)

    def _eval_node(self, node: ast.AST, depth: int) -> Any:
        if depth > _MAX_DEPTH:
            raise InterceptError("recursion limit exceeded")

        # Literals
        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float, bool)):
                return node.value
            raise InterceptError(
                f"unsupported constant: {type(node.value).__name__}"
            )

        # Binary ops
        if isinstance(node, ast.BinOp):
            op_type: type[Any] = type(node.op)
            if op_type not in self._ALLOWED_OPS:
                raise InterceptError(
                    f"operator {op_type.__name__} not allowed"
                )
            left = self._eval_node(node.left, depth + 1)
            right = self._eval_node(node.right, depth + 1)
            try:
                return self._ALLOWED_OPS[op_type](left, right)
            except ZeroDivisionError:
                raise InterceptError("division by zero")

        # Unary ops
        if isinstance(node, ast.UnaryOp):
            op_type = type(node.op)
            if op_type not in self._ALLOWED_OPS:
                raise InterceptError(
                    f"unary operator {op_type.__name__} not allowed"
                )
            operand = self._eval_node(node.operand, depth + 1)
            return self._ALLOWED_OPS[op_type](operand)

        # Function calls
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise InterceptError("only named functions allowed")
            fn_name = node.func.id
            if node.keywords:
                raise InterceptError("keyword arguments not supported")
            fn = self._functions.get(fn_name) or self._ALLOWED_FUNCS.get(fn_name)
            if fn is None:
                raise InterceptError(f"unknown function: {fn_name}")
            args = [self._eval_node(a, depth + 1) for a in node.args]
            try:
                return fn(*args)
            except (ValueError, TypeError) as exc:
                raise InterceptError(str(exc))

        # Comparisons
        if isinstance(node, ast.Compare):
            return self._eval_compare(node, depth)

        # Security blocks — explicit rejections
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise InterceptError("import not allowed")
        if isinstance(node, ast.Attribute):
            raise InterceptError("attribute access not allowed")
        if isinstance(node, ast.Subscript):
            raise InterceptError("subscript not allowed")
        if isinstance(node, (ast.List, ast.Tuple)):
            raise InterceptError("list/tuple literals not supported")
        if isinstance(node, ast.Dict):
            raise InterceptError("dict literals not supported")
        if isinstance(node, ast.Set):
            raise InterceptError("set literals not supported")
        if isinstance(node, ast.Name):
            var_name = node.id
            # Resolve bound variables
            if var_name in self._variables:
                return self._variables[var_name]
            # Check math constants
            if var_name in ("pi", "e", "tau", "inf"):
                return getattr(math, var_name)
            # Helpful hint for equations — suggest the MCP intercept tool
            # which has sympy-based auto-solve, or set_variable.
            _ctx = getattr(self, "_current_expr", "")
            hint = (
                "use set_variable() to bind it"
                if "=" not in _ctx
                else "equation detected — use the MCP intercept tool with "
                "solve=true (defaults on when no variables are provided) to "
                "auto-solve with sympy"
            )
            raise InterceptError(
                f"variable '{var_name}' not bound — {hint}"
            )
        if isinstance(node, ast.BoolOp):
            raise InterceptError("boolean operators not supported")
        if isinstance(node, ast.IfExp):
            raise InterceptError("conditional expressions not supported")

        raise InterceptError(f"unsupported node: {type(node).__name__}")

    def _eval_compare(self, node: ast.Compare, depth: int) -> Any:
        left = self._eval_node(node.left, depth + 1)
        result = True
        for op, comp in zip(node.ops, node.comparators):
            right = self._eval_node(comp, depth + 1)
            op_type = type(op)
            if op_type == ast.Gt:
                result = left > right
            elif op_type == ast.Lt:
                result = left < right
            elif op_type == ast.GtE:
                result = left >= right
            elif op_type == ast.LtE:
                result = left <= right
            elif op_type == ast.Eq:
                result = left == right
            elif op_type == ast.NotEq:
                result = left != right
            else:
                raise InterceptError(
                    f"comparison {op_type.__name__} not allowed"
                )
            if not result:
                return False
            left = right
        return result


# Populate _ALLOWED_OPS after class definition (refs methods of math etc.)
Intercepter._ALLOWED_OPS = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.Pow: lambda a, b: a ** b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.USub: lambda a: -a,
    ast.UAdd: lambda a: +a,
}


# ── InterceptionLoop ────────────────────────────────────────────────────

_MAX_OBSERVATION_CHARS = 2000


class InterceptionLoop:
    """Orchestrates generate→intercept→reinject up to *max_iterations*.

    Drop-in replacement for ``adapter.generate()`` — returns the same
    ``InferenceResult`` type.  When no tags are found the loop exits after a
    single generate call (the common path).
    """

    def __init__(
        self,
        adapter: InferenceAdapter,
        intercepter: Intercepter,
        max_iterations: int = 3,
        emit_fn: Callable[..., Any] | None = None,
    ) -> None:
        self.adapter = adapter
        self.intercepter = intercepter
        self.max_iterations = max_iterations
        self.emit_fn = emit_fn

    def generate(
        self,
        prompt: str,
        *,
        schema: dict | None = None,
        grammar: str | None = None,
        max_tokens: int = 512,
        temperature: float = 0.2,
        stop: list[str] | None = None,
    ) -> InferenceResult:
        observations: list[str] = []
        total_tokens_in = 0
        total_tokens_out = 0
        total_latency = 0
        intercept_result: InterceptResult | None = None

        for i in range(self.max_iterations):
            full_prompt = prompt
            if observations:
                obs_block = "\n".join(observations)
                if len(obs_block) > _MAX_OBSERVATION_CHARS:
                    obs_block = obs_block[-_MAX_OBSERVATION_CHARS:]
                full_prompt = (
                    f"{prompt}\n<observation>\n{obs_block}\n</observation>"
                )

            result = self.adapter.generate(
                full_prompt,
                schema=schema,
                grammar=grammar,
                max_tokens=max_tokens,
                temperature=temperature,
                stop=stop,
            )
            total_tokens_in += result.tokens_in
            total_tokens_out += result.tokens_out
            total_latency += result.latency_ms

            intercept_result = self.intercepter.process(result.text)

            if self.emit_fn:
                self.emit_fn(
                    type="tool_call",
                    category="external",
                    data={
                        "action": "intercept",
                        "iteration": i,
                        "count": intercept_result.count,
                        "errors": [e for e in intercept_result.errors if e],
                    },
                )

            if not intercept_result.intercepted:
                # Clean text — return immediately (common path).
                return result

            observations.append(intercept_result.text)

        # Max iterations reached — return the adapter's last result text,
        # but with cumulative metering.  We cannot reuse ``result`` directly
        # because its metering fields are per-call; build a fresh one.
        from .adapter import (
            InferenceResult,  # local import — avoid cycle at module load
        )
        return InferenceResult(
            text=intercept_result.text if intercept_result else "",
            tokens_in=total_tokens_in,
            tokens_out=total_tokens_out,
            latency_ms=total_latency,
        )

