"""
Concrete inference adapters (spec section 5.1). stdlib urllib only —
no `requests`. All defaults point at localhost: independence means the
framework runs fully local; pointing at a cloud endpoint is the
operator's choice, never a requirement.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request

from .adapter import (
    AdapterBadResponse,
    AdapterCaps,
    AdapterConnectionError,
    AdapterHTTPError,
    AdapterTimeout,
    InferenceAdapter,
    InferenceResult,
)


def _endpoint(url: str) -> str:
    """The address to name in an error, without anything secret in it.

    A DNS failure reads '[Errno -5] No address associated with hostname' and
    never says which hostname, which is the one thing the operator needs. The
    query string is dropped because some providers accept a key there, and
    these messages reach the ledger and the event bus.
    """
    return url.split("?", 1)[0]


def _post_json(url: str, payload: dict, timeout: float,
               headers: dict | None = None) -> dict:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": "application/json", **(headers or {})})
    where = _endpoint(url)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except TimeoutError as exc:
        raise AdapterTimeout(f"{where}: {exc}") from exc
    except urllib.error.HTTPError as exc:        # server responded 4xx/5xx
        raise AdapterHTTPError(
            f"{where}: HTTP {exc.code}: {exc.reason}",
            status=exc.code) from exc
    except urllib.error.URLError as exc:
        if isinstance(getattr(exc, "reason", None), TimeoutError):
            raise AdapterTimeout(f"{where}: {exc}") from exc
        raise AdapterConnectionError(f"{where}: {exc}") from exc
    except (json.JSONDecodeError, ValueError) as exc:
        raise AdapterBadResponse(f"{where}: {exc}") from exc


class OllamaAdapter(InferenceAdapter):
    def __init__(self, *, model: str,
                 base_url: str = "http://localhost:11434",
                 timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        payload = {"model": self.model, "prompt": prompt, "stream": False,
                   "options": {"temperature": temperature,
                               "num_predict": max_tokens}}
        if schema is not None:
            payload["format"] = "json"
        if stop:
            payload["options"]["stop"] = stop
        start = time.monotonic()
        data = _post_json(f"{self.base_url}/api/generate", payload,
                          self.timeout)
        return InferenceResult(
            text=str(data.get("response", "")),
            tokens_in=int(data.get("prompt_eval_count", 0)),
            tokens_out=int(data.get("eval_count", 0)),
            latency_ms=int((time.monotonic() - start) * 1000))

    def capabilities(self) -> AdapterCaps:
        return AdapterCaps(model_name=self.model, json_mode=True,
                           grammar=False)


class LlamaCppAdapter(InferenceAdapter):
    """llama.cpp server — native GBNF grammar support (tier 1, F3)."""

    def __init__(self, *, base_url: str = "http://localhost:8080",
                 timeout: float = 120.0, model_name: str = "llama.cpp"):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.model_name = model_name

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        payload = {"prompt": prompt, "n_predict": max_tokens,
                   "temperature": temperature}
        if grammar is not None:
            payload["grammar"] = grammar
        if stop:
            payload["stop"] = stop
        start = time.monotonic()
        data = _post_json(f"{self.base_url}/completion", payload, self.timeout)
        return InferenceResult(
            text=str(data.get("content", "")),
            tokens_in=int(data.get("tokens_evaluated", 0)),
            tokens_out=int(data.get("tokens_predicted", 0)),
            latency_ms=int((time.monotonic() - start) * 1000))

    def capabilities(self) -> AdapterCaps:
        return AdapterCaps(model_name=self.model_name, json_mode=False,
                           grammar=True)


class OpenAICompatAdapter(InferenceAdapter):
    def __init__(self, *, model: str,
                 base_url: str = "http://localhost:8000/v1",
                 api_key: str = "", timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def _response_format(self, schema) -> dict | None:
        """response_format payload for a schema (None = omit it).

        Vanilla OpenAI-compatible servers (vLLM, etc.) accept the simple
        json_object mode; LMStudioAdapter overrides this — its API wants
        json_schema or text and 400s on json_object.
        """
        return {"type": "json_object"} if schema is not None else None

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        payload = {"model": self.model,
                   "messages": [{"role": "user", "content": prompt}],
                   "max_tokens": max_tokens, "temperature": temperature}
        response_format = self._response_format(schema)
        if response_format is not None:
            payload["response_format"] = response_format
        if stop:
            payload["stop"] = stop
        headers = ({"Authorization": f"Bearer {self.api_key}"}
                   if self.api_key else {})
        start = time.monotonic()
        data = _post_json(f"{self.base_url}/chat/completions", payload,
                          self.timeout, headers)
        try:
            text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise AdapterBadResponse(f"unexpected payload: {exc}") from exc
        usage = data.get("usage", {})
        return InferenceResult(
            text=str(text),
            tokens_in=int(usage.get("prompt_tokens", 0)),
            tokens_out=int(usage.get("completion_tokens", 0)),
            latency_ms=int((time.monotonic() - start) * 1000))

    def capabilities(self) -> AdapterCaps:
        return AdapterCaps(model_name=self.model, json_mode=True,
                           grammar=False)


class LMStudioAdapter(OpenAICompatAdapter):
    """LM Studio's local OpenAI-compatible server (default port 1234).

    LM Studio speaks the OpenAI Chat Completions API, so this reuses
    OpenAICompatAdapter wholesale and only pins the default endpoint. The
    local server needs no API key. JSON mode is advertised (recent LM
    Studio honours ``response_format: json_object``); GBNF is not exposed
    over the OpenAI-compatible surface, so grammar stays off.
    """

    def __init__(self, *, model: str = "local",
                 base_url: str = "http://localhost:1234/v1",
                 api_key: str = "", timeout: float = 120.0):
        super().__init__(model=model, base_url=base_url, api_key=api_key,
                         timeout=timeout)

    def _response_format(self, schema) -> dict | None:
        # LM Studio's API rejects {"type": "json_object"} (it wants
        # "json_schema" or "text"). The gateway already instructs the model
        # to emit one JSON object and repairs minor deviations, so we leave
        # the format unconstrained — robust across LM Studio versions.
        return None


class OpenAIAdapter(OpenAICompatAdapter):
    """OpenAI's hosted API — GPT models over the official cloud endpoint.

    A thin convenience over ``OpenAICompatAdapter`` that (1) defaults ``base_url``
    to OpenAI's cloud endpoint and (2) reads ``OPENAI_API_KEY`` from the env. The
    generic adapter cannot safely auto-read that key because *its* default
    endpoint is localhost — reading an ambient OpenAI key there would leak it to a
    local server. Pinning the cloud default makes the env-key read safe (the key
    only ever travels to OpenAI). For any *other* OpenAI-compatible cloud provider
    (Groq, Together, OpenRouter, DeepSeek, Fireworks, a cloud-hosted vLLM…), use
    ``OpenAICompatAdapter`` directly with an explicit ``base_url`` + ``api_key``.

    Unlike ``LMStudioAdapter`` it keeps the parent's ``response_format`` =
    ``json_object`` — real OpenAI honours it.
    """

    def __init__(self, *, model: str = "gpt-4o",
                 base_url: str = "https://api.openai.com/v1",
                 api_key: str = "", timeout: float = 120.0):
        super().__init__(
            model=model, base_url=base_url,
            api_key=api_key or os.environ.get("OPENAI_API_KEY", ""),
            timeout=timeout)

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        if not self.api_key:
            raise AdapterConnectionError(
                "OPENAI_API_KEY not set (pass api_key= or set the env var)")
        return super().generate(prompt, schema=schema, grammar=grammar,
                                max_tokens=max_tokens, temperature=temperature,
                                stop=stop)


# ── Frontier (remote API) adapters ─────────────────────────────────────────
# These reach a remote provider over the network — the operator's deliberate
# choice, using their own key. Inference is infrastructure, not a tool an actor
# can invoke, so R7 (no network in the ToolRegistry) is unaffected: this only
# widens the InferenceAdapter carve-out from localhost to a configured frontier
# API. Cognition (the prompt) is sent to that provider; that is the point of
# integrating with Claude Code (Anthropic) and Antigravity (Gemini).


class AnthropicAdapter(InferenceAdapter):
    """Anthropic Claude — Messages API (``POST /v1/messages``).

    The inference backend behind Claude Code. stdlib urllib only. The API key
    comes from ``api_key=`` or the ``ANTHROPIC_API_KEY`` env var. Claude has no
    ``response_format`` flag, so JSON is elicited by the gateway's prompt + repair
    (same posture as LMStudioAdapter); ``json_mode`` is advertised because Claude
    honours JSON instructions reliably.
    """

    def __init__(self, *, model: str = "claude-sonnet-4-6",
                 base_url: str = "https://api.anthropic.com",
                 api_key: str = "", timeout: float = 120.0,
                 anthropic_version: str = "2023-06-01"):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.timeout = timeout
        self.anthropic_version = anthropic_version

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        if not self.api_key:
            raise AdapterConnectionError(
                "ANTHROPIC_API_KEY not set (pass api_key= or set the env var)")
        payload = {"model": self.model, "max_tokens": max_tokens,
                   "temperature": temperature,
                   "messages": [{"role": "user", "content": prompt}]}
        if stop:
            payload["stop_sequences"] = stop
        headers = {"x-api-key": self.api_key,
                   "anthropic-version": self.anthropic_version}
        start = time.monotonic()
        data = _post_json(f"{self.base_url}/v1/messages", payload,
                          self.timeout, headers)
        try:
            blocks = data["content"]
            text = "".join(b.get("text", "") for b in blocks
                           if b.get("type") == "text")
        except (KeyError, IndexError, TypeError) as exc:
            raise AdapterBadResponse(f"unexpected payload: {exc}") from exc
        usage = data.get("usage", {})
        return InferenceResult(
            text=str(text),
            tokens_in=int(usage.get("input_tokens", 0)),
            tokens_out=int(usage.get("output_tokens", 0)),
            latency_ms=int((time.monotonic() - start) * 1000))

    def capabilities(self) -> AdapterCaps:
        return AdapterCaps(model_name=self.model, json_mode=True, grammar=False)


class GeminiAdapter(InferenceAdapter):
    """Google Gemini — generateContent API (``POST .../models/<m>:generateContent``).

    The inference backend behind Antigravity. stdlib urllib only. The API key
    comes from ``api_key=`` or ``GOOGLE_API_KEY`` / ``GEMINI_API_KEY``. Gemini
    supports native JSON output via ``responseMimeType``, so JSON mode is
    enforced when a schema is supplied.
    """

    def __init__(self, *, model: str = "gemini-2.5-pro",
                 base_url: str = "https://generativelanguage.googleapis.com",
                 api_key: str = "", timeout: float = 120.0):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = (api_key or os.environ.get("GOOGLE_API_KEY")
                        or os.environ.get("GEMINI_API_KEY") or "")
        self.timeout = timeout

    def generate(self, prompt, *, schema=None, grammar=None, max_tokens=512,
                 temperature=0.2, stop=None) -> InferenceResult:
        if not self.api_key:
            raise AdapterConnectionError(
                "GOOGLE_API_KEY / GEMINI_API_KEY not set "
                "(pass api_key= or set the env var)")
        gen_config: dict = {"temperature": temperature,
                            "maxOutputTokens": max_tokens}
        if stop:
            gen_config["stopSequences"] = stop
        if schema is not None:
            gen_config["responseMimeType"] = "application/json"
        payload = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                   "generationConfig": gen_config}
        headers = {"x-goog-api-key": self.api_key}
        url = f"{self.base_url}/v1beta/models/{self.model}:generateContent"
        start = time.monotonic()
        data = _post_json(url, payload, self.timeout, headers)
        try:
            parts = data["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts)
        except (KeyError, IndexError, TypeError) as exc:
            raise AdapterBadResponse(f"unexpected payload: {exc}") from exc
        usage = data.get("usageMetadata", {})
        return InferenceResult(
            text=str(text),
            tokens_in=int(usage.get("promptTokenCount", 0)),
            tokens_out=int(usage.get("candidatesTokenCount", 0)),
            latency_ms=int((time.monotonic() - start) * 1000))

    def capabilities(self) -> AdapterCaps:
        return AdapterCaps(model_name=self.model, json_mode=True, grammar=False)
