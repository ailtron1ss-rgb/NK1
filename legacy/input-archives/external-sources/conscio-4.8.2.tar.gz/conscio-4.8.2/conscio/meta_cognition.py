"""
Meta-Cognition — Self-assessment and blind spot detection.

The agent's ability to think about its own thinking:
- Track confidence scores per task type
- Detect recurring failure patterns
- Identify blind spots (areas where confidence is consistently low)
- Record self-critiques after complex interactions
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from .calibration import (
    MIN_CALIBRATION_SAMPLES,
    ConfidenceValue,
    brier,
    ece,
)
from .guards import atomic_write_text, read_json_dict


class MetaCognition:
    """
    Self-assessment engine.
    
    Data structure:
    {
        "confidence_history": [
            {"timestamp": "...", "task_type": "...", "confidence": 0.0-1.0, "outcome": "success|failure|partial"}
        ],
        "blind_spots": ["area where confidence is consistently low"],
        "error_patterns": [
            {"pattern": "description", "count": N, "last_seen": "ISO timestamp"}
        ],
        "self_critiques": [
            {"timestamp": "...", "task": "...", "what_i_did": "...", "what_i_should_do": "..."}
        ]
    }
    """

    def __init__(self, storage_path: Path):
        self.path = storage_path / "meta_cognition.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data = self._load()

    def _load(self) -> dict:
        # B-011: merge over the default skeleton so a valid-but-incomplete file
        # (legacy/migrated, missing any of the four keys) can't KeyError on use.
        return read_json_dict(self.path, {
            "confidence_history": [],
            "blind_spots": [],
            "error_patterns": [],
            "self_critiques": [],
        })

    def _save(self) -> None:
        # Keep only last 100 entries per category to prevent unbounded growth
        data = self._data
        data["confidence_history"] = data["confidence_history"][-100:]
        data["self_critiques"] = data["self_critiques"][-50:]
        atomic_write_text(self.path,
                          json.dumps(data, indent=2, ensure_ascii=False))

    # --- Confidence Tracking ---

    def record_confidence(self, task_type: str, confidence: float,
                          outcome: str = "pending") -> None:
        """
        Record a confidence assessment for a task.
        
        Args:
            task_type: Category of task (e.g., "coding", "trading", "debugging")
            confidence: Self-assessed confidence (0-1)
            outcome: "success", "failure", "partial", or "pending"
        """
        self._data["confidence_history"].append({
            "timestamp": datetime.now().isoformat(),
            "task_type": task_type,
            "confidence": confidence,
            "outcome": outcome,
        })
        self._detect_blind_spots()
        self._save()

    def update_outcome(self, task_type: str, outcome: str) -> bool:
        """Resolve the most recent pending confidence record for a task type.

        Returns True when a pending record was actually resolved — #148:
        reflect() gates failure critiques on real resolution, so evidence-free
        cycles never fabricate calibration data or critiques.
        """
        for entry in reversed(self._data["confidence_history"]):
            if entry["task_type"] == task_type and entry["outcome"] == "pending":
                entry["outcome"] = outcome
                self._detect_blind_spots()
                self._save()
                return True
        return False

    def average_confidence(self, task_type: str = "") -> float:
        """Get average confidence, optionally filtered by task type.

        DESCRIPTIVE STATISTIC ONLY — not a gate input. Never feed directly
        to an authorization or safety gate without wrapping in a category.
        """
        entries = self._data["confidence_history"]
        if task_type:
            entries = [e for e in entries if e["task_type"] == task_type]
        if not entries:
            return 0.5
        return sum(e["confidence"] for e in entries) / len(entries)

    def accuracy(self, task_type: str = "") -> float:
        """Get accuracy (success rate) for completed tasks.

        DESCRIPTIVE STATISTIC ONLY — not a gate input. Never feed directly
        to an authorization or safety gate without wrapping in a category.
        """
        entries = self._resolved_entries(task_type)
        if not entries:
            return 0.5
        successes = sum(1 for e in entries if e["outcome"] == "success")
        return successes / len(entries)

    def calibration(self, task_type: str = "") -> ConfidenceValue:
        """Compute Expected Calibration Error (ECE) against ground truth.

        Returns a ConfidenceValue with category:
        - 'none' (value=None, metric=None) if binary resolved samples < MIN_CALIBRATION_SAMPLES.
        - 'measured' (metric='ece', value=ECE) if samples >= MIN_CALIBRATION_SAMPLES.

        Pending records are filtered; partial records are excluded from binary metrics.
        """
        entries = self._binary_resolved_entries(task_type)
        n = len(entries)
        if n < MIN_CALIBRATION_SAMPLES:
            return ConfidenceValue.none(samples=n)
        confidences = [e["confidence"] for e in entries]
        outcomes = [e["outcome"] == "success" for e in entries]
        err = ece(confidences, outcomes, bins=5)
        return ConfidenceValue.measured(value=err, samples=n, metric="ece")

    def calibration_score(self, task_type: str = "") -> float | None:
        """Compatibility projection: returns 1.0 - ECE, or None if insufficient data.

        Returns None when samples < MIN_CALIBRATION_SAMPLES — never fabricates 0.5.
        1.0 = perfectly calibrated (ECE = 0.0).
        """
        cv = self.calibration(task_type)
        if cv.category != "measured" or cv.value is None:
            return None
        return 1.0 - cv.value

    def brier_score(self, task_type: str = "") -> float | None:
        """Brier score over binary resolved outcomes, or None if insufficient data."""
        entries = self._binary_resolved_entries(task_type)
        if len(entries) < MIN_CALIBRATION_SAMPLES:
            return None
        confidences = [e["confidence"] for e in entries]
        outcomes = [e["outcome"] == "success" for e in entries]
        return brier(confidences, outcomes)

    def has_calibration_evidence(self, task_type: str = "") -> bool:
        """True when calibration is measured rather than unmeasured/none."""
        return len(self._binary_resolved_entries(task_type)) >= MIN_CALIBRATION_SAMPLES

    def _resolved_entries(self, task_type: str = "") -> list[dict]:
        """Confidence records whose outcome is known — pending ones prove nothing."""
        entries = [e for e in self._data["confidence_history"] if e["outcome"] != "pending"]
        if task_type:
            entries = [e for e in entries if e["task_type"] == task_type]
        return entries

    def _binary_resolved_entries(self, task_type: str = "") -> list[dict]:
        """Binary resolved confidence records (success/failure).

        Pending records are filtered; partial records are excluded from binary
        metrics (ECE and Brier).
        """
        entries = [
            e for e in self._data["confidence_history"]
            if e["outcome"] in ("success", "failure")
        ]
        if task_type:
            entries = [e for e in entries if e["task_type"] == task_type]
        return entries

    # --- Blind Spot Detection ---

    def _detect_blind_spots(self) -> None:
        """Auto-detect areas where confidence is consistently low or accuracy is poor."""
        # Group by task type
        task_entries: dict[str, list] = {}
        for e in self._data["confidence_history"]:
            task_entries.setdefault(e["task_type"], []).append(e)

        blind_spots = []
        for task, entries in task_entries.items():
            if len(entries) < 3:
                continue
            completed = [e for e in entries if e["outcome"] != "pending"]
            if len(completed) < 2:
                continue
            avg_conf = sum(e["confidence"] for e in completed) / len(completed)
            accuracy = sum(1 for e in completed if e["outcome"] == "success") / len(completed)
            # Blind spot: low confidence OR overconfident but inaccurate
            if avg_conf < 0.4 or (avg_conf > 0.7 and accuracy < 0.4):
                blind_spots.append(task)

        # Merge: keep manually-added blind spots that aren't auto-detected
        auto_detected = set(blind_spots)
        manual_blind_spots = [b for b in self._data.get("blind_spots", [])
                              if b not in auto_detected]
        self._data["blind_spots"] = blind_spots + manual_blind_spots

    def blind_spots(self) -> list[str]:
        """Blind spots as a shallow-copied list (public read — replaces the
        private meta._data scans in self_prompt/engine, same v0.6-debt kill
        as WorldModel.list_relations)."""
        return list(self._data.get("blind_spots", []))

    # --- Error Patterns ---

    def record_error(self, pattern: str) -> None:
        """Record an error pattern for tracking."""
        # Check if pattern already exists
        for ep in self._data["error_patterns"]:
            if ep["pattern"] == pattern:
                ep["count"] += 1
                ep["last_seen"] = datetime.now().isoformat()
                self._save()
                return
        # New pattern
        self._data["error_patterns"].append({
            "pattern": pattern,
            "count": 1,
            "last_seen": datetime.now().isoformat(),
        })
        self._save()

    def frequent_errors(self, min_count: int = 2) -> list[dict]:
        """Get error patterns that occur frequently."""
        return [
            ep for ep in self._data["error_patterns"]
            if ep["count"] >= min_count
        ]

    def expire_error(self, prefix: str, max_remove: int = 1) -> int:
        """
        Remove up to max_remove oldest error patterns starting with prefix.

        Used by the TrustMatrix probation cycle (v1.0): a successful probe
        forgives the oldest matching pattern so retries=0 is never an
        absorbing state.
        """
        matching = sorted(
            (ep for ep in self._data["error_patterns"]
             if ep["pattern"].startswith(prefix)),
            key=lambda ep: ep["last_seen"])
        removed = 0
        for ep in matching[:max_remove]:
            self._data["error_patterns"].remove(ep)
            removed += 1
        if removed:
            self._save()
        return removed

    # --- Self-Critique ---

    def add_critique(self, task: str, what_i_did: str, what_i_should_do: str) -> None:
        """Record a self-critique after a complex interaction."""
        self._data["self_critiques"].append({
            "timestamp": datetime.now().isoformat(),
            "task": task,
            "what_i_did": what_i_did,
            "what_i_should_do": what_i_should_do,
        })
        self._save()

    def recent_critiques(self, n: int = 5) -> list[dict]:
        """Get the most recent self-critiques."""
        return self._data["self_critiques"][-n:]

    # --- Summary for Context Injection ---

    def summary(self) -> str:
        """
        Generate a compact meta-cognition summary for context injection.
        
        Fits within the meta_cognition token budget.
        """
        parts = []
        avg = self.average_confidence()
        cal = self.calibration_score()
        cal_str = f"{cal:.0%}" if cal is not None else "none"

        parts.append(f"Confidence: {avg:.0%} | Calibration: {cal_str}")

        if self._data["blind_spots"]:
            spots = ", ".join(self._data["blind_spots"][:3])
            parts.append(f"Blind spots: {spots}")

        freq_errors = self.frequent_errors()
        if freq_errors:
            top = freq_errors[0]
            parts.append(f"Top error: {top['pattern']} ({top['count']}x)")

        return " | ".join(parts) if parts else "No self-assessment data yet."

    def to_dict(self) -> dict:
        return dict(self._data)

    def status(self) -> dict:
        return {
            "confidence_records": len(self._data["confidence_history"]),
            "blind_spots": len(self._data["blind_spots"]),
            "error_patterns": len(self._data["error_patterns"]),
            "critiques": len(self._data["self_critiques"]),
            "avg_confidence": self.average_confidence(),
            "calibration": self.calibration_score(),
            "path": str(self.path),
        }
