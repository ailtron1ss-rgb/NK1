"""
Model Registry — Maps model identifiers to context window sizes and capabilities.

This is the foundation of context-awareness: the framework MUST know
what model it's running on and how much context it has available.
"""

from __future__ import annotations

import json
import logging
import os
import re
import struct
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


class ContextMode(Enum):
    """Operating mode based on available context."""
    MINIMAL = "minimal"     # < 128k tokens
    COMPACT = "compact"     # 128k–256k tokens
    STANDARD = "standard"   # 256k+ tokens


@dataclass
class ModelInfo:
    """Information about a specific AI model."""
    name: str
    context_window: int
    mode: ContextMode
    strengths: list[str] = field(default_factory=list)
    notes: str = ""
    has_json_mode: bool = False   # backend reliably honors JSON output mode
    supports_gbnf: bool = False   # backend supports GBNF grammar constraint

    @property
    def available_context_tokens(self) -> int:
        """Effective context after overhead (system prompt, tools, etc.)."""
        # Reserve ~20% for system prompt, tools, conversation overhead
        return int(self.context_window * 0.8)

    def context_for_consciousness(self) -> int:
        """How many tokens the consciousness state is allowed to use."""
        from .context_manager import CONTEXT_BUDGET_PCT
        return int(self.available_context_tokens * CONTEXT_BUDGET_PCT)


class ModelRegistry:
    """
    Registry of known models and their context windows.
    
    Can load from the YAML config or be populated programmatically.
    Falls back to heuristic detection if the model isn't in the registry.
    """

    # Known models with their context windows
    _known_models: dict[str, ModelInfo] = {
        # Primary
        "glm-5.2": ModelInfo("glm-5.2", 1_000_000, ContextMode.STANDARD,
                             ["complex_reasoning", "coding", "analysis", "long_context"],
                             "1M ctx. MoE coding-first. Successor to glm-5.1."),
        "glm-5.1": ModelInfo("glm-5.1", 200_000, ContextMode.STANDARD,
                             ["complex_reasoning", "coding", "analysis"],
                             "Superior in complex tasks. 200k ctx."),
        "glm-5": ModelInfo("glm-5", 200_000, ContextMode.STANDARD,
                           ["complex_reasoning", "coding", "analysis"]),
        "kimi-k2.6": ModelInfo("kimi-k2.6", 256_000, ContextMode.STANDARD,
                               ["reasoning", "long_context"],
                               "Rate-limited by context usage. Use for delegation."),
        "kimi-k2": ModelInfo("kimi-k2", 256_000, ContextMode.STANDARD,
                             ["reasoning", "long_context"]),
        "minimax-m2.7": ModelInfo("minimax-m2.7", 260_000, ContextMode.STANDARD,
                                  ["long_context"],
                                  "Large ctx but weaker on complex tasks."),
        "minimax-m3": ModelInfo("minimax-m3", 1_000_000, ContextMode.STANDARD,
                                 ["long_context", "reasoning"],
                                 "1M ctx. Default runtime model."),
        "step-flash-3.7": ModelInfo("step-flash-3.7", 260_000, ContextMode.STANDARD,
                                    ["speed", "long_context"],
                                    "Fast but inconsistent on complex tasks."),
        "deepseek-v4-pro": ModelInfo("deepseek-v4-pro", 128_000, ContextMode.COMPACT,
                                     ["reasoning"],
                                     "UNSTABLE — NVIDIA build shared. Not reliable."),
        "deepseek-v4-flash": ModelInfo("deepseek-v4-flash", 128_000, ContextMode.COMPACT,
                                       ["speed"],
                                       "UNSTABLE — same NVIDIA build issue."),
        "nemotron-3-super-120b": ModelInfo("nemotron-3-super-120b", 1_000_000,
                                           ContextMode.STANDARD,
                                           ["long_context"],
                                           "1M ctx. Adapter model — HALLUCINATES easily. Use with caution."),
        "nemotron-3-ultra-253b": ModelInfo("nemotron-3-ultra-253b", 1_000_000,
                                            ContextMode.STANDARD,
                                            ["long_context"],
                                            "1M ctx. Adapter model — HALLUCINATES easily. Use with caution."),
        # Premium
        "claude-sonnet-4": ModelInfo("claude-sonnet-4", 200_000, ContextMode.STANDARD,
                                     ["complex_reasoning", "coding", "analysis"]),
        "claude-opus-4": ModelInfo("claude-opus-4", 200_000, ContextMode.STANDARD,
                                   ["complex_reasoning", "deep_analysis"],
                                   "Most capable but expensive."),
        "gpt-4o": ModelInfo("gpt-4o", 128_000, ContextMode.COMPACT,
                            ["general", "multimodal"]),
        "gemini-2.5-pro": ModelInfo("gemini-2.5-pro", 1_048_576,
                                    ContextMode.STANDARD,
                                    ["long_context", "multimodal", "reasoning"]),
        "gemini-2.5-flash": ModelInfo("gemini-2.5-flash", 1_048_576,
                                      ContextMode.STANDARD,
                                      ["speed", "long_context", "multimodal"]),
        "gemini-1.5-pro": ModelInfo("gemini-1.5-pro", 2_097_152,
                                    ContextMode.STANDARD,
                                    ["long_context", "multimodal"]),
        # Open Source
        "llama-3.1-70b": ModelInfo("llama-3.1-70b", 128_000, ContextMode.COMPACT,
                                   ["general"]),
        "qwen-2.5-72b": ModelInfo("qwen-2.5-72b", 128_000, ContextMode.COMPACT,
                                  ["multilingual", "reasoning"]),
        "mistral-large": ModelInfo("mistral-large", 128_000, ContextMode.COMPACT,
                                   ["reasoning", "coding"]),
    }

    # Aliases — common shorthand names
    _aliases: dict[str, str] = {
        "glm": "glm-5.2",
        "glm5": "glm-5.2",
        "kimi": "kimi-k2.6",
        "minimax": "minimax-m2.7",
        "minimax-m3": "minimax-m3",
        "step": "step-flash-3.7",
        "step-flash": "step-flash-3.7",
        "deepseek": "deepseek-v4-pro",
        "nemotron": "nemotron-3-super-120b",
        "nemotron-ultra": "nemotron-3-ultra-253b",
        "claude": "claude-sonnet-4",
        "sonnet": "claude-sonnet-4",
        "opus": "claude-opus-4",
        "gpt4": "gpt-4o",
        "gemini": "gemini-2.5-pro",
        "gemini-pro": "gemini-2.5-pro",
        "gemini-flash": "gemini-2.5-flash",
    }

    # Context window thresholds
    MINIMAL_THRESHOLD = 128_000
    COMPACT_THRESHOLD = 256_000

    # Model-family context defaults — ONE rule per family, never a per-version
    # catalog (Option A: the framework attends to the context window, not to an
    # exhaustive model list). Used only as a heuristic for UNKNOWN models whose
    # family has a single, stable window (every Claude model is 200k).
    _FAMILY_CONTEXT: dict[str, int] = {
        "claude-": 200_000,
    }

    # Quant/format tokens appended to a model id that do NOT change its context
    # window (fp8, GGUF quant tags, …). Stripped for lookup/heuristics only.
    _QUANT_SUFFIX_RE = re.compile(
        r'[-_:@.]?('
        r'fp8|fp16|bf16|f16|f32|'
        r'q[0-9]+(?:_[0-9a-z]+)*|iq[0-9]+(?:_[0-9a-z]+)*|'
        r'int4|int8|awq|gptq|gguf|ggml|mlx|4bit|8bit'
        r')$'
    )

    # Config file path for persistent model context overrides (stdlib JSON).
    _CONFIG_PATHS = [
        Path.home() / ".config" / "conscio" / "config.json",
        Path.home() / ".conscio" / "config.json",
    ]

    @classmethod
    def _read_config_context(cls, model_name: str) -> int | None:
        """Read context_window from the conscio JSON config file.

        Config format (JSON), nested or flat:
            {"models": {"mimo-v2.5-pro": {"context_window": 1048576}}}
            {"context_window": {"qwen3.5-0.8b": 32000}}

        Stdlib ``json`` only — no optional dependency, so the feature can never
        silently no-op for lack of a third-party package. Reached only on the
        opt-in autodetect path (see ``detect``).
        """
        # Match the exact requested name first, then the canonical form, so a
        # config keyed ``glm-5.2`` still pins a model requested as
        # ``z-ai/glm-5.2`` or ``glm-5.2-fp8``.
        candidates = [model_name]
        canon = cls._canonical_name(model_name)
        if canon != model_name:
            candidates.append(canon)
        for config_path in cls._CONFIG_PATHS:
            if not config_path.exists():
                continue
            try:
                with open(config_path) as f:
                    config = json.load(f)
            except (OSError, ValueError):
                continue
            if not isinstance(config, dict):
                continue
            # Nested: {"models": {name: {"context_window": ctx}}}
            models = config.get("models")
            if isinstance(models, dict):
                for key in candidates:
                    model_cfg = models.get(key)
                    if isinstance(model_cfg, dict):
                        ctx = model_cfg.get("context_window")
                        if isinstance(ctx, (int, float)) and ctx > 0:
                            return int(ctx)
            # Flat: {"context_window": {name: ctx}}
            ctx_map = config.get("context_window")
            if isinstance(ctx_map, dict):
                for key in candidates:
                    ctx = ctx_map.get(key)
                    if isinstance(ctx, (int, float)) and ctx > 0:
                        return int(ctx)
        return None

    @classmethod
    def detect_mode(cls, context_window: int) -> ContextMode:
        """Determine operating mode from context window size."""
        if context_window < cls.MINIMAL_THRESHOLD:
            return ContextMode.MINIMAL
        elif context_window < cls.COMPACT_THRESHOLD:
            return ContextMode.COMPACT
        else:
            return ContextMode.STANDARD

    @classmethod
    def query_context_from_endpoint(cls, base_url: str,
                                    model_name: str) -> int | None:
        """Query an OpenAI-compatible /v1/models endpoint for context_length.

        Returns the context_length if found, None otherwise.
        Works with LM Studio, vLLM, llama.cpp server, and any endpoint
        that returns context_length in the model metadata.
        """
        url = base_url.rstrip("/")
        # Try /v1/models first (OpenAI format)
        models_url = f"{url}/models"
        if not models_url.startswith("http"):
            models_url = f"http://{models_url}"

        try:
            req = urllib.request.Request(
                models_url,
                headers={"Content-Type": "application/json"},
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            # Search for the model in the response
            for model in data.get("data", []):
                if model.get("id") == model_name:
                    ctx = model.get("context_length")
                    if ctx is not None and isinstance(ctx, (int, float)) and ctx > 0:
                        return int(ctx)
            return None
        except (urllib.error.URLError, OSError, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Endpoint probe failed for {models_url}: {e}")
            return None

    # Directories where local GGUF models are commonly stored
    _GGUF_SEARCH_DIRS = [
        Path.home() / ".lmstudio" / "models",
        Path.home() / ".ollama" / "models",
        Path.home() / "models",
    ]

    @classmethod
    def query_context_from_lmstudio(cls, model_name: str) -> int | None:
        """Read active context_length from LM Studio conversation state.

        LM Studio stores the loaded model's contextLength in its conversation
        JSON files under lastUsedModel.instanceLoadTimeConfig. This returns
        the ACTIVE context window (what the user configured), not the GGUF max.

        Returns None if LM Studio state is not found or doesn't match.
        """
        lmstudio_dir = Path.home() / ".lmstudio" / "conversations"
        if not lmstudio_dir.exists():
            return None

        model_norm = cls._normalize_model_name(model_name)
        best_ctx = None
        best_ts = 0

        try:
            for conv_file in sorted(lmstudio_dir.glob("*.conversation.json"),
                                    reverse=True):
                with open(conv_file) as f:
                    data = json.load(f)

                # Check if this conversation's model matches
                lum = data.get("lastUsedModel", {})
                identifier = lum.get("identifier", "")
                if model_norm not in cls._normalize_model_name(identifier):
                    continue

                # Extract contextLength from instanceLoadTimeConfig
                ilc = lum.get("instanceLoadTimeConfig", {})
                for field in ilc.get("fields", []):
                    if field.get("key") == "llm.load.contextLength":
                        ctx = field.get("value")
                        if isinstance(ctx, (int, float)) and ctx > 0:
                            # Use the most recent conversation's value
                            ts_str = conv_file.stem.split(".")[0]
                            try:
                                ts = int(ts_str)
                            except ValueError:
                                ts = 0
                            if ts > best_ts:
                                best_ts = ts
                                best_ctx = int(ctx)
                        break

                if best_ctx:
                    break  # Found in most recent file

        except Exception as e:
            logger.debug(f"LM Studio state read failed: {e}")
            return None

        if best_ctx:
            logger.debug(f"LM Studio active context for {model_name}: {best_ctx}")
        return best_ctx

    @classmethod
    def _read_gguf_context_length(cls, gguf_path: str) -> int | None:
        """Read context_length (architectural max) from GGUF file metadata."""
        try:
            with open(gguf_path, "rb") as f:
                magic = f.read(4)
                if magic != b'GGUF':
                    return None
                _version = struct.unpack('<I', f.read(4))[0]
                _n_tensors = struct.unpack('<Q', f.read(8))[0]
                n_kv = struct.unpack('<Q', f.read(8))[0]

                # GGUF value type sizes
                _type_sizes = {
                    0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4, 6: 4, 7: 1,
                    10: 8, 11: 8, 12: 8,
                }

                for _ in range(min(n_kv, 500)):
                    key_len = struct.unpack('<Q', f.read(8))[0]
                    key = f.read(key_len).decode('utf-8', errors='replace')
                    val_type = struct.unpack('<I', f.read(4))[0]

                    if val_type == 4:  # UINT32
                        val = struct.unpack('<I', f.read(4))[0]
                    elif val_type == 10:  # UINT64
                        val = struct.unpack('<Q', f.read(8))[0]
                    elif val_type == 6:  # FLOAT32
                        val = struct.unpack('<f', f.read(4))[0]
                    elif val_type == 0:  # UINT8
                        val = struct.unpack('B', f.read(1))[0]
                    elif val_type == 1:  # INT8
                        val = struct.unpack('b', f.read(1))[0]
                    elif val_type == 2:  # UINT16
                        val = struct.unpack('<H', f.read(2))[0]
                    elif val_type == 3:  # INT16
                        val = struct.unpack('<h', f.read(2))[0]
                    elif val_type == 5:  # INT32
                        val = struct.unpack('<i', f.read(4))[0]
                    elif val_type == 7:  # BOOL
                        val = struct.unpack('?', f.read(1))[0]
                    elif val_type == 8:  # STRING
                        slen = struct.unpack('<Q', f.read(8))[0]
                        f.read(slen)  # skip string value
                        continue
                    elif val_type == 9:  # ARRAY — skip it and keep scanning
                        elem_type = struct.unpack('<I', f.read(4))[0]
                        count = struct.unpack('<Q', f.read(8))[0]
                        if elem_type == 8:  # array of strings (variable-length)
                            for _i in range(count):
                                slen = struct.unpack('<Q', f.read(8))[0]
                                f.read(slen)
                        elif elem_type in _type_sizes:
                            f.read(_type_sizes[elem_type] * count)
                        else:
                            return None  # unknown element type — cannot skip safely
                        continue
                    elif val_type == 11:  # INT64
                        val = struct.unpack('<q', f.read(8))[0]
                    elif val_type == 12:  # FLOAT64
                        val = struct.unpack('<d', f.read(8))[0]
                    else:
                        return None  # Unknown type

                    if 'context_length' in key.lower():
                        return int(val)
        except (struct.error, OSError):
            return None
        return None

    @classmethod
    def _normalize_model_name(cls, name: str) -> str:
        """Normalize model name for fuzzy matching (strip non-alnum)."""
        return re.sub(r'[^a-z0-9]', '', name.lower())

    @classmethod
    def _canonical_name(cls, name: str) -> str:
        """Strip a provider prefix and quant/format suffixes for lookup.

        ``z-ai/glm-5.2`` -> ``glm-5.2``; ``glm-5.2-fp8`` -> ``glm-5.2``;
        ``glm-5.2:q4_k_m`` -> ``glm-5.2``. The context window is a property of
        the model, not of its vendor namespace or quantization, so these tokens
        must not change resolution (Option A: context-first). Matching stays
        EXACT after this strip — never substring — so ``glm-5.2`` can never
        collapse to the shorter ``glm-5``.
        """
        n = name.strip().lower()
        if "/" in n:
            n = n.rsplit("/", 1)[-1]
        prev = None
        while prev != n and n:
            prev = n
            n = cls._QUANT_SUFFIX_RE.sub("", n).strip("-_:@. ")
        return n

    @classmethod
    def query_context_from_gguf(cls, model_name: str,
                                search_dirs: list | None = None) -> int | None:
        """Search local directories for a GGUF model and read its context_length.

        Scans ``*.gguf`` stores (LM Studio, raw downloads). Ollama keeps models as
        extensionless sha256 blobs, so it is NOT covered here — reach Ollama via its
        OpenAI-compatible endpoint (``base_url``, e.g. http://localhost:11434/v1).
        Returns the model's architectural MAX context_length (which may exceed the
        active/loaded context), or None.
        """
        dirs = search_dirs or cls._GGUF_SEARCH_DIRS
        model_norm = cls._normalize_model_name(model_name)

        for base_dir in dirs:
            if not base_dir.exists():
                continue
            for gguf in base_dir.rglob("*.gguf"):
                # Skip multimodal projector files
                if "mmproj" in gguf.name.lower():
                    continue
                file_norm = cls._normalize_model_name(gguf.stem)
                if model_norm in file_norm or file_norm.startswith(model_norm[:15]):
                    ctx = cls._read_gguf_context_length(str(gguf))
                    if ctx and ctx > 0:
                        logger.debug(f"GGUF context_length for {model_name}: {ctx} "
                                     f"(from {gguf})")
                        return ctx
        return None

    @classmethod
    def lookup(cls, model_name: str) -> ModelInfo | None:
        """
        Look up a model by name or alias.
        
        Tries exact match first, then alias, then fuzzy match.
        Returns None if the model is completely unknown.
        """
        # Normalize
        key = model_name.lower().strip()

        # Exact match
        if key in cls._known_models:
            return cls._known_models[key]

        # Alias match
        if key in cls._aliases:
            return cls._known_models[cls._aliases[key]]

        # Canonical retry: strip a provider prefix (z-ai/glm-5.2) and quant
        # suffixes (glm-5.2-fp8) and match EXACTLY on the result. Exact-only —
        # no substring/containment — so "glm-5.2" can never collapse to the
        # shorter "glm-5" (200k). Unknown variants still fall through to the
        # heuristic (128k / family default) or the endpoint probe.
        canon = cls._canonical_name(model_name)
        if canon != key:
            if canon in cls._known_models:
                return cls._known_models[canon]
            if canon in cls._aliases:
                return cls._known_models[cls._aliases[canon]]

        return None

    @staticmethod
    def _env_truthy(name: str) -> bool:
        """True if env var `name` is set to a truthy value (1/true/yes/on)."""
        return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}

    @classmethod
    def detect(cls, model_name: str, context_window: int | None = None,
               base_url: str | None = None,
               autodetect: bool = True) -> ModelInfo:
        """Resolve ModelInfo — auto-detect context by default.

        Resolution order (Option A — an explicit context/override always wins,
        the model name is only a fallback lookup key):

            1. explicit ``context_window`` argument     (programmatic override)
            2. env ``CONSCIO_CONTEXT_WINDOW``           (explicit, no I/O)
            3. config.json ``models`` override          (explicit user pin)
            4. endpoint probe of ``base_url``, if given (explicit, targeted network)
            5. known-model registry                     (curated fallback)
            6. LM Studio state -> GGUF scan             (ambient, on by default)
            7. heuristic from the model name (family default, then 128k)

        Steps 3 and 6 are ambient host-state reads gated by ``autodetect`` (on
        by default). The config override (3) is placed BEFORE the registry so a
        user pin wins even for a known model. An explicit ``base_url`` enables
        only the probe of THAT endpoint, never a ``$HOME`` scan. GGUF reports a
        model's architectural MAX, so it is consulted last and labelled as such.
        """
        info = cls.lookup(model_name)

        # 1. Explicit override takes priority.
        if context_window is not None:
            mode = cls.detect_mode(context_window)
            if info is not None:
                return ModelInfo(
                    name=model_name,
                    context_window=context_window,
                    mode=mode,
                    strengths=info.strengths,
                    notes=f"Context window overridden to {context_window}. Original: {info.context_window}.",
                )
            return ModelInfo(
                name=model_name,
                context_window=context_window,
                mode=mode,
                notes="Context window provided by user.",
            )

        # 2. Environment variable CONSCIO_CONTEXT_WINDOW (explicit, no I/O).
        env_ctx = os.environ.get("CONSCIO_CONTEXT_WINDOW")
        if env_ctx:
            try:
                ctx = int(env_ctx)
                if ctx > 0:
                    mode = cls.detect_mode(ctx)
                    strengths = info.strengths if info else []
                    notes = f"Context window from env CONSCIO_CONTEXT_WINDOW: {ctx}."
                    return ModelInfo(
                        name=model_name,
                        context_window=ctx,
                        mode=mode,
                        strengths=strengths,
                        notes=notes,
                    )
            except ValueError:
                pass

        # 3. Config-file override (explicit user pin) — wins over the registry
        #    AND the endpoint probe, so "an override always wins" holds even for
        #    a KNOWN model (Option A). Gated by autodetect because a file read is
        #    I/O; autodetect=False stays pure and deterministic. Keys match the
        #    exact name or its canonical form (see _read_config_context).
        if autodetect or cls._env_truthy("CONSCIO_AUTODETECT"):
            config_ctx = cls._read_config_context(model_name)
            if config_ctx is not None:
                mode = cls.detect_mode(config_ctx)
                return ModelInfo(
                    name=model_name,
                    context_window=config_ctx,
                    mode=mode,
                    strengths=info.strengths if info else [],
                    notes=f"Context window from config file: {config_ctx}.",
                )

        # 4. Explicit, targeted endpoint probe — only the URL the caller named.
        if base_url:
            endpoint_ctx = cls.query_context_from_endpoint(base_url, model_name)
            if endpoint_ctx is not None:
                mode = cls.detect_mode(endpoint_ctx)
                strengths = info.strengths if info else []
                notes = f"Context window auto-detected from endpoint: {endpoint_ctx}."
                if info:
                    notes += f" Original registry: {info.context_window}."
                return ModelInfo(
                    name=model_name,
                    context_window=endpoint_ctx,
                    mode=mode,
                    strengths=strengths,
                    notes=notes,
                )

        # 5. Known model (curated fallback) — reached only when no explicit
        #    override/pin/endpoint supplied a window above.
        if info is not None:
            return info

        # 6. Auto-detect ambient host-state path (default on).
        #    Only reached for UNKNOWN models not in the registry.
        #    Can be disabled with autodetect=False or CONSCIO_AUTODETECT=0.
        if autodetect or cls._env_truthy("CONSCIO_AUTODETECT"):
            # LM Studio active state (the loaded context — preferred over MAX).
            lmstudio_ctx = cls.query_context_from_lmstudio(model_name)
            if lmstudio_ctx is not None:
                mode = cls.detect_mode(lmstudio_ctx)
                strengths = info.strengths if info else []
                notes = f"Context window auto-detected from LM Studio state: {lmstudio_ctx}."
                if info:
                    notes += f" Original registry: {info.context_window}."
                return ModelInfo(
                    name=model_name,
                    context_window=lmstudio_ctx,
                    mode=mode,
                    strengths=strengths,
                    notes=notes,
                )

            # 4c. GGUF metadata scan — architectural MAX (may exceed active ctx).
            gguf_ctx = cls.query_context_from_gguf(model_name)
            if gguf_ctx is not None:
                mode = cls.detect_mode(gguf_ctx)
                strengths = info.strengths if info else []
                notes = (f"Context window from GGUF architectural max: {gguf_ctx} "
                         f"(may exceed the active/loaded context).")
                if info:
                    notes += f" Original registry: {info.context_window}."
                return ModelInfo(
                    name=model_name,
                    context_window=gguf_ctx,
                    mode=mode,
                    strengths=strengths,
                    notes=notes,
                )

        # 6. Heuristic from name.
        ctx = cls._extract_context_from_name(model_name)
        mode = cls.detect_mode(ctx)
        return ModelInfo(
            name=model_name,
            context_window=ctx,
            mode=mode,
            notes=f"Unknown model — context window inferred as {ctx} from name.",
        )

    @classmethod
    def _extract_context_from_name(cls, name: str) -> int:
        """Try to extract context window size from model name.

        Handles patterns like \"128k\", \"1m\", \"256k\", and size suffixes
        like \"-70b\", \"-550b\" (billion params — not context, but useful
        as a heuristic signal for large models).
        """
        low = cls._canonical_name(name)
        # Explicit context suffix: "128k", "1m", "256k"
        match = re.search(r'(\d+)([km])', low)
        if match:
            num = int(match.group(1))
            unit = match.group(2)
            if unit == 'k':
                return num * 1_000
            elif unit == 'm':
                return num * 1_000_000

        # Family default: an unknown model in a family with a single stable
        # window (all Claude models are 200k). One rule, not a per-version list.
        for prefix, window in cls._FAMILY_CONTEXT.items():
            if low.startswith(prefix):
                return window

        # Param-count suffix heuristic: "-70b", "-550b", "-0.8b"
        # Large param count → likely 128k+ context; small → 32k
        param_match = re.search(r'[-_](\d+(?:\.\d+)?)b$', low)
        if param_match:
            params_b = float(param_match.group(1))
            if params_b >= 100:
                return 128_000    # 100B+ → assume 128k
            elif params_b >= 30:
                return 128_000    # 30B+ → assume 128k
            else:
                return 32_000     # <30B → small context

        # Default: assume compact (128k) for safety
        return 128_000

    @classmethod
    def register(cls, name: str, context_window: int,
                 strengths: list[str] | None = None,
                 notes: str = "") -> ModelInfo:
        """Register a new model in the registry."""
        mode = cls.detect_mode(context_window)
        info = ModelInfo(
            name=name,
            context_window=context_window,
            mode=mode,
            strengths=strengths or [],
            notes=notes,
        )
        cls._known_models[name.lower()] = info
        return info

    @classmethod
    def all_models(cls) -> dict[str, ModelInfo]:
        """Return all registered models."""
        return dict(cls._known_models)


def resolve_model_name(*, cli_arg: str | None = None,
                       config_model: str | None = None) -> str:
    """Resolve the active model name without any hardcoded fallback.

    Resolution order:
        1. Explicit CLI argument
        2. Config file value
        3. ``CONSCIO_MODEL`` environment variable
        4. ``CONSCIO_CONTEXT_WINDOW`` env → ModelRegistry heuristic

    Raises ``ValueError`` if no model can be determined — the caller MUST
    specify a model via one of the above channels.
    """
    if cli_arg:
        return cli_arg
    if config_model:
        return config_model
    env = os.environ.get("CONSCIO_MODEL")
    if env:
        return env
    raise ValueError(
        "No model specified. Set CONSCIO_MODEL, configure 'model' in "
        "config.json, or pass --model on the command line."
    )
