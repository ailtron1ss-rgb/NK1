"""Emit + verify a host's MCP launch config. Per-host binding lives here:
--storage <space> + env CONSCIO_VAULT_DIR=<space>/keys. Backs up before write
(R5) and reads back to confirm (never fails silently). Prunes old backups to
the most recent MAX_BACKUPS per config file."""
from __future__ import annotations

import json
import shutil
import sys
from collections.abc import Callable
from pathlib import Path

from ..guards import safe_read_json
from . import spaces

# conscio-mcp launch flags only. "initiate" is a DAEMON flag (conscio-daemon
# --initiate); conscio-mcp rejects it, so it must never enter the MCP entry.
# "awake" stays even though the wizard never offers it: conscio-mcp accepts
# it and hand-tuned/pre-Reach entries carrying it must survive a --repair.
# v4.6.4: "relay" e "halls" SAIRAM deste mapa. Sao capacidades, e capacidade
# escrita aqui morre no proximo update do plugin, que recria o .mcp.json do
# cache a partir do asset (A3, medido em producao). Agora moram no espaco
# (conscio.mcp.capabilities); um arg numa entrada antiga continua ligando, e
# `existing_flags` o recupera como consentimento para a migracao.
_FLAG_ARG = {"act": "--enable-act", "awake": "--awake",
             "hermes": "--enable-hermes-review"}
# v4.6.4: args de CAPACIDADE que instaladores antigos emitiram. Nao sao
# re-emitidos (a capacidade mora no espaco agora), mas existing_flags os
# reconhece como CONSENTIMENTO: uma instalacao que ja tinha --enable-relay
# ou --can-create-halls no .mcp.json nao pode perder o acesso no update --
# o consentimento migra para o espaco.
_LEGACY_CAP_ARGS = {"--enable-relay": "relay",
                    "--can-create-halls": "halls"}
# a flag that is inert without another one. A hall delivers through the relay
# mailbox, so --can-create-halls alone would launch a server that advertises
# hall tools and serves none. Emit the dependency instead of the broken pair.
_FLAG_REQUIRES = {"halls": "relay"}
# args older installers emitted into the MCP entry: recovered as consents on
# --repair, but NEVER re-emitted (mcp_server_entry only knows _FLAG_ARG)
_LEGACY_ARG_FLAG = {"--initiate": "initiate"}
MAX_BACKUPS = 30
MCP_SCRIPT = "conscio-mcp"


class HostConfigError(RuntimeError):
    pass


def mcp_command() -> str:
    """The ``conscio-mcp`` to launch, absolute whenever we can prove one.

    A host is usually started from a GUI that never sourced the user's venv,
    so a bare name in the config resolves to nothing at launch — the single
    most common binding failure. Look beside the running interpreter first:
    that is *this* install, and the venv is exactly the case a PATH lookup
    gets wrong. Then the PATH of whoever ran the wizard, which covers
    ``pip install --user`` (~/.local/bin is not beside the interpreter).
    A relative hit is discarded: the host resolves it against its own cwd,
    which is worse than the bare name. The bare name remains the last
    resort, never worse than what earlier versions always emitted.

    The answer is captured at write time, so a moved or rebuilt venv leaves
    a stale path — ``conscio init --repair`` re-resolves it.
    """
    beside = Path(sys.executable).parent if sys.executable else None
    for found in (shutil.which(MCP_SCRIPT, path=str(beside)) if beside else None,
                  shutil.which(MCP_SCRIPT)):
        if found and Path(found).is_absolute():
            return found
    return MCP_SCRIPT


def mcp_server_entry(slug: str, *, flags: dict, model: str | None) -> dict:
    args = ["--storage", str(spaces.space_dir(slug))]
    if model:
        args += ["--model", model]
    on = {k for k, v in flags.items() if v}
    on |= {_FLAG_REQUIRES[k] for k in on if k in _FLAG_REQUIRES}
    for key in list(flags) + sorted(on - set(flags)):   # asked first, then deps
        if key in on and key in _FLAG_ARG:
            args.append(_FLAG_ARG[key])
            on.discard(key)
    return {"command": mcp_command(), "args": args,
            "env": {"CONSCIO_VAULT_DIR": str(spaces.vault_dir(slug))}}


def upsert_conscio_entry(o: dict, slug: str, *, flags: dict,
                         model: str | None, self_instance_id: str = "") -> None:
    """Replace the conscio MCP entry, preserving user-added env keys on the
    old entry (ours win on conflict). Args are fully owned by the flags.

    HARD BLOCK: hard-block cross-agent writes. Se ``self_instance_id`` foi
    informado e o espaço alvo já é dono de OUTRO agente (instance.json com id
    diferente), recusa HARD — um agente nunca grava sobre a instalação de outro.
    Leitura (consulta) continua permitida; escrita é bloqueada."""
    if self_instance_id:
        from . import spaces as _sp
        space_target = str(_sp.space_dir(slug))
        if _sp.space_is_cross_agent(space_target, self_instance_id):
            raise HostConfigError(
                f"cross-agent write blocked: slug '{slug}' → {space_target} "
                f"belongs to another agent (self={self_instance_id}). "
                f"Install conscio for YOUR agent; don't hijack another."
            )
    # v4.6.4: capacidades opt-in (relay/halls) moram no ESPACO, nao no arg do
    # .mcp.json que o update do plugin recria do asset. A uniao com o ja
    # persistido e deliberada: um --repair que nao mencione halls nao pode
    # desligar o que o usuario ja consentiu.
    from ..mcp import capabilities as _caps
    pedidas = {k for k, v in flags.items() if v and k in _caps.CAPABILITIES}
    pedidas |= {_FLAG_REQUIRES[k] for k in pedidas if k in _FLAG_REQUIRES}
    if pedidas:
        _caps.write_capabilities(spaces.space_dir(slug),
                                 _caps.read_capabilities(
                                     spaces.space_dir(slug)) | pedidas)
    entry = mcp_server_entry(slug, flags=flags, model=model)
    servers = o.setdefault("mcpServers", {})
    if not isinstance(servers, dict):      # corrupt shape: rebuild (backed up)
        servers = o["mcpServers"] = {}
    old = servers.get("conscio")
    if isinstance(old, dict) and isinstance(old.get("env"), dict):
        entry["env"] = {**old["env"], **entry["env"]}
    servers["conscio"] = entry


def _entry_args(config_path: Path) -> list:
    """The existing conscio entry's args list; [] on missing/corrupt anything."""
    obj = safe_read_json(Path(config_path)) or {}
    servers = obj.get("mcpServers", {})
    entry = servers.get("conscio", {}) if isinstance(servers, dict) else {}
    args = entry.get("args", []) if isinstance(entry, dict) else []
    return args if isinstance(args, list) else []


def _arg_value(config_path: Path, flag: str) -> str | None:
    args = _entry_args(config_path)
    for i, a in enumerate(args[:-1]):
        if a == flag:
            v = args[i + 1]
            return v if isinstance(v, str) and v else None
    return None


def existing_flags(config_path: Path) -> dict:
    """Inverse of mcp_server_entry: recover the consent flags from an existing
    conscio entry's args, so a --repair rewrite never silently strips a flag
    the user had granted. Includes _LEGACY_ARG_FLAG args (recovered as consent,
    never re-emitted). Missing/corrupt file or entry -> {}."""
    inv = {arg: key for key, arg in _FLAG_ARG.items()}
    inv.update(_LEGACY_ARG_FLAG)
    inv.update(_LEGACY_CAP_ARGS)
    return {inv[a]: True for a in _entry_args(config_path) if a in inv}


def existing_model(config_path: Path) -> str | None:
    """Recover --model from an existing conscio entry — a --repair without
    --model must not strip the configured model. None when absent/corrupt."""
    return _arg_value(config_path, "--model")


def existing_slug(config_path: Path) -> str | None:
    """Recover the bound space slug from an existing entry's --storage arg —
    --repair must rebind the SAME space, never mint a new one."""
    v = _arg_value(config_path, "--storage")
    return Path(v).name if v else None


def _prune_backups(path: Path) -> None:
    baks = sorted(path.parent.glob(path.name + ".bak.*"))
    for old in baks[:-MAX_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass


def backup_then_write_json(path: Path, *, mutate: Callable[[dict], None],
                           verify: Callable[[dict], bool], ts: str) -> Path | None:
    path = Path(path)
    backup = None
    obj: dict = {}
    if path.exists():
        backup = path.with_name(path.name + f".bak.{ts}")
        n = 1
        while backup.exists():             # same-second rerun: never overwrite
            backup = path.with_name(path.name + f".bak.{ts}-{n}")
            n += 1
        shutil.copy2(path, backup)
        try:
            obj = json.loads(path.read_text() or "{}")
            if not isinstance(obj, dict):
                obj = {}
        except (OSError, ValueError):
            obj = {}                       # corrupt: backup preserves the original
    mutate(obj)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True))
    tmp.replace(path)
    try:
        back = json.loads(path.read_text() or "{}")
    except (OSError, ValueError) as exc:
        raise HostConfigError(f"wrote {path} but it is unreadable: {exc}") from exc
    if not verify(back):
        raise HostConfigError(f"wrote {path} but the conscio entry is missing "
                              f"on read-back — config NOT applied")
    if backup is not None:
        _prune_backups(path)
    return backup


def write_claude_code(slug: str, *, flags: dict, model: str | None,
                      config_path: Path, ts: str) -> Path | None:
    def mutate(o: dict) -> None:
        upsert_conscio_entry(o, slug, flags=flags, model=model)
    return backup_then_write_json(
        config_path, mutate=mutate,
        verify=lambda o: "conscio" in o.get("mcpServers", {}), ts=ts)


def generic_snippet(slug: str, *, flags: dict, model: str | None) -> str:
    return json.dumps(
        {"mcpServers": {"conscio": mcp_server_entry(slug, flags=flags,
                                                    model=model)}},
        indent=2, sort_keys=True)
