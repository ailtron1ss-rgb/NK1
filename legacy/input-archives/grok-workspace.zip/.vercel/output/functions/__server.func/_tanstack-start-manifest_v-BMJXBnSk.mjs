//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BMJXBnSk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CtQ5b2C2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CtQ5b2C2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-YCbNIjDg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
