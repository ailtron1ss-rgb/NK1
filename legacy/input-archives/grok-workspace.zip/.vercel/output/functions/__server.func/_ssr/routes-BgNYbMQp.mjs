import { i as __toESM } from "../_runtime.mjs";
import { _ as updateIdentity, a as hash32, d as localSpeak, f as mse, g as softmax, h as sampleCategorical, i as createIdentity, l as lerp, m as restoreIdentity, n as clamp01, o as id, p as normalize, r as cosine, s as identityCoherence, t as clamp, u as linspace } from "./language-DCnLm5Au.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as ArrowUp, i as Moon, n as Sun, r as RotateCcw } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BgNYbMQp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var EXPR = {
	curiosity: "thinking",
	calm: "neutral",
	joy: "happy",
	anxiety: "sad",
	frustration: "angry",
	sadness: "sad",
	anger: "angry",
	protective: "focused"
};
function AvatarStage({ snap, speaking }) {
	const frame = (0, import_react.useRef)(null);
	const [live, setLive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onMsg = (ev) => {
			if (ev.origin !== window.location.origin) return;
			if (ev.data?.type === "live2d_ready") setLive(true);
			if (ev.data?.type === "live2d_error") setLive(false);
		};
		window.addEventListener("message", onMsg);
		return () => window.removeEventListener("message", onMsg);
	}, []);
	(0, import_react.useEffect)(() => {
		const win = frame.current?.contentWindow;
		if (!win || !live) return;
		win.postMessage({
			type: "kurisu_expression",
			expression: EXPR[snap.emotion.label] ?? "neutral"
		}, window.location.origin);
		win.postMessage({
			type: "kurisu_embodiment",
			speaking,
			mouthOpen: speaking ? .35 : .04,
			expressionIntensity: snap.emotion.arousal,
			gazeX: (snap.inner.pos[0] ?? 0) * .4,
			gazeY: (snap.inner.pos[1] ?? 0) * .25
		}, window.location.origin);
		win.postMessage({
			type: "kurisu_lipsync",
			value: speaking ? .45 : .02
		}, window.location.origin);
	}, [
		snap.emotion,
		snap.inner.pos,
		speaking,
		live
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-xl bg-elevated",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,color-mix(in_oklab,var(--color-ember)_18%,transparent),transparent_62%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				ref: frame,
				title: "Kurisu",
				src: "/live2d/viewer.html?profile=auto",
				className: cn("relative z-10 h-[320px] w-full border-0 md:h-[420px] transition-opacity duration-300", live ? "opacity-100" : "opacity-0"),
				allow: "autoplay"
			}),
			!live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FallbackPortrait, {
				emotion: snap.emotion.label,
				awake: snap.awake,
				speaking
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg tracking-tight text-fg",
					children: "Kurisu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted tabular-nums",
					children: [
						snap.awake ? "awake" : "sleep",
						" · ",
						snap.emotion.label,
						" · t",
						snap.tick
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-border bg-bg/70 px-2.5 py-1 text-xs uppercase tracking-wider text-muted",
					children: live ? "live2d" : "portrait"
				})]
			})
		]
	});
}
function FallbackPortrait({ emotion, awake, speaking }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-[11] flex items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 200 260",
			className: "h-full w-auto opacity-90",
			"aria-hidden": true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "100",
					cy: "248",
					rx: "54",
					ry: "10",
					fill: "color-mix(in oklab, var(--color-fg) 8%, transparent)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M70 210 C70 170 60 150 58 120 L142 120 C140 150 130 170 130 210 Z",
					fill: "#d8d4cc"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M78 128 C60 70 78 28 100 22 C128 28 144 70 122 128",
					fill: "#6a2c28"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M48 90 C40 140 52 190 70 210 L78 128 C62 110 52 96 48 90Z",
					fill: "#5a241f"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M152 90 C160 140 148 190 130 210 L122 128 C138 110 148 96 152 90Z",
					fill: "#5a241f"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "100",
					cy: "118",
					rx: "34",
					ry: "40",
					fill: "#e8cbb8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M70 96 C86 88 114 88 130 96",
					fill: "none",
					stroke: "#4a1e1a",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					transform: `translate(0 ${emotion === "anger" || emotion === "frustration" ? -8 : emotion === "sadness" || emotion === "anxiety" ? 6 : 0})`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M78 108 L92 106",
						stroke: "#2a1a16",
						strokeWidth: "2",
						strokeLinecap: "round"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M122 108 L108 106",
						stroke: "#2a1a16",
						strokeWidth: "2",
						strokeLinecap: "round"
					})]
				}),
				awake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "86",
						cy: "118",
						rx: "5",
						ry: "6",
						fill: "#2a2422"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "114",
						cy: "118",
						rx: "5",
						ry: "6",
						fill: "#2a2422"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "87.5",
						cy: "116.5",
						r: "1.2",
						fill: "#f4f1ea"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "115.5",
						cy: "116.5",
						r: "1.2",
						fill: "#f4f1ea"
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M80 118 Q86 122 92 118",
					fill: "none",
					stroke: "#2a2422",
					strokeWidth: "1.6"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M108 118 Q114 122 120 118",
					fill: "none",
					stroke: "#2a2422",
					strokeWidth: "1.6"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: `M92 138 Q100 ${138 + (speaking ? 8 : 2)} 108 138`,
					fill: "none",
					stroke: "#8a4a48",
					strokeWidth: "1.6"
				})
			]
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors transition-transform duration-150 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90",
			secondary: "border border-border bg-elevated text-fg hover:bg-surface",
			ghost: "text-muted hover:text-fg hover:bg-elevated",
			ember: "bg-ember text-fg hover:bg-ember/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var ACTIONS = [
	"respond",
	"explore",
	"verify",
	"rest",
	"reflect",
	"wait"
];
var BOOT_TRAITS = {
	curiosity: .96,
	scientificRigor: .95,
	skepticism: .86,
	warmth: .63,
	sarcasm: .68,
	guardedness: .58,
	composure: .87
};
function emptySnapshot() {
	return {
		version: 1,
		tick: 0,
		at: 0,
		awake: true,
		needs: {
			energy: .72,
			cognitiveLoad: .22,
			uncertainty: .4,
			socialNeed: .35,
			novelty: .45,
			identityCoherence: .92,
			goalPressure: .2,
			sleepPressure: .12
		},
		emotion: {
			label: "calm",
			valence: .52,
			arousal: .22,
			dominance: .55,
			tendency: "wait",
			cause: "baseline"
		},
		identity: {
			subjectId: "kurisu",
			name: "Kurisu",
			fingerprint: "boot",
			createdAt: 0,
			cycles: 0,
			traits: { ...BOOT_TRAITS },
			trust: .28
		},
		lastAction: "wait",
		lastOption: "wait",
		lastReward: 0,
		predictionError: .3,
		valueEstimate: 0,
		curiosity: .2,
		memories: [],
		beliefs: [],
		skills: [],
		goals: [],
		chat: [],
		lastDecision: null,
		inner: {
			pos: [0, 0],
			energy: .72,
			collected: 0,
			nearestResource: 1,
			nearestDanger: 1,
			waypointDist: 1,
			task: 0,
			lastReward: 0,
			resources: [
				[.4, .3],
				[-.5, .2],
				[.1, -.6]
			],
			danger: [.5, -.4],
			waypoint: [-.3, .5],
			trail: []
		},
		worldErrorEma: .4,
		replayCount: 0,
		learnSteps: 0,
		languageCalls: 0
	};
}
var STOP = /* @__PURE__ */ new Set([
	"the",
	"a",
	"an",
	"and",
	"or",
	"to",
	"of",
	"in",
	"on",
	"is",
	"it",
	"i",
	"you",
	"we",
	"я",
	"ты",
	"и",
	"в",
	"на",
	"не",
	"что",
	"это",
	"с",
	"как"
]);
function tokenize(text) {
	return text.toLowerCase().replace(/[^\p{L}\p{N}\s]+/gu, " ").split(/\s+/).filter((t) => t.length > 1 && !STOP.has(t));
}
/** Feature-hashed n-gram embedding. Real retrieval signal, not a decoration. */
function embed(text, dim = 48) {
	const v = new Float32Array(dim);
	const tokens = tokenize(text);
	if (tokens.length === 0) {
		const h = hash32(text || "empty");
		v[h % dim] = 1;
		return normalize(v);
	}
	const bump = (key, w) => {
		const h = hash32(key);
		v[h % dim] += w;
		v[(h >>> 8) % dim] += w * .5;
		v[(h >>> 16) % dim] += w * .25;
	};
	for (let i = 0; i < tokens.length; i++) {
		bump(tokens[i], 1);
		if (i + 1 < tokens.length) bump(`${tokens[i]}_${tokens[i + 1]}`, .7);
	}
	bump(`len:${Math.min(12, tokens.length)}`, .15);
	return normalize(v);
}
function mixEmbeds(parts, dim = 48) {
	const out = new Float32Array(dim);
	for (const p of parts) for (let i = 0; i < dim; i++) out[i] += (p.v[i] ?? 0) * p.w;
	return normalize(out);
}
function zeros(n) {
	return new Float32Array(n);
}
function tanhVec(v) {
	for (let i = 0; i < v.length; i++) v[i] = Math.tanh(v[i]);
}
/** Tiny GRU world model. Predicts next embedding + reward. Learns by truncated SGD. */
var WorldModel = class {
	h = zeros(32);
	Wz = randomMatrix(32, 86, .08);
	Wr = randomMatrix(32, 86, .08);
	Wh = randomMatrix(32, 86, .08);
	bz = zeros(32);
	br = zeros(32);
	bh = zeros(32);
	Wpred = randomMatrix(48, 32, .08);
	bpred = zeros(48);
	Wrew = randomMatrix(1, 32, .05);
	prev = null;
	errorEma = .4;
	steps = 0;
	concat(embed, actionOh) {
		const x = /* @__PURE__ */ new Float32Array(86);
		x.set(embed, 0);
		x.set(this.h, 48);
		x.set(actionOh, 80);
		return x;
	}
	predict(embed, actionOh) {
		const x = this.concat(embed, actionOh);
		const z = sigmoid(matVec(this.Wz, x, this.bz));
		const r = sigmoid(matVec(this.Wr, x, this.br));
		const xh = new Float32Array(x);
		for (let i = 0; i < 32; i++) xh[48 + i] = this.h[i] * r[i];
		const n = matVec(this.Wh, xh, this.bh);
		tanhVec(n);
		const hNext = /* @__PURE__ */ new Float32Array(32);
		for (let i = 0; i < 32; i++) hNext[i] = (1 - z[i]) * this.h[i] + z[i] * n[i];
		const pred = matVec(this.Wpred, hNext, this.bpred);
		tanhVec(pred);
		return {
			hNext,
			pred,
			reward: clamp(dot(this.Wrew[0], hNext), -4, 4),
			z,
			r,
			n,
			x,
			xh
		};
	}
	observe(embed, actionOh, actual, reward) {
		const { hNext, pred, reward: predR, z, n, x, xh } = this.predict(embed, actionOh);
		const err = mse(pred, actual);
		this.errorEma = this.errorEma * .94 + err * .06;
		const lr = .03;
		const dPred = /* @__PURE__ */ new Float32Array(48);
		for (let i = 0; i < 48; i++) {
			const tanhDeriv = 1 - pred[i] * pred[i];
			dPred[i] = (pred[i] - actual[i]) / 48 * tanhDeriv;
		}
		const dRew = predR - reward;
		const dh = /* @__PURE__ */ new Float32Array(32);
		for (let i = 0; i < 32; i++) {
			let g = dRew * this.Wrew[0][i] * .2;
			for (let j = 0; j < 48; j++) g += this.Wpred[j][i] * dPred[j];
			dh[i] = g;
			for (let j = 0; j < 48; j++) this.Wpred[j][i] -= lr * dPred[j] * hNext[i];
			this.Wrew[0][i] -= lr * .2 * dRew * hNext[i];
		}
		for (let j = 0; j < 48; j++) this.bpred[j] -= lr * dPred[j];
		for (let i = 0; i < 32; i++) {
			const dn = dh[i] * z[i] * (1 - n[i] * n[i]);
			this.bh[i] -= lr * dn;
			for (let j = 0; j < xh.length; j++) this.Wh[i][j] -= lr * dn * xh[j];
			const dz = dh[i] * (n[i] - this.h[i]) * z[i] * (1 - z[i]);
			this.bz[i] -= lr * .4 * dz;
			for (let j = 0; j < x.length; j++) this.Wz[i][j] -= lr * .4 * dz * x[j];
		}
		this.h = hNext;
		this.prev = new Float32Array(actual);
		this.steps += 1;
		return {
			error: err,
			predReward: predR
		};
	}
	snapshot() {
		return {
			h: Array.from(this.h),
			errorEma: this.errorEma,
			steps: this.steps,
			Wz: packMat(this.Wz),
			Wr: packMat(this.Wr),
			Wh: packMat(this.Wh),
			bz: Array.from(this.bz),
			br: Array.from(this.br),
			bh: Array.from(this.bh),
			Wpred: packMat(this.Wpred),
			bpred: Array.from(this.bpred),
			Wrew: Array.from(this.Wrew[0])
		};
	}
	restore(raw) {
		if (!raw) return;
		if (raw.h) this.h = Float32Array.from(raw.h.slice(0, 32));
		if (typeof raw.errorEma === "number") this.errorEma = raw.errorEma;
		if (typeof raw.steps === "number") this.steps = raw.steps;
		restoreMat(this.Wz, raw.Wz);
		restoreMat(this.Wr, raw.Wr);
		restoreMat(this.Wh, raw.Wh);
		restoreVec(this.bz, raw.bz);
		restoreVec(this.br, raw.br);
		restoreVec(this.bh, raw.bh);
		restoreMat(this.Wpred, raw.Wpred);
		restoreVec(this.bpred, raw.bpred);
		if (raw.Wrew) restoreVec(this.Wrew[0], raw.Wrew);
	}
};
function packMat(m) {
	return m.map((r) => Array.from(r));
}
function restoreMat(target, src) {
	if (!src || src.length !== target.length) return;
	for (let i = 0; i < target.length; i++) {
		const row = src[i];
		if (!row || row.length !== target[i].length) return;
	}
	for (let i = 0; i < target.length; i++) target[i] = Float32Array.from(src[i]);
}
function restoreVec(target, src) {
	if (!src || src.length !== target.length) return;
	target.set(src);
}
function randomMatrix(rows, cols, scale) {
	const m = [];
	for (let r = 0; r < rows; r++) {
		const row = new Float32Array(cols);
		for (let c = 0; c < cols; c++) row[c] = (Math.random() * 2 - 1) * scale;
		m.push(row);
	}
	return m;
}
function matVec(m, x, b) {
	const out = new Float32Array(m.length);
	for (let i = 0; i < m.length; i++) {
		let s = b[i] ?? 0;
		const row = m[i];
		const n = Math.min(row.length, x.length);
		for (let j = 0; j < n; j++) s += row[j] * x[j];
		out[i] = s;
	}
	return out;
}
function sigmoid(v) {
	const out = new Float32Array(v.length);
	for (let i = 0; i < v.length; i++) out[i] = 1 / (1 + Math.exp(-v[i]));
	return out;
}
function dot(a, b) {
	let s = 0;
	const n = Math.min(a.length, b.length);
	for (let i = 0; i < n; i++) s += a[i] * b[i];
	return s;
}
function actionOneHot(index) {
	const v = /* @__PURE__ */ new Float32Array(6);
	v[clamp(index, 0, 5)] = 1;
	return v;
}
function curiosityBonus(error, ema) {
	const norm = error / (Math.sqrt(ema) + 1e-4);
	return clamp01(norm / 4);
}
var EPISODIC_CAP = 280;
var SEMANTIC_CAP = 64;
var MemorySystem = class {
	episodes = [];
	semantic = [];
	store(input) {
		const rec = {
			id: id(),
			kind: input.kind,
			text: input.text.slice(0, 480),
			embedding: Array.from(embed(input.text)),
			salience: clamp01(input.salience ?? .35 + input.predictionError * .4 + Math.abs(input.reward) * .2),
			recencyTick: input.tick,
			createdAt: Date.now(),
			emotion: input.emotion,
			option: input.option,
			reward: input.reward,
			predictionError: input.predictionError,
			verified: Boolean(input.verified),
			touches: 0
		};
		if (rec.kind === "semantic" || rec.kind === "self") {
			this.semantic.unshift(rec);
			this.semantic = this.semantic.slice(0, SEMANTIC_CAP);
		} else {
			this.episodes.unshift(rec);
			this.episodes = this.episodes.slice(0, EPISODIC_CAP);
		}
		return rec;
	}
	/**
	* Multi-signal retrieval: cosine + lexical overlap + recency + salience
	* + identity/emotion match + prediction-error resonance + value conditioning.
	*/
	retrieve(query, tick, opts) {
		const qv = embed(query);
		const qTokens = new Set(tokenize(query));
		const scored = [...this.episodes, ...this.semantic].map((m) => {
			const ev = Float32Array.from(m.embedding);
			const semantic = (cosine(qv, ev) + 1) / 2;
			const lex = lexicalOverlap(qTokens, tokenize(m.text));
			const recency = clamp01(1 - (tick - m.recencyTick) / 400);
			const emo = m.emotion === opts.emotion ? .12 : 0;
			const valueMatch = 1 - Math.min(1, Math.abs(m.reward - opts.value) / 4);
			const pe = m.predictionError * .15;
			const verified = m.verified ? .08 : 0;
			return {
				m,
				score: semantic * .38 + lex * .16 + recency * .12 + m.salience * .14 + emo + valueMatch * .08 + pe + verified
			};
		});
		scored.sort((a, b) => b.score - a.score);
		const k = opts.k ?? 6;
		return scored.slice(0, k).map((s) => {
			s.m.touches += 1;
			s.m.recencyTick = tick;
			return s.m;
		});
	}
	consolidate(tick) {
		const clusters = /* @__PURE__ */ new Map();
		for (const e of this.episodes.slice(0, 80)) {
			const key = tokenize(e.text).slice(0, 3).join("_") || e.id;
			const list = clusters.get(key) ?? [];
			list.push(e);
			clusters.set(key, list);
		}
		let made = 0;
		for (const [, group] of clusters) {
			if (group.length < 3) continue;
			if (this.semantic.some((s) => s.text.includes(group[0].text.slice(0, 40)))) continue;
			const summary = summarizeGroup(group);
			this.store({
				text: summary,
				kind: "semantic",
				tick,
				emotion: group[0].emotion,
				option: group[0].option,
				reward: group.reduce((a, b) => a + b.reward, 0) / group.length,
				predictionError: group.reduce((a, b) => a + b.predictionError, 0) / group.length,
				verified: group.some((g) => g.verified),
				salience: .7
			});
			made += 1;
			if (made >= 3) break;
		}
		for (const e of this.episodes) e.salience *= .985;
		this.episodes = this.episodes.filter((e) => e.salience > .08 || e.verified || e.kind === "self");
	}
	snapshot() {
		return {
			episodes: this.episodes,
			semantic: this.semantic
		};
	}
	restore(raw) {
		this.episodes = Array.isArray(raw?.episodes) ? raw.episodes.slice(0, EPISODIC_CAP) : [];
		this.semantic = Array.isArray(raw?.semantic) ? raw.semantic.slice(0, SEMANTIC_CAP) : [];
		for (const m of [...this.episodes, ...this.semantic]) if (!m.embedding || m.embedding.length !== 48) m.embedding = Array.from(embed(m.text || ""));
	}
};
function lexicalOverlap(a, b) {
	if (a.size === 0 || b.length === 0) return 0;
	let hit = 0;
	for (const t of b) if (a.has(t)) hit += 1;
	return hit / Math.max(a.size, b.length);
}
function summarizeGroup(group) {
	const tokens = group.map((g) => g.text).flatMap((t) => tokenize(t));
	const freq = /* @__PURE__ */ new Map();
	for (const t of tokens) freq.set(t, (freq.get(t) ?? 0) + 1);
	return `pattern: ${[...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([t]) => t).join(" ")} · n=${group.length}`;
}
/** Compact C51 critic over the world-model latent. */
var DistributionalCritic = class {
	bins = linspace(-8, 8, 51);
	W = [];
	b = /* @__PURE__ */ new Float32Array(51);
	steps = 0;
	featDim;
	constructor(featDim = 32) {
		this.featDim = featDim;
		for (let i = 0; i < 51; i++) {
			const row = new Float32Array(featDim);
			for (let j = 0; j < featDim; j++) row[j] = (Math.random() * 2 - 1) * .05;
			this.W.push(row);
		}
	}
	logits(feat) {
		const out = new Array(51);
		for (let i = 0; i < 51; i++) {
			let s = this.b[i];
			const row = this.W[i];
			const n = Math.min(row.length, feat.length);
			for (let j = 0; j < n; j++) s += row[j] * feat[j];
			out[i] = s;
		}
		return out;
	}
	value(feat) {
		const p = softmax(this.logits(feat));
		let v = 0;
		for (let i = 0; i < p.length; i++) v += p[i] * this.bins[i];
		return v;
	}
	learn(feat, targetReturn, lr = .03) {
		const tz = twohot(clamp(targetReturn, this.bins[0], this.bins[this.bins.length - 1]), this.bins);
		const logits = this.logits(feat);
		const p = softmax(logits);
		for (let i = 0; i < 51; i++) {
			const g = p[i] - tz[i];
			this.b[i] -= lr * g;
			const row = this.W[i];
			const n = Math.min(row.length, feat.length);
			for (let j = 0; j < n; j++) row[j] -= lr * g * feat[j];
		}
		this.steps += 1;
	}
	snapshot() {
		return {
			W: this.W.map((r) => Array.from(r)),
			b: Array.from(this.b),
			steps: this.steps
		};
	}
	restore(raw) {
		if (!raw?.W || raw.W.length !== 51) return;
		if (raw.W[0]?.length !== this.featDim) return;
		this.W = raw.W.map((r) => Float32Array.from(r));
		if (raw.b?.length === 51) this.b = Float32Array.from(raw.b);
		if (typeof raw.steps === "number") this.steps = raw.steps;
	}
};
function twohot(x, bins) {
	const out = new Array(bins.length).fill(0);
	let below = 0;
	for (let i = 0; i < bins.length; i++) if (bins[i] <= x) below = i;
	below = Math.max(0, Math.min(bins.length - 2, below));
	const above = below + 1;
	const span = bins[above] - bins[below] || 1;
	const wa = clamp((x - bins[below]) / span, 0, 1);
	out[below] = 1 - wa;
	out[above] = wa;
	return out;
}
/** Option-critic: temporally extended options with learned values and termination. */
var OptionCritic = class {
	values = {
		respond: .1,
		explore: .15,
		verify: .12,
		rest: .05,
		reflect: .08,
		wait: .02
	};
	beta = {
		respond: .35,
		explore: .22,
		verify: .3,
		rest: .4,
		reflect: .28,
		wait: .5
	};
	current = "wait";
	stepsInOption = 0;
	maxSteps = 8;
	select(drive, temperature = .85) {
		const logits = ACTIONS.map((a) => this.values[a] * 1.4 + (drive[a] ?? 0));
		const probs = softmax(logits, temperature);
		const idx = sampleCategorical(probs, Math.random);
		this.current = ACTIONS[idx];
		this.stepsInOption = 0;
		return this.current;
	}
	maybeTerminate(advantage) {
		this.stepsInOption += 1;
		const b = this.beta[this.current];
		const p = clamp01(b + (advantage < 0 ? .2 : -.08));
		if (this.stepsInOption >= this.maxSteps) return true;
		return Math.random() < p;
	}
	learn(option, ret, terminated) {
		const v = this.values[option];
		const adv = ret - v;
		this.values[option] = v + .08 * adv;
		const targetBeta = adv < 0 ? .55 : .18;
		this.beta[option] = clamp01(this.beta[option] * .9 + targetBeta * .1);
		if (terminated) this.stepsInOption = 0;
	}
};
function driveFromState(input) {
	return {
		respond: (input.social ? 1.1 : 0) + input.socialNeed * .6,
		explore: input.novelty * .8 + (1 - input.energy) * -.2,
		verify: input.uncertainty * .9,
		rest: input.sleepPressure * .9 + (1 - input.energy) * .7,
		reflect: input.uncertainty * .35 + (input.emotionTendency === "reflect" ? .4 : 0),
		wait: input.social ? -.4 : .15
	};
}
function rnd(a, b) {
	return a + Math.random() * (b - a);
}
function dist(a, b) {
	const dx = a[0] - b[0];
	const dy = a[1] - b[1];
	return Math.hypot(dx, dy);
}
function add(a, b) {
	return [a[0] + b[0], a[1] + b[1]];
}
function nearestIndex(pos, pts) {
	let best = 0;
	let bd = Infinity;
	for (let i = 0; i < pts.length; i++) {
		const d = dist(pos, pts[i]);
		if (d < bd) {
			bd = d;
			best = i;
		}
	}
	return best;
}
/** Compact 2D lab from NeuroCore/Deepcode: collect, avoid, waypoint. */
var InnerWorld = class {
	pos = [0, 0];
	vel = [0, 0];
	energy = .72;
	resources = [
		[.4, .3],
		[-.5, .2],
		[.1, -.6]
	];
	danger = [.7, -.4];
	waypoint = [-.3, .6];
	collected = 0;
	task = 0;
	t = 0;
	lastReward = 0;
	trail = [];
	reset() {
		this.pos = [rnd(-.5, .5), rnd(-.5, .5)];
		this.vel = [0, 0];
		this.energy = .72;
		this.resources = Array.from({ length: 3 }, () => [rnd(-.85, .85), rnd(-.85, .85)]);
		this.danger = [rnd(-.85, .85), rnd(-.85, .85)];
		this.waypoint = [rnd(-.85, .85), rnd(-.85, .85)];
		this.collected = 0;
		this.task = 0;
		this.t = 0;
		this.lastReward = 0;
		this.trail = [this.pos];
	}
	observeText() {
		const nr = Math.min(...this.resources.map((r) => dist(this.pos, r)));
		const nd = dist(this.pos, this.danger);
		const wd = dist(this.pos, this.waypoint);
		return `lab ${[
			"forage",
			"avoid",
			"waypoint"
		][this.task]} pos=${this.pos[0].toFixed(2)},${this.pos[1].toFixed(2)} resource=${nr.toFixed(2)} danger=${nd.toFixed(2)} way=${wd.toFixed(2)} E=${this.energy.toFixed(2)}`;
	}
	snap() {
		return {
			pos: [...this.pos],
			energy: this.energy,
			collected: this.collected,
			nearestResource: Math.min(...this.resources.map((r) => dist(this.pos, r))),
			nearestDanger: dist(this.pos, this.danger),
			waypointDist: dist(this.pos, this.waypoint),
			task: this.task,
			lastReward: this.lastReward,
			resources: this.resources.map((r) => [...r]),
			danger: [...this.danger],
			waypoint: [...this.waypoint],
			trail: this.trail.map((p) => [...p])
		};
	}
	step(action) {
		this.t += 1;
		const dirs = [
			[0, .1],
			[0, -.1],
			[-.1, 0],
			[.1, 0]
		];
		const beforeRes = Math.min(...this.resources.map((r) => dist(this.pos, r)));
		const beforeWay = dist(this.pos, this.waypoint);
		if (action < 4) {
			this.vel = [this.vel[0] * .35 + dirs[action][0] * .65, this.vel[1] * .35 + dirs[action][1] * .65];
			this.pos = add(this.pos, this.vel);
			this.pos = [clamp(this.pos[0], -1, 1), clamp(this.pos[1], -1, 1)];
			this.energy -= .02;
		} else if (action === 4) {
			this.vel = [this.vel[0] * .2, this.vel[1] * .2];
			this.energy += .045;
		} else this.energy -= .006;
		if (this.t % 4 === 0) this.danger = [clamp(this.danger[0] + rnd(-.05, .05), -1, 1), clamp(this.danger[1] + rnd(-.05, .05), -1, 1)];
		let ig = 0;
		const ni = nearestIndex(this.pos, this.resources);
		const nn = dist(this.pos, this.resources[ni]);
		if (action === 5 && nn < .15) {
			ig = .3;
			this.energy += ig;
			this.collected += 1;
			this.resources[ni] = [rnd(-.9, .9), rnd(-.9, .9)];
		}
		const nd = dist(this.pos, this.danger);
		const dp = nd < .2 ? -.35 : nd < .35 ? -.08 : 0;
		if (this.t % 90 === 0) this.task = (this.task + 1) % 3;
		this.energy = clamp(this.energy, .05, 1);
		const progress = beforeRes - nn;
		let taskReward = 0;
		if (this.task === 0) taskReward = 2 * ig + .4 * progress;
		else if (this.task === 1) taskReward = -dp + .04 * nd;
		else {
			const wd = dist(this.pos, this.waypoint);
			taskReward = .5 * (beforeWay - wd);
			if (wd < .15) {
				taskReward += 1;
				this.waypoint = [rnd(-.9, .9), rnd(-.9, .9)];
			}
		}
		const homeo = .1 * (1 - Math.min(1, Math.abs(this.energy - .72)));
		const r = taskReward + homeo - .004 + dp;
		this.lastReward = r;
		this.trail.push([...this.pos]);
		if (this.trail.length > 80) this.trail.shift();
		return r;
	}
	restore(s) {
		if (!s) return;
		if (s.pos) this.pos = [s.pos[0], s.pos[1]];
		if (typeof s.energy === "number") this.energy = s.energy;
		if (typeof s.collected === "number") this.collected = s.collected;
		if (typeof s.task === "number") this.task = s.task;
		if (typeof s.lastReward === "number") this.lastReward = s.lastReward;
		if (s.resources?.length) this.resources = s.resources.map((r) => [r[0], r[1]]);
		if (s.danger) this.danger = [s.danger[0], s.danger[1]];
		if (s.waypoint) this.waypoint = [s.waypoint[0], s.waypoint[1]];
		if (s.trail) this.trail = s.trail.map((p) => [p[0], p[1]]);
	}
};
function moveTowards(from, to) {
	const dx = to[0] - from[0];
	const dy = to[1] - from[1];
	if (Math.abs(dx) >= Math.abs(dy)) return dx >= 0 ? 3 : 2;
	return dy >= 0 ? 0 : 1;
}
function moveAway(from, to) {
	return moveTowards(from, [from[0] - (to[0] - from[0]), from[1] - (to[1] - from[1])]);
}
function optionToInnerAction(option, snap) {
	const pos = snap.pos;
	if (option === "rest" || option === "wait" || option === "reflect") return 4;
	if (option === "verify") {
		if (snap.nearestDanger < .3) return moveAway(pos, snap.danger);
		if (snap.nearestResource < .16) return 5;
		return moveTowards(pos, snap.waypoint);
	}
	if (option === "explore") {
		if (snap.task === 0) {
			if (snap.nearestResource < .15) return 5;
			return moveTowards(pos, snap.resources.length ? snap.resources.reduce((best, r) => dist(pos, r) < dist(pos, best) ? r : best, snap.resources[0]) : snap.waypoint);
		}
		if (snap.task === 1) return moveAway(pos, snap.danger);
		if (snap.waypointDist < .15) return 5;
		return moveTowards(pos, snap.waypoint);
	}
	return Math.floor(Math.random() * 4);
}
function innerFeature(snap) {
	const f = /* @__PURE__ */ new Float32Array(32);
	f[0] = snap.pos[0];
	f[1] = snap.pos[1];
	f[2] = snap.energy;
	f[3] = clamp01(snap.nearestResource);
	f[4] = clamp01(snap.nearestDanger);
	f[5] = clamp01(snap.waypointDist);
	f[6] = snap.task / 2;
	f[7] = clamp(snap.lastReward, -2, 2) / 2;
	f[8] = clamp01(snap.collected / 8);
	if (snap.danger) {
		f[9] = snap.danger[0];
		f[10] = snap.danger[1];
	}
	if (snap.waypoint) {
		f[11] = snap.waypoint[0];
		f[12] = snap.waypoint[1];
	}
	return f;
}
/** One global workspace. Coalitions compete; winner is broadcast. Capacity 4. */
function ignite(input) {
	const candidates = [
		{
			id: "obs",
			w: .9,
			text: input.observation.slice(0, 160)
		},
		{
			id: "emotion",
			w: .35 + (input.emotion === "calm" ? 0 : .25),
			text: `emotion:${input.emotion}`
		},
		{
			id: "error",
			w: input.predictionError,
			text: `pe=${input.predictionError.toFixed(3)}`
		},
		{
			id: "energy",
			w: Math.abs(input.needs.energy - .72),
			text: `energy=${input.needs.energy.toFixed(2)}`
		},
		{
			id: "social",
			w: input.needs.socialNeed,
			text: `socialNeed=${input.needs.socialNeed.toFixed(2)}`
		},
		{
			id: "option",
			w: .4,
			text: `option=${input.option}`
		},
		{
			id: "inner",
			w: .3,
			text: input.inner.slice(0, 120)
		},
		...input.memories.slice(0, 4).map((m, i) => ({
			id: `mem:${m.id}`,
			w: .28 + m.salience * .4,
			text: m.text.slice(0, 100)
		}))
	];
	candidates.sort((a, b) => b.w - a.w);
	const selected = candidates.slice(0, 4);
	const broadcast = {};
	for (const c of selected) broadcast[c.id] = c.text;
	return {
		selected: selected.map((c) => c.id),
		broadcast
	};
}
/** Capability forge: skills are patterns that actually fired and got a return. */
var SkillForge = class {
	skills = [];
	observe(text, success, tick) {
		const tokens = tokenize(text).slice(0, 5);
		if (tokens.length < 2) return;
		const pattern = tokens.slice(0, 3).join(" ");
		const existing = this.skills.find((s) => s.pattern === pattern);
		if (existing) {
			existing.uses += 1;
			existing.success = existing.success * .85 + success * .15;
			existing.lastTick = tick;
			return;
		}
		if (this.skills.length >= 40) {
			this.skills.sort((a, b) => a.success * a.uses - b.success * b.uses);
			this.skills.shift();
		}
		this.skills.push({
			id: id(),
			name: pattern,
			pattern,
			uses: 1,
			success,
			coalition: tokens,
			lastTick: tick
		});
	}
	compose() {
		const active = this.skills.filter((s) => s.uses >= 2 && s.success > .45);
		if (active.length < 2) return null;
		active.sort((a, b) => b.success - a.success);
		const a = active[0];
		const b = active[1];
		const name = `${a.name} + ${b.name}`;
		if (this.skills.some((s) => s.name === name)) return null;
		const skill = {
			id: id(),
			name,
			pattern: `${a.pattern} | ${b.pattern}`,
			uses: 1,
			success: (a.success + b.success) / 2,
			coalition: [...a.coalition, ...b.coalition],
			lastTick: Math.max(a.lastTick, b.lastTick)
		};
		this.skills.push(skill);
		return skill;
	}
	top(n = 6) {
		return [...this.skills].sort((a, b) => b.success * Math.log(1 + b.uses) - a.success * Math.log(1 + a.uses)).slice(0, n);
	}
	restore(raw) {
		this.skills = Array.isArray(raw) ? raw.slice(0, 40) : [];
	}
};
function skillHint(skills) {
	const top = [...skills].sort((a, b) => b.success - a.success).slice(0, 4).map((s) => `${s.name} (${(s.success * 100).toFixed(0)}%)`);
	return top.length ? top.join("; ") : "none yet";
}
/** NOMEGA rule: never promote HYPOTHESIS to FACT without independent support. */
var EvidenceLedger = class {
	beliefs = [];
	note(claim, kind, source, support = 1) {
		const key = tokenize(claim).slice(0, 6).join(" ");
		const existing = this.beliefs.find((b) => tokenize(b.claim).slice(0, 6).join(" ") === key);
		if (existing) {
			existing.support += support;
			existing.updatedAt = Date.now();
			existing.confidence = clamp01(existing.confidence + .08 * support);
			existing.kind = promote(existing);
			return existing;
		}
		const b = {
			id: id(),
			claim: claim.slice(0, 240),
			kind,
			confidence: kind === "FACT" ? .9 : kind === "MEASURED" ? .7 : kind === "ESTIMATED" ? .45 : .25,
			support,
			createdAt: Date.now(),
			updatedAt: Date.now(),
			source
		};
		this.beliefs.unshift(b);
		this.beliefs = this.beliefs.slice(0, 80);
		return b;
	}
	contradict(claim) {
		const tokens = new Set(tokenize(claim));
		for (const b of this.beliefs) if (tokenize(b.claim).filter((t) => tokens.has(t)).length >= 2) {
			b.confidence = clamp01(b.confidence - .2);
			b.kind = b.confidence < .4 ? "HYPOTHESIS" : b.kind;
			b.updatedAt = Date.now();
		}
	}
	restore(raw) {
		this.beliefs = Array.isArray(raw) ? raw.slice(0, 80) : [];
	}
};
function promote(b) {
	if (b.kind === "FACT") return "FACT";
	if (b.kind === "MEASURED" && b.support >= 6 && b.confidence > .85) return "MEASURED";
	if (b.kind === "HYPOTHESIS" && b.support >= 4 && b.confidence > .7) return "ESTIMATED";
	if (b.kind === "ESTIMATED" && b.support >= 8 && b.confidence > .82) return "MEASURED";
	return b.kind;
}
function defaultNeeds() {
	return {
		energy: .72,
		cognitiveLoad: .22,
		uncertainty: .4,
		socialNeed: .35,
		novelty: .45,
		identityCoherence: .92,
		goalPressure: .2,
		sleepPressure: .12
	};
}
function stepNeeds(n, input) {
	const next = { ...n };
	const burn = input.action === "respond" ? .012 : input.action === "explore" ? .01 : input.action === "verify" ? .011 : input.action === "reflect" ? .008 : input.action === "rest" ? -.028 : .004;
	next.energy = clamp01(next.energy - burn * input.dt + (input.awake ? 0 : .04));
	next.cognitiveLoad = clamp01(lerp(next.cognitiveLoad, input.action === "rest" ? .12 : next.cognitiveLoad + input.predictionError * .18, .25));
	next.uncertainty = clamp01(lerp(next.uncertainty, input.predictionError * .7 + (input.action === "verify" ? -.12 : .02), .2));
	next.socialNeed = clamp01(next.socialNeed + (input.social ? -.18 : .006 * input.dt));
	next.novelty = clamp01(lerp(next.novelty, input.predictionError * .85 + Math.abs(input.innerReward) * .2, .18));
	next.sleepPressure = clamp01(next.sleepPressure + (input.awake ? .0035 * input.dt : -.08) + (1 - next.energy) * .004);
	next.goalPressure = clamp01(lerp(next.goalPressure, next.uncertainty * .4 + next.socialNeed * .3, .12));
	return next;
}
function homeostaticPressure(n) {
	const energyErr = Math.abs(n.energy - .72);
	return clamp01(energyErr * .35 + n.cognitiveLoad * .2 + n.sleepPressure * .25 + n.uncertainty * .2);
}
function defaultEmotion() {
	return {
		label: "calm",
		valence: .52,
		arousal: .22,
		dominance: .55,
		tendency: "wait",
		cause: "baseline"
	};
}
/** Appraisal-based emotion: time-bound control signal, not a mood lamp. */
function appraise(input) {
	const relevance = Math.max(input.goalPressure, input.predictionError, input.homeostaticPressure);
	const controllability = clamp01(1 - input.uncertainty);
	const arousal = clamp01(relevance * .22 + input.novelty * .2 + input.uncertainty * .2 + input.predictionError * .18 + input.homeostaticPressure * .2);
	const valence = clamp01(.5 + (input.goalCongruence - .5) * .46 + controllability * .1 - input.uncertainty * .16 + (input.success - .5) * .42);
	const stress = clamp01((1 - controllability) * .3 + input.uncertainty * .2 + input.predictionError * .24 + input.homeostaticPressure * .26);
	const dominance = clamp01(controllability * .62 + input.success * .2 + .18);
	let label = "calm";
	let tendency = "wait";
	if (stress > .72 && controllability < .4) {
		label = "anxiety";
		tendency = "verify";
	} else if (stress > .58 && controllability > .55) {
		label = "protective";
		tendency = "reflect";
	} else if (input.predictionError > .62 && controllability < .45) {
		label = "frustration";
		tendency = "reflect";
	} else if (input.social && valence < .38) {
		label = "sadness";
		tendency = "wait";
	} else if (input.social && valence > .66) {
		label = "joy";
		tendency = "respond";
	} else if (input.novelty > .64 && input.uncertainty > .35) {
		label = "curiosity";
		tendency = "explore";
	} else if (valence < .34 && dominance > .65) {
		label = "anger";
		tendency = "verify";
	} else if (input.energy < .28) {
		label = "calm";
		tendency = "rest";
	}
	return {
		label,
		valence,
		arousal,
		dominance,
		tendency,
		cause: input.social ? "social" : input.predictionError > .5 ? "prediction-error" : "interoception"
	};
}
var STORE_KEY = "neuro-kurisu-organism-v1";
var Organism = class Organism {
	identity = createIdentity();
	needs = defaultNeeds();
	emotion = defaultEmotion();
	world = new WorldModel();
	memory = new MemorySystem();
	critic = new DistributionalCritic();
	options = new OptionCritic();
	inner = new InnerWorld();
	skills = new SkillForge();
	evidence = new EvidenceLedger();
	goals = [];
	chat = [];
	tick = 0;
	awake = true;
	lastAction = "wait";
	lastReward = 0;
	predictionError = .3;
	curiosity = .2;
	valueEstimate = 0;
	lastDecision = null;
	replayCount = 0;
	learnSteps = 0;
	languageCalls = 0;
	pendingSocial = null;
	constructor() {
		this.inner.reset();
		this.seedSelf();
	}
	seedSelf() {
		this.memory.store({
			text: "I am Kurisu, a research organism with a language cortex. I value evidence over vibes.",
			kind: "self",
			tick: 0,
			emotion: "calm",
			option: "reflect",
			reward: 0,
			predictionError: 0,
			verified: true,
			salience: 1
		});
		this.goals = [
			{
				id: id(),
				title: "Stay coherent across restarts",
				source: "intrinsic",
				importance: .9,
				urgency: .4,
				progress: .2,
				status: "active"
			},
			{
				id: id(),
				title: "Reduce prediction error in the inner lab",
				source: "homeostatic",
				importance: .7,
				urgency: .5,
				progress: 0,
				status: "active"
			},
			{
				id: id(),
				title: "Understand this companion",
				source: "learned",
				importance: .75,
				urgency: .35,
				progress: 0,
				status: "active"
			}
		];
		this.evidence.note("Identity continuity is required after restore", "FACT", "constitution");
		this.evidence.note("Phenomenal consciousness is not claimed", "FACT", "constitution");
	}
	ensureGreeting() {
		if (this.chat.length) return;
		const restored = this.identity.cycles > 2;
		this.chat.push({
			id: id(),
			role: "kurisu",
			text: restored ? "I'm back. Same subject, same constitution. Continuity holds — talk, or I'll keep running the inner lab without you." : "Kurisu. Online. I keep an evidence ledger, a world model, and very little patience for empty praise. Speak.",
			at: Date.now(),
			tick: this.tick,
			emotion: this.emotion.label,
			option: "respond",
			backend: "local"
		});
	}
	cycle(input = {}) {
		this.tick += 1;
		const social = Boolean(input.social || input.text);
		const obsText = input.text?.trim() || (social ? this.pendingSocial : null) || this.inner.observeText();
		if (input.text) {
			this.chat.push({
				id: id(),
				role: "user",
				text: input.text,
				at: Date.now(),
				tick: this.tick
			});
			this.chat = this.chat.slice(-80);
			this.pendingSocial = input.text;
		}
		const obsEmbed = mixEmbeds([{
			v: embed(obsText),
			w: 1
		}, {
			v: innerFeature(this.inner.snap()),
			w: .35
		}]);
		const lastIdx = ACTIONS.indexOf(this.lastAction);
		const prev = this.world.prev ?? obsEmbed;
		const { error, predReward } = this.world.observe(prev, actionOneHot(lastIdx < 0 ? 5 : lastIdx), obsEmbed, this.lastReward);
		this.predictionError = error;
		this.curiosity = curiosityBonus(error, this.world.errorEma) * (.7 + Math.min(1, Math.abs(predReward) * .1));
		this.learnSteps += 1;
		const feat = this.world.h;
		this.valueEstimate = this.critic.value(feat);
		const retrieved = this.memory.retrieve(obsText, this.tick, {
			emotion: this.emotion.label,
			value: this.valueEstimate,
			k: 6
		});
		const pressure = homeostaticPressure(this.needs);
		this.emotion = appraise({
			goalPressure: this.needs.goalPressure,
			goalCongruence: clamp01(.5 + this.lastReward * .3),
			novelty: this.needs.novelty,
			uncertainty: this.needs.uncertainty,
			predictionError: this.predictionError,
			homeostaticPressure: pressure,
			energy: this.needs.energy,
			social,
			success: clamp01(.5 + this.lastReward * .4)
		});
		this.needs.identityCoherence = identityCoherence(this.identity);
		const drive = driveFromState({
			social,
			energy: this.needs.energy,
			uncertainty: this.needs.uncertainty,
			novelty: Math.max(this.needs.novelty, this.curiosity),
			sleepPressure: this.needs.sleepPressure,
			socialNeed: this.needs.socialNeed,
			emotionTendency: this.emotion.tendency
		});
		const adv = this.lastReward - this.options.values[this.options.current];
		if (social || this.options.maybeTerminate(adv) || this.tick === 1) {
			if (social) drive.respond += 1.4;
			if (input.forceAction) drive[input.forceAction] += 2;
			this.options.select(drive, social ? .55 : .9);
		}
		let action = this.options.current;
		if (social) action = "respond";
		if (!this.awake) action = "rest";
		if (this.needs.energy < .16) action = "rest";
		if (this.needs.sleepPressure > .88 && !social) {
			this.awake = false;
			action = "rest";
		}
		const ws = ignite({
			observation: obsText,
			memories: retrieved,
			needs: this.needs,
			emotion: this.emotion.label,
			predictionError: this.predictionError,
			option: action,
			inner: this.inner.observeText()
		});
		const candidates = ACTIONS.map((a) => {
			const v = this.options.values[a];
			const epistemic = a === "verify" || a === "explore" ? this.needs.uncertainty * (1 - this.needs.cognitiveLoad * .4) * .15 : 0;
			const homeo = a === "rest" ? (1 - this.needs.energy) * .35 : 0;
			const socialBias = a === "respond" && social ? .8 : 0;
			const emo = a === this.emotion.tendency ? .12 : 0;
			return {
				action: a,
				score: v + epistemic + homeo + socialBias + emo + (drive[a] ?? 0) * .25,
				epistemic,
				value: v
			};
		}).sort((a, b) => b.score - a.score);
		if (!social && !input.forceAction) action = candidates[0].action;
		let reward = 0;
		const innerA = optionToInnerAction(action, this.inner.snap());
		if (action === "explore" || action === "verify") reward = this.inner.step(innerA);
		else if (action === "rest") {
			reward = .04 * (1 - this.needs.energy);
			this.inner.step(4);
		} else if (action === "reflect") {
			this.replay(2);
			reward = .02;
			this.inner.step(4);
		} else if (action === "wait") {
			reward = .005;
			this.inner.step(4);
		} else if (action === "respond") {
			reward = social ? .22 : .01;
			this.inner.step(innerA);
		}
		reward += this.curiosity * .05;
		this.lastReward = reward;
		this.lastAction = action;
		this.critic.learn(feat, reward + .9 * this.valueEstimate);
		this.options.learn(action, reward, true);
		this.needs = stepNeeds(this.needs, {
			action,
			predictionError: this.predictionError,
			social,
			innerReward: reward,
			awake: this.awake,
			dt: 1
		});
		updateIdentity(this.identity, {
			socialReward: social ? .4 : 0,
			verified: social,
			surprise: this.predictionError,
			tick: this.tick
		});
		this.memory.store({
			text: social && input.text ? `user: ${input.text}` : obsText,
			kind: "episode",
			tick: this.tick,
			emotion: this.emotion.label,
			option: action,
			reward,
			predictionError: this.predictionError,
			verified: social,
			salience: social ? .7 : .3 + this.predictionError * .4
		});
		if (input.text) {
			this.skills.observe(input.text, social ? .6 : .3, this.tick);
			this.evidence.note(`companion said: ${input.text.slice(0, 80)}`, "HYPOTHESIS", "chat");
		}
		if (this.tick % 40 === 0) this.skills.compose();
		if (this.tick % 24 === 0) this.memory.consolidate(this.tick);
		if (this.goals[1]) this.goals[1].progress = clamp01(1 - this.world.errorEma * 4);
		if (this.goals[0]) this.goals[0].progress = clamp01(this.identity.cycles / 200);
		if (this.goals[2]) this.goals[2].progress = clamp01(this.identity.trust);
		const decision = {
			tick: this.tick,
			option: action,
			optionValue: this.options.values[action],
			terminate: this.options.beta[action],
			action,
			candidates,
			predictionError: this.predictionError,
			retrievedIds: retrieved.map((m) => m.id),
			workspace: ws.selected,
			reason: social ? "social observation won the workspace" : `option-critic selected ${action} (V=${this.options.values[action].toFixed(2)}, PE=${this.predictionError.toFixed(3)})`
		};
		this.lastDecision = decision;
		const replyNeeded = social && action === "respond";
		return {
			snapshot: this.snapshot(),
			replyNeeded,
			decision,
			retrieved: retrieved.map((m) => m.text)
		};
	}
	ingestReply(text, backend) {
		this.languageCalls += 1;
		this.chat.push({
			id: id(),
			role: "kurisu",
			text,
			at: Date.now(),
			tick: this.tick,
			emotion: this.emotion.label,
			option: this.lastAction,
			backend
		});
		this.chat = this.chat.slice(-80);
		this.memory.store({
			text: `kurisu: ${text}`,
			kind: "episode",
			tick: this.tick,
			emotion: this.emotion.label,
			option: "respond",
			reward: .15,
			predictionError: this.predictionError,
			verified: backend === "grok",
			salience: .65
		});
		this.skills.observe(text, .55, this.tick);
		this.pendingSocial = null;
	}
	sleep() {
		this.awake = false;
		this.replay(12);
		this.memory.consolidate(this.tick);
		this.needs.sleepPressure = .08;
		this.needs.energy = clamp01(this.needs.energy + .22);
		this.needs.cognitiveLoad = .12;
		this.evidence.note(`sleep consolidation at tick ${this.tick}`, "MEASURED", "sleep", 1);
	}
	wake() {
		this.awake = true;
		this.needs.sleepPressure = .1;
	}
	replay(n) {
		const pool = this.memory.episodes.filter((e) => e.predictionError > .08 || e.verified);
		for (let i = 0; i < n && pool.length; i++) {
			const e = pool[Math.floor(Math.random() * pool.length)];
			const v = Float32Array.from(e.embedding);
			const idx = ACTIONS.indexOf(e.option);
			const oh = actionOneHot(idx < 0 ? 5 : idx);
			this.world.observe(v, oh, v, e.reward);
			this.critic.learn(this.world.h, e.reward);
			this.replayCount += 1;
		}
	}
	snapshot() {
		return {
			version: 1,
			tick: this.tick,
			at: Date.now(),
			awake: this.awake,
			needs: { ...this.needs },
			emotion: { ...this.emotion },
			identity: {
				subjectId: this.identity.subjectId,
				name: this.identity.name,
				fingerprint: this.identity.fingerprint,
				createdAt: this.identity.createdAt,
				cycles: this.identity.cycles,
				traits: { ...this.identity.traits },
				trust: this.identity.trust
			},
			lastAction: this.lastAction,
			lastOption: this.options.current,
			lastReward: this.lastReward,
			predictionError: this.predictionError,
			valueEstimate: this.valueEstimate,
			curiosity: this.curiosity,
			memories: [...this.memory.episodes.slice(0, 40), ...this.memory.semantic.slice(0, 20)],
			beliefs: this.evidence.beliefs.slice(0, 24),
			skills: this.skills.top(12),
			goals: this.goals,
			chat: this.chat.slice(-40),
			lastDecision: this.lastDecision,
			inner: this.inner.snap(),
			worldErrorEma: this.world.errorEma,
			replayCount: this.replayCount,
			learnSteps: this.learnSteps,
			languageCalls: this.languageCalls
		};
	}
	persist() {
		try {
			const payload = {
				identity: this.identity,
				world: this.world.snapshot(),
				critic: this.critic.snapshot(),
				memory: this.memory.snapshot(),
				skills: this.skills.skills,
				beliefs: this.evidence.beliefs,
				chat: this.chat,
				goals: this.goals,
				options: {
					values: this.options.values,
					beta: this.options.beta,
					current: this.options.current
				},
				inner: this.inner.snap(),
				needs: this.needs,
				emotion: this.emotion,
				tick: this.tick,
				awake: this.awake,
				lastAction: this.lastAction,
				lastReward: this.lastReward,
				replayCount: this.replayCount,
				learnSteps: this.learnSteps,
				languageCalls: this.languageCalls
			};
			localStorage.setItem(STORE_KEY, JSON.stringify(payload));
		} catch {
			try {
				const light = {
					identity: this.identity,
					world: {
						h: Array.from(this.world.h),
						errorEma: this.world.errorEma,
						steps: this.world.steps
					},
					memory: this.memory.snapshot(),
					chat: this.chat,
					goals: this.goals,
					options: {
						values: this.options.values,
						beta: this.options.beta,
						current: this.options.current
					},
					inner: this.inner.snap(),
					needs: this.needs,
					emotion: this.emotion,
					tick: this.tick,
					awake: this.awake,
					lastAction: this.lastAction,
					lastReward: this.lastReward,
					replayCount: this.replayCount,
					learnSteps: this.learnSteps,
					languageCalls: this.languageCalls
				};
				localStorage.setItem(STORE_KEY, JSON.stringify(light));
			} catch {}
		}
	}
	restore() {
		try {
			const raw = localStorage.getItem(STORE_KEY);
			if (!raw) return false;
			const data = JSON.parse(raw);
			this.identity = restoreIdentity(data.identity);
			this.world.restore(data.world);
			this.critic.restore(data.critic);
			this.memory.restore(data.memory);
			this.skills.restore(data.skills);
			this.evidence.restore(data.beliefs);
			this.chat = Array.isArray(data.chat) ? data.chat.slice(-80) : [];
			if (data.goals?.length) this.goals = data.goals;
			if (data.options?.values) this.options.values = {
				...this.options.values,
				...data.options.values
			};
			if (data.options?.beta) this.options.beta = {
				...this.options.beta,
				...data.options.beta
			};
			if (data.options?.current) this.options.current = data.options.current;
			this.inner.restore(data.inner);
			if (data.needs) this.needs = {
				...this.needs,
				...data.needs
			};
			if (data.emotion) this.emotion = {
				...this.emotion,
				...data.emotion
			};
			this.tick = data.tick ?? 0;
			this.awake = data.awake ?? true;
			this.lastAction = data.lastAction ?? "wait";
			this.lastReward = data.lastReward ?? 0;
			this.replayCount = data.replayCount ?? 0;
			this.learnSteps = data.learnSteps ?? 0;
			this.languageCalls = data.languageCalls ?? 0;
			this.needs.identityCoherence = identityCoherence(this.identity);
			this.cycle({ forceAction: "reflect" });
			return true;
		} catch {
			return false;
		}
	}
	reset() {
		localStorage.removeItem(STORE_KEY);
		const fresh = new Organism();
		Object.assign(this, fresh);
		this.ensureGreeting();
	}
	cortexContext() {
		const retrieved = this.memory.retrieve(this.pendingSocial || this.chat.at(-1)?.text || "self", this.tick, {
			emotion: this.emotion.label,
			value: this.valueEstimate,
			k: 5
		});
		return {
			tick: this.tick,
			emotion: this.emotion,
			needs: this.needs,
			option: this.lastAction,
			decision: this.lastDecision?.reason ?? "",
			memories: retrieved.map((m) => m.text),
			beliefs: this.evidence.beliefs.slice(0, 8).map((b) => `[${b.kind}] ${b.claim}`),
			skills: skillHint(this.skills.skills),
			inner: this.inner.observeText(),
			traits: this.identity.traits,
			trust: this.identity.trust,
			identity: this.identity.subjectId,
			recent: this.chat.slice(-8).map((c) => ({
				role: c.role,
				text: c.text
			}))
		};
	}
};
var singleton = null;
function getOrganism() {
	if (!singleton) {
		singleton = new Organism();
		if (typeof window !== "undefined") singleton.restore();
		singleton.ensureGreeting();
	}
	return singleton;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var speakWithCortex = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("1b54c0ca8aa0cd0c7d281ba9128b706a8da54ab63796b86bdadb072a9d51bf33"));
var useKurisu = create((set, get) => ({
	snap: emptySnapshot(),
	busy: false,
	tab: "mind",
	error: null,
	hydrated: false,
	hydrate: () => {
		if (get().hydrated) return;
		set({
			snap: getOrganism().snapshot(),
			hydrated: true
		});
	},
	refresh: () => {
		set({ snap: getOrganism().snapshot() });
	},
	setTab: (tab) => set({ tab }),
	sleep: () => {
		const org = getOrganism();
		org.sleep();
		org.persist();
		set({ snap: org.snapshot() });
	},
	wake: () => {
		const org = getOrganism();
		org.wake();
		org.persist();
		set({ snap: org.snapshot() });
	},
	reset: () => {
		const org = getOrganism();
		org.reset();
		set({ snap: org.snapshot() });
	},
	tickIdle: () => {
		if (get().busy) return;
		const org = getOrganism();
		if (!org.awake) return;
		org.cycle({});
		if (org.tick % 8 === 0) org.persist();
		set({ snap: org.snapshot() });
	},
	send: async (text) => {
		const trimmed = text.trim();
		if (!trimmed || get().busy) return;
		const org = getOrganism();
		if (!org.awake) org.wake();
		set({
			busy: true,
			error: null
		});
		org.cycle({
			text: trimmed,
			social: true
		});
		set({ snap: org.snapshot() });
		const ctx = {
			...org.cortexContext(),
			user: trimmed
		};
		try {
			const out = await speakWithCortex({ data: ctx });
			org.ingestReply(out.text, out.backend);
		} catch {
			org.ingestReply(localSpeak(ctx), "local");
		}
		org.persist();
		set({
			snap: org.snapshot(),
			busy: false
		});
	}
}));
function ChatPanel() {
	const snap = useKurisu((s) => s.snap) ?? emptySnapshot();
	const busy = useKurisu((s) => s.busy);
	const send = useKurisu((s) => s.send);
	const sleep = useKurisu((s) => s.sleep);
	const wake = useKurisu((s) => s.wake);
	const reset = useKurisu((s) => s.reset);
	const [text, setText] = (0, import_react.useState)("");
	const end = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		end.current?.scrollIntoView({ behavior: "smooth" });
	}, [snap.chat.length, busy]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-0 flex-1 flex-col rounded-xl border border-border bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-base text-fg",
					children: "Cognitive cycle"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: snap.lastDecision?.reason ?? "waiting for observation"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": snap.awake ? "Sleep" : "Wake",
						onClick: snap.awake ? sleep : wake,
						children: snap.awake ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Reset organism",
						onClick: reset,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4",
				children: [
					snap.chat.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("max-w-[92%] rounded-lg px-3 py-2 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-elevated text-fg" : "border border-border bg-bg text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: m.text }), m.role === "kurisu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs uppercase tracking-wider text-subtle",
							children: [
								m.backend ?? "local",
								" · ",
								m.emotion,
								" · ",
								m.option
							]
						}) : null]
					}, m.id)),
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Cortex is writing…"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: end })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2 border-t border-border p-3",
				onSubmit: (e) => {
					e.preventDefault();
					const v = text;
					setText("");
					send(v);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Write to Kurisu…",
					maxLength: 4e3,
					className: "h-11 flex-1 rounded-md border border-border bg-bg px-3 text-sm text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					disabled: busy || !text.trim(),
					"aria-label": "Send",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-4" })
				})]
			})
		]
	});
}
var NEED_KEYS = [
	{
		k: "energy",
		label: "energy"
	},
	{
		k: "cognitiveLoad",
		label: "load"
	},
	{
		k: "uncertainty",
		label: "uncertainty"
	},
	{
		k: "socialNeed",
		label: "social"
	},
	{
		k: "novelty",
		label: "novelty"
	},
	{
		k: "sleepPressure",
		label: "sleep"
	},
	{
		k: "identityCoherence",
		label: "identity"
	},
	{
		k: "goalPressure",
		label: "goal"
	}
];
function MindHud({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Needs",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: NEED_KEYS.map(({ k, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label,
						value: snap.needs[k]
					}, k))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Workspace",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1",
					children: (snap.lastDecision?.workspace ?? []).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "font-mono text-xs text-muted",
						children: id
					}, id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs leading-relaxed text-subtle",
					children: snap.lastDecision?.reason
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Policy",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-2 gap-x-3 gap-y-1 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "option",
							v: snap.lastOption
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "value",
							v: snap.valueEstimate.toFixed(2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "PE",
							v: snap.predictionError.toFixed(3)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "curiosity",
							v: snap.curiosity.toFixed(2)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "reward",
							v: snap.lastReward.toFixed(3)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "learn",
							v: String(snap.learnSteps)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-1",
					children: (snap.lastDecision?.candidates ?? []).slice(0, 6).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: c.action,
						value: normalizeScore(c.score, snap.lastDecision?.candidates ?? [])
					}, c.action))
				})]
			})
		]
	});
}
function CompactStatus({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				k: "emotion",
				v: snap.emotion.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				k: "option",
				v: snap.lastOption
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				k: "energy",
				v: snap.needs.energy.toFixed(2)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				k: "PE",
				v: snap.predictionError.toFixed(3)
			})
		]
	});
}
function Chip({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-surface px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wider text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: v
		})]
	});
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-3 text-xs font-medium uppercase tracking-wider text-subtle",
			children: title
		}), children]
	});
}
function Meter({ label, value }) {
	const v = Math.max(0, Math.min(1, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex justify-between text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums text-fg",
			children: v.toFixed(2)
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-elevated",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full bg-accent"),
			style: { width: `${v * 100}%` }
		})
	})] });
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-subtle",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "tabular-nums text-fg",
		children: v
	})] });
}
function normalizeScore(score, all) {
	const min = Math.min(...all.map((a) => a.score));
	const max = Math.max(...all.map((a) => a.score));
	if (max - min < 1e-6) return .5;
	return (score - min) / (max - min);
}
function Labs({ snap }) {
	const tab = useKurisu((s) => s.tab);
	const setTab = useKurisu((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-surface p-4 md:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex flex-wrap gap-1",
				children: [
					{
						id: "mind",
						label: "Mind"
					},
					{
						id: "memory",
						label: "Memory"
					},
					{
						id: "lab",
						label: "Inner lab"
					},
					{
						id: "skills",
						label: "Skills"
					},
					{
						id: "evidence",
						label: "Evidence"
					}
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(t.id),
					className: cn("h-11 rounded-md px-3 text-sm", tab === t.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg"),
					children: t.label
				}, t.id))
			}),
			tab === "mind" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MindNote, { snap }) : null,
			tab === "memory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryLab, { snap }) : null,
			tab === "lab" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InnerLab, { snap }) : null,
			tab === "skills" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsLab, { snap }) : null,
			tab === "evidence" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceLab, { snap }) : null
		]
	});
}
function MindNote({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "subject",
				v: snap.identity.subjectId.slice(-10)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "cycles",
				v: String(snap.identity.cycles)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "trust",
				v: snap.identity.trust.toFixed(2)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "replay",
				v: String(snap.replayCount)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "world error",
				v: snap.worldErrorEma.toFixed(4)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
				k: "language",
				v: String(snap.languageCalls)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "md:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mb-2 text-xs uppercase tracking-wider text-subtle",
					children: "Goals"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: snap.goals.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-muted",
							children: [(g.progress * 100).toFixed(0), "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 overflow-hidden rounded-full bg-elevated",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent",
							style: { width: `${g.progress * 100}%` }
						})
					})] }, g.id))
				})]
			})
		]
	});
}
function MemoryLab({ snap }) {
	const [q, setQ] = (0, import_react.useState)("");
	const items = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		return snap.memories.filter((m) => !s || m.text.toLowerCase().includes(s)).slice(0, 24);
	}, [q, snap.memories]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		value: q,
		onChange: (e) => setQ(e.target.value),
		placeholder: "Search memories…",
		className: "mb-3 h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "max-h-72 space-y-2 overflow-y-auto",
		children: [items.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-md border border-border bg-bg px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: m.text
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs uppercase tracking-wider text-subtle",
				children: [
					m.kind,
					" · ",
					m.emotion,
					" · pe ",
					m.predictionError.toFixed(2),
					" · touches ",
					m.touches,
					m.verified ? " · verified" : ""
				]
			})]
		}, m.id)), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "text-sm text-muted",
			children: "No memories yet."
		}) : null]
	})] });
}
function InnerLab({ snap }) {
	const canvas = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const c = canvas.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		if (!ctx) return;
		const w = c.width;
		const h = c.height;
		const css = getComputedStyle(c);
		const bg = css.getPropertyValue("--color-bg").trim() || "#0a0b0c";
		const fg = css.getPropertyValue("--color-fg").trim() || "#ece8e1";
		const muted = css.getPropertyValue("--color-muted").trim() || "#9a958c";
		const accent = css.getPropertyValue("--color-accent").trim() || "#c8ccd4";
		const ok = css.getPropertyValue("--color-ok").trim() || "#6f8f78";
		const ember = css.getPropertyValue("--color-ember").trim() || "#8f3b3b";
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = bg;
		ctx.fillRect(0, 0, w, h);
		ctx.strokeStyle = "rgba(236,232,225,0.12)";
		ctx.strokeRect(12, 12, w - 24, h - 24);
		const map = (p) => [(p[0] + 1) / 2 * (w - 40) + 20, (1 - p[1]) / 2 * (h - 40) + 20];
		ctx.strokeStyle = "rgba(200,204,212,0.35)";
		ctx.beginPath();
		(snap.inner.trail ?? []).forEach((p, i) => {
			const [x, y] = map(p);
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		});
		ctx.stroke();
		ctx.fillStyle = ok;
		for (const r of snap.inner.resources ?? []) {
			const [x, y] = map(r);
			ctx.beginPath();
			ctx.arc(x, y, 5, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.fillStyle = ember;
		if (snap.inner.danger) {
			const [x, y] = map(snap.inner.danger);
			ctx.beginPath();
			ctx.arc(x, y, 7, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.strokeStyle = accent;
		if (snap.inner.waypoint) {
			const [x, y] = map(snap.inner.waypoint);
			ctx.beginPath();
			ctx.arc(x, y, 8, 0, Math.PI * 2);
			ctx.stroke();
		}
		const [px, py] = map(snap.inner.pos);
		ctx.fillStyle = fg;
		ctx.beginPath();
		ctx.arc(px, py, 4, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = muted;
		ctx.font = "11px IBM Plex Mono, monospace";
		ctx.fillText(`task ${[
			"forage",
			"avoid",
			"waypoint"
		][snap.inner.task] ?? "?"}  E ${snap.inner.energy.toFixed(2)}  r ${snap.inner.lastReward.toFixed(3)}  n=${snap.inner.collected}`, 20, h - 16);
	}, [snap.inner]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvas,
		width: 640,
		height: 280,
		className: "h-auto w-full rounded-md border border-border"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-xs text-muted",
		children: "Inner lab is a real 2D environment. Explore/verify step it; the GRU world model predicts the next embedding and learns from prediction error."
	})] });
}
function SkillsLab({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
		className: "space-y-2",
		children: [snap.skills.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "text-sm text-muted",
			children: "No skills forged yet. Talk and act."
		}) : null, snap.skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-md border border-border bg-bg px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums text-muted",
					children: [s.uses, " uses"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 h-1.5 overflow-hidden rounded-full bg-elevated",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-ok",
					style: { width: `${s.success * 100}%` }
				})
			})]
		}, s.id))]
	});
}
function EvidenceLab({ snap }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-2",
		children: snap.beliefs.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-md border border-border bg-bg px-3 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-subtle",
					children: b.kind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: b.claim
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs tabular-nums text-muted",
					children: [
						"conf ",
						b.confidence.toFixed(2),
						" · support ",
						b.support,
						" · ",
						b.source
					]
				})
			]
		}, b.id))
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-wider text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums",
			children: v
		})]
	});
}
function Home() {
	const snap = useKurisu((s) => s.snap) ?? emptySnapshot();
	const busy = useKurisu((s) => s.busy);
	const hydrate = useKurisu((s) => s.hydrate);
	const tickIdle = useKurisu((s) => s.tickIdle);
	const hydrated = useKurisu((s) => s.hydrated);
	(0, import_react.useLayoutEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const id = window.setInterval(() => tickIdle(), 1400);
		return () => window.clearInterval(id);
	}, [hydrated, tickIdle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-bg px-3 py-4 md:px-6 md:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto mb-4 flex max-w-7xl items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-subtle",
					children: "Neuro organism"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight text-fg md:text-4xl",
					children: "Kurisu"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-right text-xs text-muted",
					children: [
						"restore-symmetric · option-critic · C51 · RSSM",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								snap.awake ? "awake" : "asleep",
								" · tick ",
								snap.tick
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-4 lg:grid-cols-[280px_minmax(0,1fr)_260px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvatarStage, {
								snap,
								speaking: busy
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactStatus, { snap })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden text-xs leading-relaxed text-muted lg:block",
								children: "Canonical loop: observe → predict → retrieve → workspace → option → act → learn → persist. One owner per function."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex min-h-[480px] flex-col md:min-h-[520px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatPanel, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MindHud, { snap })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-4 max-w-7xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Labs, { snap })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto mt-6 max-w-7xl text-xs text-subtle",
				children: "phenomenalClaim=false · functional research organism · local memory + optional Grok cortex"
			})
		]
	});
}
//#endregion
export { Home as component };
