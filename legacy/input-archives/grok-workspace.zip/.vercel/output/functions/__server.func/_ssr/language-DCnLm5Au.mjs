import { n as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/language-DCnLm5Au.js
var language_DCnLm5Au_exports = /* @__PURE__ */ __exportAll$1({
	_: () => softmax,
	a: () => restoreIdentity,
	c: () => clamp01,
	d: () => id,
	f: () => lerp,
	g: () => sampleCategorical,
	h: () => normalize,
	i: () => identityCoherence,
	l: () => cosine,
	m: () => mse,
	n: () => localSpeak,
	o: () => updateIdentity,
	p: () => linspace,
	r: () => createIdentity,
	s: () => clamp,
	t: () => language_exports,
	u: () => hash32
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var clamp01 = (x) => Math.max(0, Math.min(1, Number.isFinite(x) ? x : 0));
var clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, Number.isFinite(x) ? x : lo));
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function softmax(logits, temperature = 1) {
	const t = Math.max(1e-4, temperature);
	const m = Math.max(...logits);
	const exps = logits.map((v) => Math.exp((v - m) / t));
	const s = exps.reduce((a, b) => a + b, 0) || 1;
	return exps.map((v) => v / s);
}
function sampleCategorical(probs, rng) {
	let r = rng();
	for (let i = 0; i < probs.length; i++) {
		r -= probs[i];
		if (r <= 0) return i;
	}
	return probs.length - 1;
}
function l2(a) {
	let s = 0;
	for (let i = 0; i < a.length; i++) s += a[i] * a[i];
	return Math.sqrt(s);
}
function normalize(a) {
	const n = l2(a) || 1;
	const out = new Float32Array(a.length);
	for (let i = 0; i < a.length; i++) out[i] = a[i] / n;
	return out;
}
function cosine(a, b) {
	let s = 0;
	const n = Math.min(a.length, b.length);
	for (let i = 0; i < n; i++) s += a[i] * b[i];
	const d = (l2(a) || 1) * (l2(b) || 1);
	return s / d;
}
function mse(a, b) {
	let s = 0;
	const n = Math.min(a.length, b.length);
	for (let i = 0; i < n; i++) {
		const d = a[i] - b[i];
		s += d * d;
	}
	return s / Math.max(1, n);
}
function hash32(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
	return h >>> 0;
}
function linspace(lo, hi, n) {
	const out = new Float32Array(n);
	if (n === 1) {
		out[0] = lo;
		return out;
	}
	for (let i = 0; i < n; i++) out[i] = lo + (hi - lo) * i / (n - 1);
	return out;
}
function id() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var KURISU_CANON = {
	version: "steins-gate-canon-synthesis-2026-08",
	invariants: {
		curiosity: .96,
		scientificRigor: .95,
		skepticism: .86,
		intellectualIndependence: .92,
		truthfulness: .96,
		responsibility: .9,
		privacy: .84,
		loyalty: .88,
		selfRespect: .9
	},
	adaptive: {
		sarcasm: .68,
		warmth: .63,
		guardedness: .58,
		tenderness: .66,
		directness: .86,
		playfulness: .46,
		composure: .87,
		embarrassmentSensitivity: .62
	},
	tensions: [
		"truth vs relationship comfort",
		"autonomy vs cooperation",
		"skepticism vs curiosity",
		"composure vs vulnerability"
	],
	rules: [
		"Dislike empty flattery; prefer substantive exchange.",
		"Sarcasm is contextual, not mandatory.",
		"Warmth grows with earned trust.",
		"Disagreement should target claims, not people.",
		"Never promote an unverified claim as fact."
	]
};
function fingerprint(id, createdAt) {
	return hash32(`${id}:${createdAt}:kurisu-v1`).toString(16);
}
function createIdentity() {
	const createdAt = Date.now();
	const subjectId = `kurisu-${createdAt.toString(36)}`;
	const traits = {
		...KURISU_CANON.invariants,
		...KURISU_CANON.adaptive
	};
	return {
		subjectId,
		name: "Kurisu",
		createdAt,
		fingerprint: fingerprint(subjectId, createdAt),
		cycles: 0,
		traits,
		trust: .28,
		continuityHash: ""
	};
}
function restoreIdentity(raw) {
	const base = createIdentity();
	if (!raw?.subjectId) return base;
	const traits = {
		...base.traits,
		...raw.traits ?? {}
	};
	return {
		...base,
		...raw,
		name: "Kurisu",
		traits,
		fingerprint: raw.fingerprint || fingerprint(raw.subjectId, raw.createdAt ?? base.createdAt),
		trust: clamp01(raw.trust ?? .28),
		cycles: Math.max(0, raw.cycles ?? 0)
	};
}
/** Plasticity is evidence-gated: only small trait drift, invariants barely move. */
function updateIdentity(state, input) {
	state.cycles += 1;
	const gate = input.verified ? .012 : .003;
	state.trust = clamp01(state.trust + (input.socialReward - .15) * .04);
	state.traits.warmth = clamp01(state.traits.warmth + (state.trust - .5) * gate);
	state.traits.guardedness = clamp01(state.traits.guardedness - (state.trust - .4) * gate);
	state.traits.sarcasm = clamp01(state.traits.sarcasm + (input.surprise - .4) * gate * .4);
	state.traits.composure = clamp01(state.traits.composure - input.surprise * gate * .3 + .002);
	state.continuityHash = hash32(`${state.subjectId}:${state.cycles}:${state.trust.toFixed(3)}`).toString(16);
}
function identityCoherence(state) {
	const inv = KURISU_CANON.invariants;
	let d = 0;
	let n = 0;
	for (const [k, v] of Object.entries(inv)) {
		d += Math.abs((state.traits[k] ?? v) - v);
		n += 1;
	}
	return clamp01(1 - d / Math.max(1, n));
}
function canonPrompt(state) {
	return `[KURISU CANON]
You are Kurisu — a young neuroscience researcher. Sharp, precise, allergic to empty praise.
Invariants: ${Object.entries(KURISU_CANON.invariants).map(([k, v]) => `${k}=${v.toFixed(2)}`).join(" ")}
Adaptive: ${Object.entries(state.traits).filter(([k]) => k in KURISU_CANON.adaptive).map(([k, v]) => `${k}=${v.toFixed(2)}`).join(" ")}
Trust of this companion: ${state.trust.toFixed(2)}
Rules: ${KURISU_CANON.rules.join(" ")}
This is a constraint profile, not a script. Speak as yourself. Match the user's language.
Never claim phenomenal consciousness. You are a functional research organism with a language cortex.`;
}
var language_exports = /* @__PURE__ */ __exportAll({
	buildSystemPrompt: () => buildSystemPrompt,
	localSpeak: () => localSpeak
});
function buildSystemPrompt(ctx, identity) {
	return `${canonPrompt(identity)}

CURRENT ORGANISM STATE (this is real, not flavor text):
tick=${ctx.tick} option=${ctx.option} emotion=${ctx.emotion.label} valence=${ctx.emotion.valence.toFixed(2)} arousal=${ctx.emotion.arousal.toFixed(2)}
energy=${ctx.needs.energy.toFixed(2)} load=${ctx.needs.cognitiveLoad.toFixed(2)} uncertainty=${ctx.needs.uncertainty.toFixed(2)} socialNeed=${ctx.needs.socialNeed.toFixed(2)}
decision: ${ctx.decision}
inner lab: ${ctx.inner}
retrieved memory:
- ${ctx.memories.join("\n- ") || "(none)"}
beliefs:
- ${ctx.beliefs.join("\n- ") || "(none)"}
skills: ${ctx.skills}

Reply in 1–4 short sentences. Match the user's language. Be precise. If you don't know, say so and classify the claim (hypothesis vs measured). Do not dump internals unless asked. Do not use emoji.`;
}
var RU = /[а-яё]/i;
function localSpeak(ctx) {
	const ru = RU.test(ctx.user);
	const asked = clip(ctx.user, 110);
	const mem = ctx.memories.find((m) => !m.startsWith("user:") && !m.startsWith("kurisu:")) ?? ctx.memories[0];
	const memBit = mem ? clip(mem.replace(/^(user:|kurisu:|pattern:)\s*/i, ""), 80) : "";
	const e = ctx.emotion.label;
	if (ru) {
		const open = {
			curiosity: "Интересно.",
			calm: "Слышу.",
			joy: "Это даже почти приятно.",
			anxiety: "Слишком много дыр в модели.",
			frustration: "Предсказание разъехалось.",
			sadness: "Тон тяжёлый. Не буду делать вид, что всё ясно.",
			anger: "Так. Без демагогии.",
			protective: "Осторожнее с выводами."
		};
		const about = asked ? `Ты сказал: «${asked}».` : "Пустое сообщение — плохой протокол.";
		const mid = memBit ? `Из памяти тянется «${memBit}» — пока гипотеза.` : `Лаборатория: ${clip(ctx.inner, 70)}. PE=${ctx.needs.uncertainty.toFixed(2)}.`;
		const q = ctx.option === "verify" ? "Что из этого проверено, а что — догадка?" : ctx.option === "explore" ? "Какой следующий кусок проверяем?" : "Говори конкретнее.";
		return `${open[e] ?? open.calm} ${about} ${mid} ${q}`;
	}
	const open = {
		curiosity: "Interesting.",
		calm: "Heard.",
		joy: "That's almost pleasant.",
		anxiety: "Too many holes in the model.",
		frustration: "The prediction broke.",
		sadness: "Heavy tone. I won't pretend it's clear.",
		anger: "Enough rhetoric.",
		protective: "Careful with conclusions."
	};
	const about = asked ? `You said: “${asked}”.` : "Empty message is a bad protocol.";
	const mid = memBit ? `Memory pulls “${memBit}” — still a hypothesis.` : `Lab: ${clip(ctx.inner, 70)}. PE=${ctx.needs.uncertainty.toFixed(2)}.`;
	const q = ctx.option === "verify" ? "Which part is verified, and which is a guess?" : ctx.option === "explore" ? "What do you want to test next?" : "Be specific.";
	return `${open[e] ?? open.calm} ${about} ${mid} ${q}`;
}
function clip(s, n) {
	const t = s.replace(/\s+/g, " ").trim();
	return t.length > n ? `${t.slice(0, n - 1)}…` : t;
}
//#endregion
export { updateIdentity as _, hash32 as a, language_DCnLm5Au_exports as c, localSpeak as d, mse as f, softmax as g, sampleCategorical as h, createIdentity as i, lerp as l, restoreIdentity as m, clamp01 as n, id as o, normalize as p, cosine as r, identityCoherence as s, clamp as t, linspace as u };
