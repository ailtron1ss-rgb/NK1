import { d as localSpeak, i as createIdentity } from "./language-DCnLm5Au.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cortex-c9YVuf1b.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var speakWithCortex_createServerFn_handler = createServerRpc({
	id: "1b54c0ca8aa0cd0c7d281ba9128b706a8da54ab63796b86bdadb072a9d51bf33",
	name: "speakWithCortex",
	filename: "src/lib/cortex.ts"
}, (opts) => speakWithCortex.__executeServer(opts));
var speakWithCortex = createServerFn({ method: "POST" }).validator((input) => input).handler(speakWithCortex_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	const identity = createIdentity();
	identity.traits = data.traits;
	identity.trust = data.trust;
	identity.subjectId = data.identity;
	if (!apiKey) return {
		ok: true,
		text: localSpeak(data),
		backend: "local"
	};
	const { buildSystemPrompt } = await import("./language-DCnLm5Au.mjs").then((n) => n.c).then((n) => n.t);
	const messages = [
		{
			role: "system",
			content: buildSystemPrompt(data, identity)
		},
		...data.recent.map((m) => ({
			role: m.role === "kurisu" ? "assistant" : "user",
			content: m.text.slice(0, 1200)
		})),
		{
			role: "user",
			content: data.user.slice(0, 4e3)
		}
	];
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				messages,
				max_tokens: 280,
				temperature: .7
			})
		});
		if (!res.ok) return {
			ok: true,
			text: localSpeak(data),
			backend: "local"
		};
		const text = (await res.json()).choices?.[0]?.message?.content?.trim();
		if (!text) return {
			ok: true,
			text: localSpeak(data),
			backend: "local"
		};
		return {
			ok: true,
			text,
			backend: "grok"
		};
	} catch {
		return {
			ok: true,
			text: localSpeak(data),
			backend: "local"
		};
	}
});
//#endregion
export { speakWithCortex_createServerFn_handler };
