import { create } from "zustand";
import { getOrganism } from "./organism";
import type { OrganismSnapshot } from "./types";
import { emptySnapshot } from "./types";
import { speakWithCortex } from "@/lib/cortex";
import { localSpeak, type CortexContext } from "./language";

type Tab = "mind" | "memory" | "lab" | "skills" | "evidence";

interface KurisuStore {
  snap: OrganismSnapshot;
  busy: boolean;
  tab: Tab;
  error: string | null;
  hydrated: boolean;
  hydrate: () => void;
  refresh: () => void;
  send: (text: string) => Promise<void>;
  sleep: () => void;
  wake: () => void;
  reset: () => void;
  setTab: (tab: Tab) => void;
  tickIdle: () => void;
}

export const useKurisu = create<KurisuStore>((set, get) => ({
  snap: emptySnapshot(),
  busy: false,
  tab: "mind",
  error: null,
  hydrated: false,
  hydrate: () => {
    if (get().hydrated) return;
    const org = getOrganism();
    set({ snap: org.snapshot(), hydrated: true });
  },
  refresh: () => {
    set({ snap: getOrganism().snapshot() });
  },
  setTab: (tab) => set({ tab }),
  sleep: () => {
    const org = getOrganism();
    org.sleep();
    org.persist();
    set({ snap: org.snapshot() });
  },
  wake: () => {
    const org = getOrganism();
    org.wake();
    org.persist();
    set({ snap: org.snapshot() });
  },
  reset: () => {
    const org = getOrganism();
    org.reset();
    set({ snap: org.snapshot() });
  },
  tickIdle: () => {
    if (get().busy) return;
    const org = getOrganism();
    if (!org.awake) return;
    org.cycle({});
    if (org.tick % 8 === 0) org.persist();
    set({ snap: org.snapshot() });
  },
  send: async (text) => {
    const trimmed = text.trim();
    if (!trimmed || get().busy) return;
    const org = getOrganism();
    if (!org.awake) org.wake();
    set({ busy: true, error: null });
    org.cycle({ text: trimmed, social: true });
    set({ snap: org.snapshot() });
    const ctx: CortexContext = { ...org.cortexContext(), user: trimmed };
    try {
      const out = await speakWithCortex({ data: ctx });
      org.ingestReply(out.text, out.backend);
    } catch {
      org.ingestReply(localSpeak(ctx), "local");
    }
    org.persist();
    set({ snap: org.snapshot(), busy: false });
  },
}));
