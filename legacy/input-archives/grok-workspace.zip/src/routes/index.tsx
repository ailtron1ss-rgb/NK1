import { useEffect, useLayoutEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AvatarStage } from "@/components/AvatarStage";
import { ChatPanel } from "@/components/ChatPanel";
import { CompactStatus, MindHud } from "@/components/MindHud";
import { Labs } from "@/components/Labs";
import { useKurisu } from "@/organism/store";
import { emptySnapshot } from "@/organism/types";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const snap = useKurisu((s) => s.snap) ?? emptySnapshot();
  const busy = useKurisu((s) => s.busy);
  const hydrate = useKurisu((s) => s.hydrate);
  const tickIdle = useKurisu((s) => s.tickIdle);
  const hydrated = useKurisu((s) => s.hydrated);

  useLayoutEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!hydrated) return;
    const id = window.setInterval(() => tickIdle(), 1400);
    return () => window.clearInterval(id);
  }, [hydrated, tickIdle]);

  return (
    <main className="min-h-dvh bg-bg px-3 py-4 md:px-6 md:py-6">
      <header className="mx-auto mb-4 flex max-w-7xl items-end justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-widest text-subtle">Neuro organism</p>
          <h1 className="font-display text-3xl tracking-tight text-fg md:text-4xl">Kurisu</h1>
        </div>
        <p className="text-right text-xs text-muted">
          restore-symmetric · option-critic · C51 · RSSM
          <br />
          <span className="tabular-nums">
            {snap.awake ? "awake" : "asleep"} · tick {snap.tick}
          </span>
        </p>
      </header>

      <div className="mx-auto grid max-w-7xl gap-4 lg:grid-cols-[280px_minmax(0,1fr)_260px]">
        <div className="space-y-3">
          <AvatarStage snap={snap} speaking={busy} />
          <div className="lg:hidden">
            <CompactStatus snap={snap} />
          </div>
          <p className="hidden text-xs leading-relaxed text-muted lg:block">
            Canonical loop: observe → predict → retrieve → workspace → option → act → learn →
            persist. One owner per function.
          </p>
        </div>
        <div className="flex min-h-[480px] flex-col md:min-h-[520px]">
          <ChatPanel />
        </div>
        <div className="hidden lg:block">
          <MindHud snap={snap} />
        </div>
      </div>

      <div className="mx-auto mt-4 max-w-7xl">
        <Labs snap={snap} />
      </div>

      <footer className="mx-auto mt-6 max-w-7xl text-xs text-subtle">
        phenomenalClaim=false · functional research organism · local memory + optional Grok cortex
      </footer>
    </main>
  );
}
