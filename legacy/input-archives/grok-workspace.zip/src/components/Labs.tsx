import { useMemo, useRef, useEffect, useState } from "react";
import type { OrganismSnapshot } from "@/organism/types";
import { useKurisu } from "@/organism/store";
import { cn } from "@/lib/utils";

export function Labs({ snap }: { snap: OrganismSnapshot }) {
  const tab = useKurisu((s) => s.tab);
  const setTab = useKurisu((s) => s.setTab);
  const tabs = [
    { id: "mind", label: "Mind" },
    { id: "memory", label: "Memory" },
    { id: "lab", label: "Inner lab" },
    { id: "skills", label: "Skills" },
    { id: "evidence", label: "Evidence" },
  ] as const;

  return (
    <section className="rounded-xl border border-border bg-surface p-4 md:p-5">
      <div className="mb-4 flex flex-wrap gap-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "h-11 rounded-md px-3 text-sm",
              tab === t.id ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tab === "mind" ? <MindNote snap={snap} /> : null}
      {tab === "memory" ? <MemoryLab snap={snap} /> : null}
      {tab === "lab" ? <InnerLab snap={snap} /> : null}
      {tab === "skills" ? <SkillsLab snap={snap} /> : null}
      {tab === "evidence" ? <EvidenceLab snap={snap} /> : null}
    </section>
  );
}

function MindNote({ snap }: { snap: OrganismSnapshot }) {
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Stat k="subject" v={snap.identity.subjectId.slice(-10)} />
      <Stat k="cycles" v={String(snap.identity.cycles)} />
      <Stat k="trust" v={snap.identity.trust.toFixed(2)} />
      <Stat k="replay" v={String(snap.replayCount)} />
      <Stat k="world error" v={snap.worldErrorEma.toFixed(4)} />
      <Stat k="language" v={String(snap.languageCalls)} />
      <div className="md:col-span-3">
        <h4 className="mb-2 text-xs uppercase tracking-wider text-subtle">Goals</h4>
        <ul className="space-y-2">
          {snap.goals.map((g) => (
            <li key={g.id}>
              <div className="flex justify-between text-sm">
                <span>{g.title}</span>
                <span className="tabular-nums text-muted">{(g.progress * 100).toFixed(0)}%</span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-accent" style={{ width: `${g.progress * 100}%` }} />
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function MemoryLab({ snap }: { snap: OrganismSnapshot }) {
  const [q, setQ] = useState("");
  const items = useMemo(() => {
    const s = q.trim().toLowerCase();
    return snap.memories.filter((m) => !s || m.text.toLowerCase().includes(s)).slice(0, 24);
  }, [q, snap.memories]);
  return (
    <div>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search memories…"
        className="mb-3 h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
      />
      <ul className="max-h-72 space-y-2 overflow-y-auto">
        {items.map((m) => (
          <li key={m.id} className="rounded-md border border-border bg-bg px-3 py-2">
            <p className="text-sm text-fg">{m.text}</p>
            <p className="mt-1 text-xs uppercase tracking-wider text-subtle">
              {m.kind} · {m.emotion} · pe {m.predictionError.toFixed(2)} · touches {m.touches}
              {m.verified ? " · verified" : ""}
            </p>
          </li>
        ))}
        {items.length === 0 ? <li className="text-sm text-muted">No memories yet.</li> : null}
      </ul>
    </div>
  );
}

function InnerLab({ snap }: { snap: OrganismSnapshot }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    const css = getComputedStyle(c);
    const bg = css.getPropertyValue("--color-bg").trim() || "#0a0b0c";
    const fg = css.getPropertyValue("--color-fg").trim() || "#ece8e1";
    const muted = css.getPropertyValue("--color-muted").trim() || "#9a958c";
    const accent = css.getPropertyValue("--color-accent").trim() || "#c8ccd4";
    const ok = css.getPropertyValue("--color-ok").trim() || "#6f8f78";
    const ember = css.getPropertyValue("--color-ember").trim() || "#8f3b3b";
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "rgba(236,232,225,0.12)";
    ctx.strokeRect(12, 12, w - 24, h - 24);
    const map = (p: [number, number]) =>
      [((p[0] + 1) / 2) * (w - 40) + 20, ((1 - p[1]) / 2) * (h - 40) + 20] as const;
    ctx.strokeStyle = "rgba(200,204,212,0.35)";
    ctx.beginPath();
    (snap.inner.trail ?? []).forEach((p, i) => {
      const [x, y] = map(p);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.fillStyle = ok;
    for (const r of snap.inner.resources ?? []) {
      const [x, y] = map(r);
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = ember;
    if (snap.inner.danger) {
      const [x, y] = map(snap.inner.danger);
      ctx.beginPath();
      ctx.arc(x, y, 7, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = accent;
    if (snap.inner.waypoint) {
      const [x, y] = map(snap.inner.waypoint);
      ctx.beginPath();
      ctx.arc(x, y, 8, 0, Math.PI * 2);
      ctx.stroke();
    }
    const [px, py] = map(snap.inner.pos);
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = muted;
    ctx.font = "11px IBM Plex Mono, monospace";
    ctx.fillText(
      `task ${["forage", "avoid", "waypoint"][snap.inner.task] ?? "?"}  E ${snap.inner.energy.toFixed(2)}  r ${snap.inner.lastReward.toFixed(3)}  n=${snap.inner.collected}`,
      20,
      h - 16,
    );
  }, [snap.inner]);

  return (
    <div>
      <canvas ref={canvas} width={640} height={280} className="h-auto w-full rounded-md border border-border" />
      <p className="mt-2 text-xs text-muted">
        Inner lab is a real 2D environment. Explore/verify step it; the GRU world model predicts the next
        embedding and learns from prediction error.
      </p>
    </div>
  );
}

function SkillsLab({ snap }: { snap: OrganismSnapshot }) {
  return (
    <ul className="space-y-2">
      {snap.skills.length === 0 ? <li className="text-sm text-muted">No skills forged yet. Talk and act.</li> : null}
      {snap.skills.map((s) => (
        <li key={s.id} className="rounded-md border border-border bg-bg px-3 py-2">
          <div className="flex justify-between text-sm">
            <span>{s.name}</span>
            <span className="tabular-nums text-muted">{s.uses} uses</span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-elevated">
            <div className="h-full bg-ok" style={{ width: `${s.success * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

function EvidenceLab({ snap }: { snap: OrganismSnapshot }) {
  return (
    <ul className="space-y-2">
      {snap.beliefs.map((b) => (
        <li key={b.id} className="rounded-md border border-border bg-bg px-3 py-2">
          <p className="text-xs uppercase tracking-wider text-subtle">{b.kind}</p>
          <p className="text-sm">{b.claim}</p>
          <p className="mt-1 text-xs tabular-nums text-muted">
            conf {b.confidence.toFixed(2)} · support {b.support} · {b.source}
          </p>
        </li>
      ))}
    </ul>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-md border border-border bg-bg px-3 py-2">
      <p className="text-xs uppercase tracking-wider text-subtle">{k}</p>
      <p className="font-mono text-sm tabular-nums">{v}</p>
    </div>
  );
}
