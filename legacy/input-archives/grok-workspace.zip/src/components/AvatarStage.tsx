import { useEffect, useRef, useState } from "react";
import type { EmotionLabel, OrganismSnapshot } from "@/organism/types";
import { cn } from "@/lib/utils";

const EXPR: Record<EmotionLabel, string> = {
  curiosity: "thinking",
  calm: "neutral",
  joy: "happy",
  anxiety: "sad",
  frustration: "angry",
  sadness: "sad",
  anger: "angry",
  protective: "focused",
};

export function AvatarStage({ snap, speaking }: { snap: OrganismSnapshot; speaking: boolean }) {
  const frame = useRef<HTMLIFrameElement>(null);
  const [live, setLive] = useState(false);

  useEffect(() => {
    const onMsg = (ev: MessageEvent) => {
      if (ev.origin !== window.location.origin) return;
      if (ev.data?.type === "live2d_ready") setLive(true);
      if (ev.data?.type === "live2d_error") setLive(false);
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  useEffect(() => {
    const win = frame.current?.contentWindow;
    if (!win || !live) return;
    win.postMessage(
      { type: "kurisu_expression", expression: EXPR[snap.emotion.label] ?? "neutral" },
      window.location.origin,
    );
    win.postMessage(
      {
        type: "kurisu_embodiment",
        speaking,
        mouthOpen: speaking ? 0.35 : 0.04,
        expressionIntensity: snap.emotion.arousal,
        gazeX: (snap.inner.pos[0] ?? 0) * 0.4,
        gazeY: (snap.inner.pos[1] ?? 0) * 0.25,
      },
      window.location.origin,
    );
    win.postMessage({ type: "kurisu_lipsync", value: speaking ? 0.45 : 0.02 }, window.location.origin);
  }, [snap.emotion, snap.inner.pos, speaking, live]);

  return (
    <div className="relative overflow-hidden rounded-xl bg-elevated">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,color-mix(in_oklab,var(--color-ember)_18%,transparent),transparent_62%)]" />
      <iframe
        ref={frame}
        title="Kurisu"
        src="/live2d/viewer.html?profile=auto"
        className={cn(
          "relative z-10 h-[320px] w-full border-0 md:h-[420px] transition-opacity duration-300",
          live ? "opacity-100" : "opacity-0",
        )}
        allow="autoplay"
      />
      {!live ? <FallbackPortrait emotion={snap.emotion.label} awake={snap.awake} speaking={speaking} /> : null}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4">
        <div>
          <p className="font-display text-lg tracking-tight text-fg">Kurisu</p>
          <p className="text-xs text-muted tabular-nums">
            {snap.awake ? "awake" : "sleep"} · {snap.emotion.label} · t{snap.tick}
          </p>
        </div>
        <span className="rounded-full border border-border bg-bg/70 px-2.5 py-1 text-xs uppercase tracking-wider text-muted">
          {live ? "live2d" : "portrait"}
        </span>
      </div>
    </div>
  );
}

function FallbackPortrait({
  emotion,
  awake,
  speaking,
}: {
  emotion: EmotionLabel;
  awake: boolean;
  speaking: boolean;
}) {
  const open = speaking ? 8 : 2;
  const brow =
    emotion === "anger" || emotion === "frustration" ? -8 : emotion === "sadness" || emotion === "anxiety" ? 6 : 0;
  return (
    <div className="pointer-events-none absolute inset-0 z-[11] flex items-center justify-center">
      <svg viewBox="0 0 200 260" className="h-full w-auto opacity-90" aria-hidden>
        <ellipse cx="100" cy="248" rx="54" ry="10" fill="color-mix(in oklab, var(--color-fg) 8%, transparent)" />
        <path d="M70 210 C70 170 60 150 58 120 L142 120 C140 150 130 170 130 210 Z" fill="#d8d4cc" />
        <path d="M78 128 C60 70 78 28 100 22 C128 28 144 70 122 128" fill="#6a2c28" />
        <path d="M48 90 C40 140 52 190 70 210 L78 128 C62 110 52 96 48 90Z" fill="#5a241f" />
        <path d="M152 90 C160 140 148 190 130 210 L122 128 C138 110 148 96 152 90Z" fill="#5a241f" />
        <ellipse cx="100" cy="118" rx="34" ry="40" fill="#e8cbb8" />
        <path d="M70 96 C86 88 114 88 130 96" fill="none" stroke="#4a1e1a" strokeWidth="10" />
        <g transform={`translate(0 ${brow})`}>
          <path d="M78 108 L92 106" stroke="#2a1a16" strokeWidth="2" strokeLinecap="round" />
          <path d="M122 108 L108 106" stroke="#2a1a16" strokeWidth="2" strokeLinecap="round" />
        </g>
        {awake ? (
          <>
            <ellipse cx="86" cy="118" rx="5" ry="6" fill="#2a2422" />
            <ellipse cx="114" cy="118" rx="5" ry="6" fill="#2a2422" />
            <circle cx="87.5" cy="116.5" r="1.2" fill="#f4f1ea" />
            <circle cx="115.5" cy="116.5" r="1.2" fill="#f4f1ea" />
          </>
        ) : (
          <>
            <path d="M80 118 Q86 122 92 118" fill="none" stroke="#2a2422" strokeWidth="1.6" />
            <path d="M108 118 Q114 122 120 118" fill="none" stroke="#2a2422" strokeWidth="1.6" />
          </>
        )}
        <path d={`M92 138 Q100 ${138 + open} 108 138`} fill="none" stroke="#8a4a48" strokeWidth="1.6" />
      </svg>
    </div>
  );
}
