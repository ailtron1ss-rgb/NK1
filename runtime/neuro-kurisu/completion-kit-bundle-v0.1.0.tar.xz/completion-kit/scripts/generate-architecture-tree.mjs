import { readdir, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const kitRoot = path.resolve(here, '..');
const runtimeRoot = path.resolve(kitRoot, '..');
const excluded = new Set(['node_modules', '.git', 'dist', 'coverage', '.cache']);
const allowed = /\.(?:ts|tsx|mts|js|mjs|json|py|sh|ps1|md)$/i;

export async function generateArchitectureTree({
  root = runtimeRoot,
  roots = ['src/organism', 'tests'],
  maxDepth = 9,
  outputDir = path.join(kitRoot, 'reports'),
  generatedAt = new Date().toISOString(),
} = {}) {
  if (!Number.isSafeInteger(maxDepth) || maxDepth < 1 || maxDepth > 30) throw new RangeError('maxDepth must be an integer in [1,30]');
  if (!Array.isArray(roots) || roots.length === 0 || roots.some(value => typeof value !== 'string' || !value.trim())) throw new TypeError('roots must be a non-empty string array');
  const absoluteRoot = path.resolve(root);
  const rows = [];
  async function walk(relative, depth = 0) {
    if (depth > maxDepth) return;
    const absolute = path.resolve(absoluteRoot, relative);
    const rel = path.relative(absoluteRoot, absolute);
    if (rel.startsWith('..') || path.isAbsolute(rel)) { rows.push({ path: relative, kind: 'unsafe-root-skipped' }); return; }
    let entries;
    try { entries = await readdir(absolute, { withFileTypes: true }); }
    catch (error) { rows.push({ path: relative, kind: 'missing-root', error: error.code ?? error.message }); return; }
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (excluded.has(entry.name) || entry.name.startsWith('.')) continue;
      const child = path.posix.join(relative.replaceAll(path.sep, '/'), entry.name);
      if (entry.isSymbolicLink()) { rows.push({ path: child, kind: 'symlink-skipped' }); continue; }
      if (entry.isDirectory()) {
        rows.push({ path: child, kind: 'directory' });
        await walk(child, depth + 1);
      } else if (entry.isFile() && allowed.test(entry.name)) {
        rows.push({ path: child, kind: 'file', extension: path.extname(entry.name).toLowerCase() });
      }
    }
  }
  for (const relative of roots) await walk(relative);
  const counts = rows.reduce((acc, row) => { acc[row.kind] = (acc[row.kind] ?? 0) + 1; return acc; }, {});
  const tree = {
    schemaVersion: 1,
    generatedAt,
    sourceRoot: absoluteRoot,
    roots: [...roots],
    maxDepth,
    counts,
    entries: rows,
    limitations: [
      'Filesystem tree is a navigation aid, not proof of runtime wiring or useful behavior.',
      'Dynamic imports, runtime plugin registration and generated files may not be represented.',
      'Symlinks and excluded build/cache/vendor directories are intentionally omitted.'
    ]
  };
  await mkdir(outputDir, { recursive: true });
  await writeFile(path.join(outputDir, 'generated-source-tree.json'), JSON.stringify(tree, null, 2) + '\n');
  const lines = [
    '# Generated NeuroCore source tree', '',
    `Generated: ${generatedAt}`,
    `Roots: ${roots.join(', ')}`,
    `Counts: ${Object.entries(counts).map(([key, value]) => `${key}=${value}`).join(', ')}`,
    '', '```text',
    ...rows.map(row => `${row.kind === 'directory' ? 'd ' : row.kind === 'file' ? '  ' : '! '}${row.path}`),
    '```', '', '## Limitations',
    ...tree.limitations.map(item => `- ${item}`), ''
  ];
  await writeFile(path.join(outputDir, 'generated-source-tree.md'), lines.join('\n'));
  return { status: 'GENERATED', roots: [...roots], counts, entries: rows.length, outputDir };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const valueAfter = (flag, fallback) => {
    const index = args.indexOf(flag);
    return index >= 0 && args[index + 1] ? args[index + 1] : fallback;
  };
  const roots = valueAfter('--roots', 'src/organism,tests').split(',').map(value => value.trim()).filter(Boolean);
  const maxDepth = Number(valueAfter('--max-depth', '9'));
  const report = await generateArchitectureTree({ roots, maxDepth });
  console.log(JSON.stringify(report, null, 2));
}
