import { readFile, mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const kitRoot = path.resolve(here, '..');
const runtimeRoot = path.resolve(kitRoot, '..');
const packageJson = JSON.parse(await readFile(path.join(runtimeRoot, 'package.json'), 'utf8'));
const gates = JSON.parse(await readFile(path.join(kitRoot, 'architecture/gates.json'), 'utf8'));
const gateId = process.argv[2];
const gate = gates.gates.find(item => item.id === gateId);
if (!gate) {
  console.error(`Unknown gate '${gateId}'. Available: ${gates.gates.map(item => item.id).join(', ')}`);
  process.exit(2);
}
const startedAt = new Date().toISOString();
const results = [];
for (const script of gate.scripts) {
  if (!Object.hasOwn(packageJson.scripts ?? {}, script)) {
    results.push({ script, status: 'MISSING_SCRIPT', exitCode: null, output: '' });
    continue;
  }
  const result = spawnSync('npm', ['run', script], {
    cwd: runtimeRoot,
    encoding: 'utf8',
    timeout: 30 * 60 * 1000,
    maxBuffer: 20 * 1024 * 1024,
    shell: process.platform === 'win32',
    env: { ...process.env, CI: process.env.CI ?? '1' },
  });
  const output = `${result.stdout ?? ''}${result.stderr ?? ''}`;
  results.push({
    script,
    status: result.error ? 'ERROR' : result.status === 0 ? 'PASS' : 'FAIL',
    exitCode: result.status,
    error: result.error?.message ?? null,
    output: output.slice(-12000),
  });
  console.log(`\n[${results.at(-1).status}] npm run ${script}`);
  if (result.status !== 0 || result.error) break;
}
const report = {
  schemaVersion: 1,
  gateId,
  title: gate.title,
  sourceBranch: 'workpass70-source',
  startedAt,
  finishedAt: new Date().toISOString(),
  status: results.length === gate.scripts.length && results.every(row => row.status === 'PASS') ? 'PASS' : 'INCOMPLETE_OR_FAILED',
  results,
  acceptance: gate.acceptance,
  warning: 'Passing software gates does not close independent holdout, real-device, long-duration soak, privacy or human license gates unless those checks are explicitly run and attached.',
};
const reportDir = path.join(kitRoot, 'reports');
await mkdir(reportDir, { recursive: true });
const reportPath = path.join(reportDir, `gate-${gateId}-${Date.now()}.json`);
await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n');
console.log(`\nReport: ${path.relative(runtimeRoot, reportPath)}`);
if (report.status !== 'PASS') process.exitCode = 1;
