import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { evaluateSkillPromotion } from '../src/promotion-gate.mjs';
const inputPath = process.argv[2];
if (!inputPath) {
  console.error('Usage: npm run promotion -- <promotion-input.json>');
  process.exit(2);
}
const absolute = path.resolve(process.cwd(), inputPath);
const input = JSON.parse(await readFile(absolute, 'utf8'));
const report = evaluateSkillPromotion(input);
console.log(JSON.stringify(report, null, 2));
if (!report.eligible) process.exitCode = 2;
