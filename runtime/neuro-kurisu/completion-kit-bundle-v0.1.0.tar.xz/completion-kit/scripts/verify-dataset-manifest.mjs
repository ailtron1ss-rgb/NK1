import { readFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

const [manifestArg, rootArg] = process.argv.slice(2);
if (!manifestArg || !rootArg) {
  console.error('Usage: node scripts/verify-dataset-manifest.mjs <manifest.json> <dataset-root>');
  process.exit(2);
}
const manifestPath = path.resolve(manifestArg);
const rootPath = await realpath(path.resolve(rootArg));
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
if (manifest.schemaVersion !== 1 || !Array.isArray(manifest.files)) throw new Error('dataset manifest schema is invalid');
const seen = new Set();
const results = [];
for (const entry of manifest.files) {
  if (!entry || typeof entry.path !== 'string' || typeof entry.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(entry.sha256)) {
    results.push({ path: entry?.path ?? null, status: 'INVALID_MANIFEST_ENTRY' });
    continue;
  }
  const normalized = entry.path.replaceAll('\\', '/');
  if (!normalized || normalized.startsWith('/') || normalized.split('/').some(part => part === '..' || part === '.')) {
    results.push({ path: entry.path, status: 'UNSAFE_PATH' });
    continue;
  }
  if (seen.has(normalized)) {
    results.push({ path: normalized, status: 'DUPLICATE_PATH' });
    continue;
  }
  seen.add(normalized);
  const target = path.resolve(rootPath, normalized);
  const relative = path.relative(rootPath, target);
  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    results.push({ path: normalized, status: 'PATH_ESCAPE' });
    continue;
  }
  try {
    const resolvedTarget = await realpath(target);
    const resolvedRelative = path.relative(rootPath, resolvedTarget);
    if (resolvedRelative.startsWith('..') || path.isAbsolute(resolvedRelative)) {
      results.push({ path: normalized, status: 'PATH_ESCAPE' });
      continue;
    }
    const metadata = await lstat(target);
    if (!metadata.isFile() || metadata.isSymbolicLink()) {
      results.push({ path: normalized, status: 'NOT_REGULAR_FILE' });
      continue;
    }
    const bytes = await readFile(target);
    const actual = createHash('sha256').update(bytes).digest('hex');
    const sizeMatches = entry.size === undefined || entry.size === bytes.byteLength;
    results.push({ path: normalized, expected: entry.sha256.toLowerCase(), actual, size: bytes.byteLength, sizeMatches, status: actual === entry.sha256.toLowerCase() && sizeMatches ? 'MATCH' : 'HASH_MISMATCH' });
  } catch (error) {
    results.push({ path: normalized, status: 'MISSING_OR_UNREADABLE', error: error.code ?? error.message });
  }
}
const mismatches = results.filter(row => row.status !== 'MATCH');
const report = { schemaVersion: 1, manifest: path.basename(manifestPath), datasetRoot: rootPath, checkedFiles: results.length, matchedFiles: results.length - mismatches.length, pass: mismatches.length === 0 && results.length > 0, results, note: 'Hash integrity does not establish dataset license, provenance, consent or benchmark validity.' };
console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
