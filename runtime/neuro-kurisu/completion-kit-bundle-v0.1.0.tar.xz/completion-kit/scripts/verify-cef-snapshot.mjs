import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { auditFullCognitiveLineage } from '../src/lineage-audit.mjs';
const inputPath = process.argv[2];
if (!inputPath) {
  console.error('Usage: node scripts/verify-cef-snapshot.mjs <cef-snapshot.json>');
  process.exit(2);
}
const sourcePath = path.resolve(process.cwd(), inputPath);
const data = JSON.parse(await readFile(sourcePath, 'utf8'));
const events = Array.isArray(data.events) ? data.events : Array.isArray(data.recent) ? data.recent : null;
if (!events) throw new Error('snapshot must contain events[] or recent[]');
const cycles = Array.isArray(data.cycles) ? data.cycles : data.stageIds ? [{ tick: data.tick, stageIds: data.stageIds }] : [];
if (cycles.length === 0) throw new Error('snapshot must contain cycles[] or a top-level stageIds map');
const results = cycles.map((cycle, index) => ({
  cycleIndex: index,
  ...auditFullCognitiveLineage({ events, stageIds: cycle.stageIds, expectedTick: cycle.tick }),
}));
const report = {
  schemaVersion: 1,
  sourceSha: typeof data.sourceSha === 'string' ? data.sourceSha : null,
  input: path.basename(sourcePath),
  cyclesChecked: results.length,
  fullCompleteCycles: results.filter(row => row.fullComplete).length,
  failedCycles: results.filter(row => !row.fullComplete).length,
  pass: results.every(row => row.fullComplete),
  results,
  note: 'Read-only structural proof. It verifies event IDs, 11 stages, same-tick identity and required causal parent edges; it does not prove cognitive quality or useful behavior.'
};
console.log(JSON.stringify(report, null, 2));
if (!report.pass) process.exitCode = 1;
